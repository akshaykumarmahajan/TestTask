'use strict';

var mongoose = require('mongoose'),
    User = mongoose.model('user'),
    
    formidable = require('formidable'),
    fs = require('fs-extra'),
    path = require('path'),
    jwt = require('jsonwebtoken'),
    validator = require('validator'),
    utility = require('../lib/utility.js'),
    mailer =  require('../lib/mailer.js'),
    waterfall = require('async-waterfall'),
    async = require('async'),
    Error = require('../lib/error.js'),
    Response = require('../lib/response.js'),
    constant = require('../lib/constants'),
    c = require('../helpers/cypher');

    const config = require('../../config/config.js').get(process.env.NODE_ENV);

module.exports = {
    adminLoggedin:adminLoggedin,
    adminLogin: adminLogin,
    getAdminById: getAdminById,
    adminChangePassword: adminChangePassword,
    adminProfileUpdate: adminProfileUpdate,
    adminUpdateImage: adminUpdateImage,
    adminForgotPassword:adminForgotPassword,
    adminResetPassword: adminResetPassword,    
    verifyLink: verifyLink,
};


/**
 * Function is use to check admin login status
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 11-Jan-2018
 */
function adminLoggedin(req, res) {
    if (req.headers && req.headers.authorization) { // success callback for the Authentication
        var parts = req.headers.authorization.split(' ');

        if (parts.length == 2) {
            jwt.verify(parts[1], config.secret, function(err, user) {
                if (err) {
                    // res.json(Response(402, constant.messages.authenticationFailed));
                    res.json(Response(constant.statusCode.unauth, constant.messages.authenticationFailed));
                } else {
                    if (user) {
                        User.findById(user.uid,{ createdAt:0, updatedAt:0, isSendCredential:0, password:0})
                        .exec(function(err, admin) {
                            if (err)
                                // res.json(Response(402, constant.messages.authenticationFailed));
                                res.json(Response(constant.statusCode.unauth, constant.messages.authenticationFailed));
                            else if (!admin){
                                // res.json(Response(402, constant.messages.authenticationFailed));
                                res.json(Response(constant.statusCode.unauth, constant.messages.authenticationFailed));
                            }else{

                                res.json({
                                    "code": constant.statusCode.ok,
                                    status: constant.messages.ok,
                                    user: admin
                                });

                                // utility.fileExistCheck('./public/assets/images/users/' + admin.image, function(exist) {
                                //     if (!exist) {
                                //         admin.image = 'noUser.jpg';
                                //         res.json({ "code": 200, status: "OK", user: admin });
                                //     } else {
                                //         res.json({ "code": 200, status: "OK", user: admin });
                                //     }
                                // });                                
                            }
                        });
                    } else {
                        // res.json(Response(402, constant.messages.authenticationFailed));
                        res.json(Response(constant.statusCode.unauth, constant.messages.authenticationFailed));
                    }
                }
            });
        } else {
            // res.json(Response(402, constant.messages.authenticationFailed));
            res.json(Response(constant.statusCode.unauth, constant.messages.authenticationFailed));
        }
    } else {
        // res.json(Response(402, constant.messages.authenticationFailed));
        res.json(Response(constant.statusCode.unauth, constant.messages.authenticationFailed));
    }
}

/**
 * Function is admin login
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 11-Jan-2018
 */
function adminLogin(req, res) {
    if (validator.isNull(req.body.email) || !req.body.email) {
        return res.json(Response(402,  constant.validateMsg.emailRequired));
    } else if (req.body.email && !validator.isEmail(req.body.email)) {
        return res.json(Response(402, constant.validateMsg.invalidEmail));
    } else if (validator.isNull(req.body.password) || !req.body.password) {
        return res.json(Response(402, constant.validateMsg.passwordRequired));
    } else {
        var passEnc = utility.getEncryptText(req.body.password);
        var lastLoginDate = new Date();
        var adminData = {
            email: req.body.email.toLowerCase(),
            password: passEnc,
            deleted:false,
            role: 'Admin'
        };
        User.findOne(adminData, function(err, adminRecord) {
            if (err) {
                res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
            } else if(adminRecord != null) {
                    var expirationDuration = 60 * 60 * 24 * 8; // expiration duration format sec:min:hour:day. ie: 8 Hours as per i/p
                    var jwtToken = jwt.sign({ uid: adminRecord._id }, config.secret, {
                        expiresIn: expirationDuration
                    });

                    var userObj = {};
                    userObj.token = jwtToken;
                    userObj.lastLoginDate = new Date();
                    User.findOneAndUpdate({_id: adminRecord._id}, { $set: userObj }, {new: true}, function (err, adminNewRecord) {
                        if (err) {
                            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                        } else {
                            res.json(Response(constant.statusCode.ok, constant.messages.loginSuccess, adminNewRecord, jwtToken));
                        }
                    });
            }else{
                res.json(Error(constant.statusCode.error, constant.messages.invalidLoginInput, null));   
            }
        });
    }
}

/**
 * Admin forgot passsword
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 12-Jan-2018
 */
function adminForgotPassword(req, res) {
    // console.log(req.body.email)
    if (validator.isNull(req.body.email)) {
        res.json(Error(constant.statusCode.error, constant.validateMsg.requiredFieldsMissing, constant.validateMsg.requiredFieldsMissing));
    }else if(req.body.email && !validator.isEmail(req.body.email)){    
        res.json(Error(constant.statusCode.error, constant.validateMsg.invalidEmail, constant.validateMsg.invalidEmail));
    } else {
        var where = { email: req.body.email , isDelete:false};
        User.findOne(where).exec(function(err, userInfoData) {
            if (err) {
                res.json(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
            } else {
                if (!userInfoData) {
                    res.json(Error(constant.statusCode.error, constant.messages.emailNotExist, constant.messages.emailNotExist));
                } else {
                    if(userInfoData.userType == 'user'|| userInfoData.userType == 'org'){
                        res.json(Error(constant.statusCode.error, constant.messages.emailNotExist, constant.messages.emailNotExist));
                    }else if (userInfoData.status == 0) {
                        res.json(Error(constant.statusCode.error, constant.messages.userNotactivated, constant.messages.userNotactivated));
                    } else if (userInfoData.isDelete) {
                        res.json(Error(constant.statusCode.error, constant.messages.userAccountdeleted, constant.messages.userAccountdeleted));
                    } else {
                        var query = {_id: userInfoData._id};
                        var data={
                            reset_key: ''
                        }
                        data.reset_key = c.uuid.v1();
                        User.findOneAndUpdate(query, data, function(err, result) {
                            if (result) {
                                var baseUrl = config.baseUrl;
                                var userMailData = { userId: userInfoData._id, email: userInfoData.email, firstname: userInfoData.firstname, lastname: userInfoData.lastname, password: utility.getDecryptText(userInfoData.password),link: baseUrl + 'admin/#/reset-password/' + data.reset_key};
                                mailer.sendMail(userInfoData.email, constant.emailKeyword.forgotPassword, userMailData, function(err, resp) {
                                    if(err){
                                        res.json(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                                    }else{
                                        res.json(Response(constant.statusCode.ok, constant.messages.forgotPasswordSuccess, {}, null));
                                    }
                                });
                            }
                        });
                    }
                }
            }
        });
    }
}

/**
 * Admin Reset Password
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 12-Jan-2018
 */
function adminResetPassword(req, res) {
    var data = req.body;
    var resetKey = data.reset_key;
    try {
        data.password = utility.getEncryptText(req.body.password);
        data.reset_key = '';
        data.status = true;
        var query = { 'reset_key': resetKey };
        User.findOneAndUpdate(query, data, { new: true }, function (err, user) {
            if (err) {
                res.json(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
            } else if (!user) {
                res.json(Response(constant.statusCode.warning, constant.messages.resetPasswordTokenExpire, {}, null));
            } else {
                res.json(Response(constant.statusCode.ok, constant.messages.resetPasswordSuccess, {}, null));
            }
        });
    } catch (err) {
        res.json(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
    }
}


/**
 * Function is admin data by ID
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 12-Jan-2018
 */
function getAdminById(req, res) {
    var id = req.swagger.params.id.value;
    User.findOne({ _id: id },{ device:0, password: 0, updatedAt: 0, createdAt: 0, verifyToken: 0}).lean().exec(function(err, data) {
        if (err) {
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        } else {
            if (!data) {
                res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));

            } else {
                utility.fileExistCheck('./public/assets/admin/images/users/' + data.image, function(exist) {
                    if (!exist) {
                        data.image = 'noUser.jpg';
                        res.json(Response(constant.statusCode.ok, constant.messages.dataRetrievedSuccess, data, null));
                    } else {
                        res.json(Response(constant.statusCode.ok, constant.messages.dataRetrievedSuccess, data, null));
                    }
                });
            }
        }
    });
}

/**
 * Function is use to change user password by user id
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 12-Jan-2018
 */
function adminChangePassword(req, res) {
    if (validator.isNull(req.body.oldPassword) || validator.isNull(req.body.newPassword)) {
        res.jsonp(Error(constant.statusCode.error, constant.validateMsg.requiredFieldsMissing, constant.validateMsg.requiredFieldsMissing));
    } else {
        User.findOne({ _id: req.body.userId }, { password: 1 }, function(err, users) {
            if (err) {
                res.json(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
            } else {
                if (users) {
                    var oldPassword = utility.getEncryptText(req.body.oldPassword);
                    var newPassword = utility.getEncryptText(req.body.newPassword);
                    if (users.password == oldPassword) {
                        if (validator.equals(oldPassword, newPassword)) {
                            res.jsonp(Error(constant.statusCode.error, constant.validateMsg.passwordDoNotUseSame, constant.validateMsg.passwordDoNotUseSame));
                        } else {
                            var updateUserRecord = {
                                password: newPassword
                            }
                            User.update({ _id: req.body.userId }, { $set: updateUserRecord }, function(err) {
                                if (err) {
                                    res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                                } else {
                                    res.json(Response(constant.statusCode.ok, constant.messages.successInChangePassword, {}, null));
                                }
                            });
                        }
                    } else {
                        res.jsonp(Error(constant.statusCode.error, constant.messages.currentPasswordWorng, constant.messages.currentPasswordWorng));
                    }
                }
            }

        })
    }
}


/**
 * Function is use to update admin info by id
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 12-Jan-2018
 */
function adminProfileUpdate(req, res) {
    User.find({ email: req.body.email.toLowerCase(), _id: { $ne: req.body._id }, deleted: false }, function(err, existAdminData) {
        if (err) {
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        } else {
            if (existAdminData.length > 0) {
                res.jsonp(Error(constant.statusCode.error, constant.messages.emailAlreadyExist, constant.messages.emailAlreadyExist));
            } else {

                User.findById(req.body._id).exec(function(err, adminData) {
                    if (err) {
                        res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                    } else {
                        if (adminData) {
                            adminData.firstname = req.body.firstname;
                            adminData.lastname = req.body.lastname;
                            // adminData.phone_number = req.body.phone_number;
                            adminData.email = req.body.email.toLowerCase();
                            // adminData.gender = req.body.gender;
                            // adminData.designation = req.body.designation;
                            adminData.save(function(err, savedData) {
                                if (err) {
                                    res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                                } else {
                                    res.json(Response(constant.statusCode.ok, constant.messages.profileUpdateSuccess, { _id: savedData._id }, null));
                                }
                            });
                        } else {
                            res.jsonp(Error(constant.statusCode.error, constant.messages.noRecordFound, constant.messages.noRecordFound));
                        }
                    }
                });


            }
        }
    });
}

/**
 * Function is use to update Admin profile pic
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 12-Jan-2018
 */
function adminUpdateImage(req, res) {

    var timestamp = Number(new Date()); // current time as number
    var file = req.swagger.params.file.value;
    var userId = req.swagger.params.id.value;
    var splitFileName = file.originalname.split('.');
    var ext = splitFileName[splitFileName.length - 1].toLowerCase();
    var filename = userId + '_' + timestamp + '.' + ext;
    var imagePath = "./public/assets/admin/images/users/" + filename;
    User.findOne({ _id: userId }, function (err, userData) {
        if (err) {
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        } else if (userData) {
            fs.writeFile(path.resolve(imagePath), file.buffer, function (err) {
                if (err) {
                    res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                } else {
                    var UserImage = { image: filename };
                    User.update({ _id: userId }, { $set: UserImage }, function (err) {
                        if (err) {
                            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                        } else {
                            if (userData.image != 'noUser.jpg') {
                                var filePath = __dirname + '/../../public/assets/admin/images/users/' + userData.image;
                                fs.exists(filePath, function (exists) {
                                    if (exists) {
                                        fs.unlink(filePath, function (err) {
                                            if (err) {
                                                res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                                            } else {
                                                res.json(Response(constant.statusCode.ok, constant.messages.imageUpdateSuccess, constant.messages.imageUpdateSuccess, null));
                                            }
                                        });
                                    } else {
                                        res.json(Response(constant.statusCode.ok, constant.messages.imageUpdateSuccess, constant.messages.imageUpdateSuccess, null));
                                    }
                                });
                            }
                        }
                    });
                }
            });
        } else {
            res.jsonp(Error(constant.statusCode.error, constant.messages.userNotFound, constant.messages.userNotFound));
        }
    }); //findOne end
}

/**
 * Function is use to activate user account after sign up by verifying Link
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 123-Jan-2017
 */
function verifyLink(req, res) {
    User.findOne({
        verifying_token: req.params.id
    }, function(err, user) {
        if (err || !user) {
            res.redirect("/#/show-message?emailSuccess=false");
        } else {
            user.status = 'Active';
            user.verifying_token = null;
            user.save(function(err, data) {
                if (err)
                    res.redirect("/#/verifying-link?success=false");
                else {
                    res.redirect("/#/verifying-link?success=true");
                }
            });
        }

    })
}



