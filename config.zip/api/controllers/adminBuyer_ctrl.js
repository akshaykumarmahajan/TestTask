'use strict';
var mongoose = require('mongoose'),
User = mongoose.model('user'),
waterfall = require('async-waterfall'),
utility = require('../lib/utility.js'),
Error = require('../lib/error.js'),
Response = require('../lib/response.js'),
constant = require('../lib/constants');
// const config = require('../../config/config.js').get(process.env.NODE_ENV);
module.exports = {
    getBuyerList: getBuyerList,
    getBuyerDetails: getBuyerDetails,
    updateBuyer: updateBuyer,
    deleteBuyer: deleteBuyer,
    changeBuyerStatus: changeBuyerStatus
};

/**
 * Function is use to get buyer list by admin 
 * @access private
 * @return json
 * Created by Abhijit A
 * @smartData Enterprises (I) Ltd
 * Created Date 11-Apr-2018
 */
function getBuyerList(req, res) {
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    var sorting = utility.getSortObj(req.body);
    // var sorting = req.body.sorting ? req.body.sorting : { _id: -1 };
    var condition = {};
    var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
    if (req.body.searchText) {
        condition.$or = [
            { 'phone_number': parseInt(searchText) },
            { 'firstname': new RegExp(searchText, 'gi') },
            { 'lastname': new RegExp(searchText, 'gi') },
            { 'email': new RegExp(searchText, 'gi') },
        ];
    }
    if (searchText.split('\\s+')[1]) {
        condition.$or = [
            { 'firstname': new RegExp(searchText.split('\\s+')[0], 'gi') },
            { 'lastname': new RegExp(searchText.split('\\s+')[1], 'gi') }
        ]
    }
    condition.deleted = false;
    condition.role = 'Buyer';
    User.find(condition)
        .limit(parseInt(count))
        .skip(parseInt(skip))
        .sort(sorting)
        .lean()
        .exec(function (err, result) {
            if (err) {
                res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
            } else {
                var data = {};
                data.data = result;
                User.find(condition).count().exec(function (err, totalCount) {
                    if (err) {
                        res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                    } else {
                        data.totalCount = totalCount
                        res.json(Response(constant.statusCode.ok, constant.messages.dataRetrievedSuccess, data, null));
                    }
                })
            }
        })
}
/**
 * Function is use to get buyer details by buyerId 
 * @access private
 * @return json
 * Created by Abhijit A
 * @smartData Enterprises (I) Ltd
 * Created Date 11-Apr-2018
 */
function getBuyerDetails(req, res) {
    User.findOne({ _id: req.body.buyerId })
        .lean()
        .exec(function (err, data) {
            if (err) {
                res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
            } else {
                if (!data) {
                    res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                } else {
                    utility.fileExistCheck('./public/assets/images/users/' + data.profile_pic, function (exist) {
                        if (!exist) {
                            res.json(Response(constant.statusCode.ok, constant.messages.dataRetrievedSuccess, data, null));
                        } else {
                            res.json(Response(constant.statusCode.ok, constant.messages.dataRetrievedSuccess, data, null));
                        }
                    });
                }
            }
        });
}

/**
 * Function is use to get buyer details by buyerId 
 * @access private
 * @return json
 * Created by Abhijit A
 * @smartData Enterprises (I) Ltd
 * Created Date 11-Apr-2018
 */
function updateBuyer(req, res) {
    var finalResponse = {};
    waterfall([
        function (callback) {
            User.find({ email: req.body.email.toLowerCase(), _id: { $ne: req.body._id }, deleted: false }).lean().exec(function (err, buyerData) {
                if (err) {
                    callback(err, false);
                } else {
                    if (buyerData.length > 0) {
                        res.jsonp(Error(constant.statusCode.error, constant.validateMsg.emailAlreadyExist, constant.validateMsg.emailAlreadyExist));
                    } else {
                        User.findById(req.body._id).exec(function (err, data) {
                            if (err) {
                                res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                            } else {
                                finalResponse.buyerData = data;
                                callback(null, finalResponse);
                            }
                        });
                    }
                }
            });
        },
        function (finalResponse, callback) {
            var buyerRecord = {
                username: req.body.firstname + ' ' + req.body.lastname,
                firstname: req.body.firstname,
                lastname: req.body.lastname,
                email: req.body.email.toLowerCase(),
                dob: req.body.dob,
                address_line_1: req.body.address_line_1,
                address_line_2: req.body.address_line_2,
                gender: req.body.gender,
                phone_number: req.body.phone_number,
                zipcode: req.body.zipcode,
                city: req.body.city,
                state: req.body.state,
                country: req.body.country,
                // modifiedBy: req.body.modifiedBy,
                // modifiedById: req.body.modifiedById,
            };
            User.update({ _id: req.body._id }, { $set: buyerRecord }, function (err) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            });
        },
    ], function (err, data) {
        if (err) {
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        } else {
            res.json(Response(constant.statusCode.ok, constant.messages.buyerUpdateSuccess, data, null));
        }
    });
}

/**
 * Function is use to update seller status 
 * @access private
 * @return json
 * Created by Abhijit A
 * @smartData Enterprises (I) Ltd
 * Created Date 11-Apr-2018
 */
function changeBuyerStatus(req, res) {
    if (req.body.status == 0 || req.body.status == 1) {
        if (req.body.status == 1) {
            var updateBuyerStatus = { status: 1 };
        } else {
            var updateBuyerStatus = { status: 0 };
        }
        User.update({ _id: req.body.buyerId }, { $set: updateBuyerStatus }, function (err) {
            if (err) {
                res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
            } else {
                res.json(Response(constant.statusCode.ok, constant.messages.buyerStatusUpdateSuccess, {}, null));
            }
        });
    } else {
        res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed));
    }
}

/**
 * Function is use to delete Buyer by Buyer id
 * @access private
 * @return json
 * Created by Ashwini
 * @smartData Enterprises (I) Ltd
 * Created Date 11-Apr-2017
 */
function deleteBuyer(req, res) {
    var id = req.swagger.params.id.value;
    var updateBuyerRecord = { deleted: true }
    User.update({ _id: id }, { $set: updateBuyerRecord }, function (err) {
        if (err) {
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        } else {
            res.json(Response(constant.statusCode.ok, constant.messages.buyerDeleteSuccess, {}, null));
        }
    });
}


