'use strict';

var mongoose = require('mongoose'),
    common = require('../../config/common.js'),
    Error = require('../lib/error.js'),
    Response = require('../lib/response.js'),
    utility = require('../lib/utility.js'),
    constant = require('../lib/constants.js'),
    waterfall = require('async-waterfall'),
    async = require('async'),
    User = mongoose.model('user'),
    Permission = mongoose.model('permission'),
    ProductCategory = mongoose.model('product_category');

module.exports = {
    getCategoryList: getCategoryList,
    addCategory: addCategory,
    updateCategory: updateCategory,
    getCategoryListAdmin: getCategoryListAdmin,
    getCategoryDetail: getCategoryDetail,
    changeCategoryStatus: changeCategoryStatus,
    deleteCategory: deleteCategory
};

/**
 * Function is use to get Dashboard 
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 26-Apr-2018
 */
function getCategoryList(req, res){
    ProductCategory.find({isSubCategory: false, categoryId: null, deleted: false})
    .lean()
    .exec(function(err, categoryList){
        if (err)
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        else {
            res.json(Response(constant.statusCode.ok, constant.messages.dataRetrievedSuccess, categoryList, null));
        }
    });
}

/**
 * Function is use to add category
 * @access private
 * @return json
 * Created by abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 26-Apr-2018
 */
function addCategory(req, res){
    console.log("Add Category Body :: ", req.body);
    var finalResponse = {};
    waterfall([
        function(callback) {
            User.findOne({ _id : req.body.addedBy, deleted: false}).lean().exec(function(err, adminInfo) {
                if (err) {
                    callback(constant.messages.requestNotProcessed, null);
                } else {
                    finalResponse.adminInfo = adminInfo;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) {
            console.log("finalResponse.adminInfo :: ", finalResponse.adminInfo);
            Permission.findOne({ adminId : finalResponse.adminInfo._id}).lean().exec(function(err, permissionInfo) {
                if (err) {
                    callback(constant.messages.requestNotProcessed, null);
                } else {
                    console.log("permissionInfo :: ", permissionInfo);
                    if(permissionInfo.category == true){
                        finalResponse.permissionInfo = permissionInfo;                       
                        callback(null, finalResponse);
                    }else{
                        callback(constant.messages.noPermission, null);
                    }                    
                }
            });
        },
        function(finalResponse, callback){
            ProductCategory.findOne({name: req.body.name, deleted: false}, function(err, categoryData){
                if(err){
                    callback(constant.messages.requestNotProcessed, null);
                }else if(categoryData){
                    callback(constant.messages.categoryAlreadyExist, null);
                }else{
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) { //status: "1"
            var categoryObj = {
                categoryId      : req.body.categoryId,
                addedBy         : req.body.addedBy,
                name            : req.body.name,
                description     : req.body.description,
                isSubCategory   : req.body.isSubCategory
            };
            new ProductCategory(categoryObj).save(function(err, categoryInfo){
                if(err){
                    callback(constant.messages.requestNotProcessed, null);
                }else{
                    finalResponse.categoryInfo = categoryInfo;
                    callback(null, finalResponse);
                }
            });
        },
    ],function(err, data) {
        if (err)
            res.jsonp(Error(constant.statusCode.error, err, err));
        else {
            res.json(Response(constant.statusCode.ok, constant.messages.categoryAddedSuccessfuly, data,null));
        }
    });
}

/**
 * Function is use to get Category List Admin 
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 26-Apr-2018
 */
function getCategoryListAdmin(req, res) {
    console.log("List Body :: ", req.body);
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    var sorting = utility.getSortObj(req.body);
    // var sorting = req.body.sorting ? req.body.sorting : { _id: -1 };
    var condition = {};
    var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
    if (req.body.searchText) {
        condition.$or = [
            { 'name': new RegExp(searchText, 'gi') },
            { 'categoryId.name': new RegExp(searchText, 'gi') },
        ];
    }
    if (searchText.split('\\s+')[1]) {
        condition.$or = [
            { 'name': new RegExp(searchText.split('\\s+')[0], 'gi') },
            { 'categoryId.name': new RegExp(searchText.split('\\s+')[1], 'gi') }
        ]
    }
    condition.deleted = false;

    var aggregateQuery = [
        {   //Parent Category Details
            $lookup: {
                from: "product_categories",
                localField: "categoryId",
                foreignField: "_id",
                as: "categoryId"
            }
        },
        { $unwind: { path: "$categoryId", preserveNullAndEmptyArrays: true }  },
        {   //Added By Admin Details
            $lookup: {
                from: "users",
                localField: "addedBy",
                foreignField: "_id",
                as: "addedBy"
            }
        },
        { $unwind: { path: "$addedBy", preserveNullAndEmptyArrays: true } },
        { $match: condition },
    ];
    var project = {
        $project: {
            categoryId      : '$categoryId',
            addedBy         : '$addedBy',
            name            : 1,
            description     : 1,
            isSubCategory   : 1,
            status          : 1,
            deleted         : 1,
            createdAt       : 1,
        }
    };

    var countQuery = [].concat(aggregateQuery);
    aggregateQuery.push(project);
    aggregateQuery.push({ $sort: sorting });
    aggregateQuery.push({ $skip: parseInt(skip) });
    aggregateQuery.push({ $limit: parseInt(count) });

    ProductCategory.aggregate(aggregateQuery).then(function(result) {
        var data = {};
        data.data = result;
        countQuery.push({ $group: { _id: null, count: { $sum: 1 } } });
        ProductCategory.aggregate(countQuery).then(function(dataCount) {
            var cnt = (dataCount[0]) ? dataCount[0].count : 0;
            data.totalCount = cnt;
            // res.json({code: 200, message: constant.messages.dataRetrievedSuccess, data: result, totalCount: cnt });
            res.json(Response(constant.statusCode.ok, constant.messages.dataRetrievedSuccess, data));
        });
    }).catch(function(err) {
        console.log("Err :: ", err)
        res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
    });
}

/**
 * Function is use to get Category details by id
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 26-Apr-2018
 */
function getCategoryDetail(req, res) {
    var categoryId = req.body.categoryId;
    ProductCategory.findOne({_id: categoryId}, function(err, categorData){
        if(err){
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        }else{
            if(categorData.deleted == true){
                res.jsonp(Error(constant.statusCode.error, constant.messages.categoryNotFound, {}));
            }else{
                res.json(Response(constant.statusCode.ok, constant.messages.dataRetrievedSuccess, categorData));
            }
        }
    });
}

/**
 * Function is use to update category
 * @access private
 * @return json
 * Created by abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 26-Apr-2018
 */
function updateCategory(req, res){
    console.log("Update Category Body :: ", req.body);
    var categoryId = req.body._id;
    var finalResponse = {};
    waterfall([
        function(callback) {
            User.findOne({ _id : req.body.updatedBy, deleted: false}).lean().exec(function(err, adminInfo) {
                if (err) {
                    callback(err, null);
                } else {
                    finalResponse.adminInfo = adminInfo;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) {
            console.log("finalResponse.adminInfo :: ", finalResponse.adminInfo);
            Permission.findOne({ adminId : finalResponse.adminInfo._id}).lean().exec(function(err, permissionInfo) {
                if (err) {
                    callback(err, null);
                } else {
                    console.log("permissionInfo :: ", permissionInfo);
                    if(permissionInfo.category == true){
                        finalResponse.permissionInfo = permissionInfo;                       
                        callback(null, finalResponse);
                    }else{
                        callback(constant.messages.noPermission, null);
                    }                    
                }
            });
        },
        function(finalResponse, callback) { //status: "1"
            ProductCategory.findOne({_id: categoryId}, function(err, categorData){
                if(err){
                    callback(err, null);
                }else{
                    if(categorData.deleted == false){
                        callback(null, finalResponse);
                    }else{
                        callback(constant.messages.categoryNotFound, null);
                    }
                }
            });
        },
        function(finalResponse, callback){
            ProductCategory.findOne({name: req.body.name, deleted: false}, function(err, oldCategoryData){
                if(err){
                    callback(constant.messages.requestNotProcessed, null);
                }else if(oldCategoryData){
                    if(oldCategoryData.name == req.body.name){
                        callback(null, finalResponse);
                    }else{
                        callback(constant.messages.categoryAlreadyExist, null);
                    }
                }else{
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) { //status: "1"
            var categoryObj = {
                categoryId      : req.body.categoryId,
                updatedBy       : req.body.addedBy,
                name            : req.body.name,
                description     : req.body.description,
                isSubCategory   : req.body.isSubCategory
            };
            ProductCategory.findOneAndUpdate({_id: categoryId}, {$set: categoryObj}, {new: true}, function(err, categoryInfo){
                if(err){
                    callback(err, null);
                }else{
                    finalResponse.categoryInfo = categoryInfo;
                    callback(null, finalResponse);
                }
            });
        },
    ],function(err, data) {
        if (err)
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        else {
            res.json(Response(constant.statusCode.ok, constant.messages.categoryUpdatedSuccessfuly, data,null));
        }
    });
}

/**
 * Function is use to update category status 
 * @access private
 * @return json
 * Created by Abhijit A
 * @smartData Enterprises (I) Ltd
 * Created Date 26-Apr-2018
 */
function changeCategoryStatus(req, res) {
    if (req.body.status == 0 || req.body.status == 1) {
        if (req.body.status == 1) {
            var updateCategoryStatus = { status: 1 };
        } else {
            var updateCategoryStatus = { status: 0 };
        }
        ProductCategory.update({ _id: req.body.categoryId }, { $set: updateCategoryStatus }, function (err) {
            if (err) {
                res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
            } else {
                res.json(Response(constant.statusCode.ok, constant.messages.categoryStatusUpdateSuccess, {}, null));
            }
        });
    } else {
        res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed));
    }
}

/**
 * Function is use to delete Category by Category id
 * @access private
 * @return json
 * Created by Ashwini
 * @smartData Enterprises (I) Ltd
 * Created Date 11-Apr-2017
 */
function deleteCategory(req, res) {
    var id = req.swagger.params.id.value;
    var updateCategoryRecord = { deleted: true }
    ProductCategory.update({ _id: id }, { $set: updateCategoryRecord }, function (err) {
        if (err) {
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        } else {
            res.json(Response(constant.statusCode.ok, constant.messages.categoryDeleteSuccess, {}, null));
        }
    });
}
