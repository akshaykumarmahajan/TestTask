'use strict';

var mongoose = require('mongoose'),
    User = mongoose.model('user'),
        
    Error = require('../lib/error.js'),
    Response = require('../lib/response.js'),
    constant = require('../lib/constants');

    const config = require('../../config/config.js').get(process.env.NODE_ENV);


module.exports = {
    getAdminDashboardCount: getAdminDashboardCount
};



/**
 * Function is use to get Dashboard 
 * @access private
 * @return json
 * Created by ashwini
 * @smartData Enterprises (I) Ltd
 * Created Date 11-Jan-2018
 */
function getAdminDashboardCount(req, res){
    
    var finalResponse = {};
    finalResponse.totalStaff = 0;
    finalResponse.totalProvider = 0;
    finalResponse.totalOrder = 0;
    res.json(Response(constant.statusCode.ok, constant.messages.dataRetrievedSuccess, finalResponse,null));
}

