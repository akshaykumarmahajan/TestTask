'use strict';

var mongoose = require('mongoose'),
    common = require('../../config/common.js'),
    Error = require('../lib/error.js'),
    Response = require('../lib/response.js'),
    utility = require('../lib/utility.js'),
    constant = require('../lib/constants.js'),
    waterfall = require('async-waterfall'),
    async = require('async'),
    User = mongoose.model('user'),
    Permission = mongoose.model('permission'),
    FAQ = mongoose.model('faq');

module.exports = {
    addFaq: addFaq,
    updateFaq: updateFaq,
    getFaqList: getFaqList,
    getFaqDetail: getFaqDetail,
    changeFaqStatus: changeFaqStatus,
    deleteFaq: deleteFaq
};

/**
 * Function is use to add Faq
 * @access private
 * @return json
 * Created by abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 26-Apr-2018
 */
function addFaq(req, res){
    console.log("Add Faq Body :: ", req.body);
    var finalResponse = {};
    waterfall([
        function(callback) {
            User.findOne({ _id : req.body.addedBy, deleted: false}).lean().exec(function(err, adminInfo) {
                if (err) {
                    console.log("User ERR :: ", err);
                    callback(constant.messages.requestNotProcessed, null);
                } else {
                    finalResponse.adminInfo = adminInfo;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) {
            Permission.findOne({ adminId : finalResponse.adminInfo._id}).lean().exec(function(err, permissionInfo) {
                if (err) {
                    console.log("Per ERR :: ", err);
                    callback(constant.messages.requestNotProcessed, null);
                } else {
                    if(permissionInfo.faq == true){
                        finalResponse.permissionInfo = permissionInfo;                       
                        callback(null, finalResponse);
                    }else{
                        callback(constant.messages.noPermission, null);
                    }                    
                }
            });
        },
        function(finalResponse, callback) { //status: "1"
            var FaqObj = {
                addedBy    : req.body.addedBy,
                question   : req.body.question,
                answer     : req.body.answer,
            };
            new FAQ(FaqObj).save(function(err, FaqInfo){
                if(err){
                    console.log("Save ERR :: ", err);
                    callback(constant.messages.requestNotProcessed, null);
                }else{
                    finalResponse.FaqInfo = FaqInfo;
                    callback(null, finalResponse);
                }
            });
        },
    ],function(err, data) {
        if (err)
            res.jsonp(Error(constant.statusCode.error, err, err));
        else {
            res.json(Response(constant.statusCode.ok, constant.messages.faqAddedSuccessfuly, data,null));
        }
    });
}

/**
 * Function is use to get Faq List Admin 
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 26-Apr-2018
 */
function getFaqList(req, res) {
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    var sorting = utility.getSortObj(req.body);
    // var sorting = req.body.sorting ? req.body.sorting : { _id: -1 };
    var condition = {};
    var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
    if (req.body.searchText) {
        condition.$or = [
            { 'question': new RegExp(searchText, 'gi') },
        ];
    }
    if (searchText.split('\\s+')[1]) {
        condition.$or = [
            { 'question': new RegExp(searchText.split('\\s+')[0], 'gi') },
        ]
    }
    condition.deleted = false;
    FAQ.find(condition)
        .limit(parseInt(count))
        .skip(parseInt(skip))
        .sort(sorting)
        .lean()
        .exec(function (err, result) {
            if (err) {
                res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
            } else {
                var data = {};
                data.data = result;
                FAQ.find(condition).count().exec(function (err, totalCount) {
                    if (err) {
                        res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                    } else {
                        data.totalCount = totalCount
                        res.json(Response(constant.statusCode.ok, constant.messages.dataRetrievedSuccess, data, null));
                    }
                })
            }
        })
}

/**
 * Function is use to get Faq details by id
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 26-Apr-2018
 */
function getFaqDetail(req, res) {
    var faqId = req.body.faqId;
    FAQ.findOne({_id: faqId}, function(err, FaqData){
        if(err){
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        }else{
            if(FaqData.deleted == true){
                res.jsonp(Error(constant.statusCode.error, constant.messages.faqNotFound, {}));
            }else{
                res.json(Response(constant.statusCode.ok, constant.messages.dataRetrievedSuccess, FaqData));
            }
        }
    });
}

/**
 * Function is use to update Faq
 * @access private
 * @return json
 * Created by abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 26-Apr-2018
 */
function updateFaq(req, res){
    console.log("Update Faq Body :: ", req.body);
    var faqId = req.body._id;
    var finalResponse = {};
    waterfall([
        function(callback) {
            User.findOne({ _id : req.body.updatedBy, deleted: false}).lean().exec(function(err, adminInfo) {
                if (err) {
                    console.log("1 ERR :: ", err);
                    callback(err, null);
                } else {
                    finalResponse.adminInfo = adminInfo;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) {
            console.log("finalResponse.adminInfo :: ", finalResponse.adminInfo);
            Permission.findOne({ adminId : finalResponse.adminInfo._id}).lean().exec(function(err, permissionInfo) {
                if (err) {
                    console.log("2 ERR :: ", err);
                    callback(err, null);
                } else {
                    console.log("permissionInfo :: ", permissionInfo);
                    if(permissionInfo.faq == true){
                        finalResponse.permissionInfo = permissionInfo;                       
                        callback(null, finalResponse);
                    }else{
                        callback(constant.messages.noPermission, null);
                    }                    
                }
            });
        },
        function(finalResponse, callback) { //status: "1"
            FAQ.findOne({_id: faqId}, function(err, FaqData){
                if(err){
                    console.log("3 ERR :: ", err);
                    callback(err, null);
                }else{
                    if(FaqData.deleted == false){
                        callback(null, finalResponse);
                    }else{
                        callback(constant.messages.faqNotFound, null);
                    }
                }
            });
        },
        function(finalResponse, callback) { //status: "1"
            var FaqObj = {
                updatedBy  : req.body.updatedBy,
                question   : req.body.question,
                answer     : req.body.answer,
            };
            FAQ.findOneAndUpdate({_id: faqId}, {$set: FaqObj}, {new: true}, function(err, FaqInfo){
                if(err){
                    console.log("4 ERR :: ", err);
                    callback(err, null);
                }else{
                    finalResponse.FaqInfo = FaqInfo;
                    callback(null, finalResponse);
                }
            });
        },
    ],function(err, data) {
        if (err)
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        else {
            res.json(Response(constant.statusCode.ok, constant.messages.faqUpdatedSuccessfuly, data,null));
        }
    });
}

/**
 * Function is use to update Faq status 
 * @access private
 * @return json
 * Created by Abhijit A
 * @smartData Enterprises (I) Ltd
 * Created Date 26-Apr-2018
 */
function changeFaqStatus(req, res) {
    if (req.body.status == 0 || req.body.status == 1) {
        if (req.body.status == 1) {
            var updateFaqStatus = { status: 1 };
        } else {
            var updateFaqStatus = { status: 0 };
        }
        FAQ.update({ _id: req.body.faqId }, { $set: updateFaqStatus }, function (err) {
            if (err) {
                res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
            } else {
                res.json(Response(constant.statusCode.ok, constant.messages.faqStatusUpdateSuccess, {}, null));
            }
        });
    } else {
        res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed));
    }
}

/**
 * Function is use to delete Faq by Faq id
 * @access private
 * @return json
 * Created by Ashwini
 * @smartData Enterprises (I) Ltd
 * Created Date 11-Apr-2017
 */
function deleteFaq(req, res) {
    var id = req.swagger.params.id.value;
    var updateFaqRecord = { deleted: true }
    FAQ.update({ _id: id }, { $set: updateFaqRecord }, function (err) {
        if (err) {
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        } else {
            res.json(Response(constant.statusCode.ok, constant.messages.faqDeleteSuccess, {}, null));
        }
    });
}
