'use strict';

var mongoose = require('mongoose'),
    common = require('../../config/common.js'),
    Error = require('../lib/error.js'),
    Response = require('../lib/response.js'),
    utility = require('../lib/utility.js'),
    constant = require('../lib/constants.js'),
    waterfall = require('async-waterfall'),
    async = require('async'),
    User = mongoose.model('user'),
    Permission = mongoose.model('permission'),
    ProductOccasion = mongoose.model('product_occasion');

module.exports = {
    addOccasion: addOccasion,
    updateOccasion: updateOccasion,
    getOccasionList: getOccasionList,
    getOccasionDetail: getOccasionDetail,
    changeOccasionStatus: changeOccasionStatus,
    deleteOccasion: deleteOccasion
};

/**
 * Function is use to add occasion
 * @access private
 * @return json
 * Created by abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 26-Apr-2018
 */
function addOccasion(req, res){
    console.log("Add occasion Body :: ", req.body);
    var finalResponse = {};
    waterfall([
        function(callback) {
            User.findOne({ _id : req.body.addedBy, deleted: false}).lean().exec(function(err, adminInfo) {
                if (err) {
                    console.log("User ERR :: ", err);
                    callback(constant.messages.requestNotProcessed, null);
                } else {
                    finalResponse.adminInfo = adminInfo;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) {
            Permission.findOne({ adminId : finalResponse.adminInfo._id}).lean().exec(function(err, permissionInfo) {
                if (err) {
                    console.log("Per ERR :: ", err);
                    callback(constant.messages.requestNotProcessed, null);
                } else {
                    if(permissionInfo.occasion == true){
                        finalResponse.permissionInfo = permissionInfo;                       
                        callback(null, finalResponse);
                    }else{
                        callback(constant.messages.noPermission, null);
                    }                    
                }
            });
        },
        function(finalResponse, callback){
            ProductOccasion.findOne({name: req.body.name, deleted: false}, function(err, occasionData){
                if(err){
                    console.log("Per1 ERR :: ", err);
                    callback(constant.messages.requestNotProcessed, null);
                }else if(occasionData){
                    callback(constant.messages.occasionAlreadyExist, null);
                }else{
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) { //status: "1"
            var occasionObj = {
                addedBy         : req.body.addedBy,
                name            : req.body.name,
                description     : req.body.description,
            };
            new ProductOccasion(occasionObj).save(function(err, occasionInfo){
                if(err){
                    console.log("Save ERR :: ", err);
                    callback(constant.messages.requestNotProcessed, null);
                }else{
                    finalResponse.occasionInfo = occasionInfo;
                    callback(null, finalResponse);
                }
            });
        },
    ],function(err, data) {
        if (err)
            res.jsonp(Error(constant.statusCode.error, err, err));
        else {
            res.json(Response(constant.statusCode.ok, constant.messages.occasionAddedSuccessfuly, data,null));
        }
    });
}

/**
 * Function is use to get occasion List Admin 
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 26-Apr-2018
 */
function getOccasionList(req, res) {
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    var sorting = utility.getSortObj(req.body);
    // var sorting = req.body.sorting ? req.body.sorting : { _id: -1 };
    var condition = {};
    var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
    if (req.body.searchText) {
        condition.$or = [
            { 'name': new RegExp(searchText, 'gi') },
        ];
    }
    if (searchText.split('\\s+')[1]) {
        condition.$or = [
            { 'name': new RegExp(searchText.split('\\s+')[0], 'gi') },
        ]
    }
    condition.deleted = false;
    ProductOccasion.find(condition)
        .limit(parseInt(count))
        .skip(parseInt(skip))
        .sort(sorting)
        .lean()
        .exec(function (err, result) {
            if (err) {
                res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
            } else {
                var data = {};
                data.data = result;
                ProductOccasion.find(condition).count().exec(function (err, totalCount) {
                    if (err) {
                        res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                    } else {
                        data.totalCount = totalCount
                        res.json(Response(constant.statusCode.ok, constant.messages.dataRetrievedSuccess, data, null));
                    }
                })
            }
        })
}

/**
 * Function is use to get occasion details by id
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 26-Apr-2018
 */
function getOccasionDetail(req, res) {
    var occasionId = req.body.occasionId;
    ProductOccasion.findOne({_id: occasionId}, function(err, occasionData){
        if(err){
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        }else{
            if(occasionData.deleted == true){
                res.jsonp(Error(constant.statusCode.error, constant.messages.occasionNotFound, {}));
            }else{
                res.json(Response(constant.statusCode.ok, constant.messages.dataRetrievedSuccess, occasionData));
            }
        }
    });
}

/**
 * Function is use to update occasion
 * @access private
 * @return json
 * Created by abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 26-Apr-2018
 */
function updateOccasion(req, res){
    console.log("Update occasion Body :: ", req.body);
    var occasionId = req.body._id;
    var finalResponse = {};
    waterfall([
        function(callback) {
            User.findOne({ _id : req.body.updatedBy, deleted: false}).lean().exec(function(err, adminInfo) {
                if (err) {
                    callback(err, null);
                } else {
                    finalResponse.adminInfo = adminInfo;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) {
            console.log("finalResponse.adminInfo :: ", finalResponse.adminInfo);
            Permission.findOne({ adminId : finalResponse.adminInfo._id}).lean().exec(function(err, permissionInfo) {
                if (err) {
                    callback(err, null);
                } else {
                    console.log("permissionInfo :: ", permissionInfo);
                    if(permissionInfo.occasion == true){
                        finalResponse.permissionInfo = permissionInfo;                       
                        callback(null, finalResponse);
                    }else{
                        callback(constant.messages.noPermission, null);
                    }                    
                }
            });
        },
        function(finalResponse, callback) { //status: "1"
            ProductOccasion.findOne({_id: occasionId}, function(err, occasionData){
                if(err){
                    callback(err, null);
                }else{
                    if(occasionData.deleted == false){
                        callback(null, finalResponse);
                    }else{
                        callback(constant.messages.occasionNotFound, null);
                    }
                }
            });
        },
        function(finalResponse, callback){
            ProductOccasion.findOne({name: req.body.name, deleted: false}, function(err, oldOccasionData){
                if(err){
                    callback(constant.messages.requestNotProcessed, null);
                }else if(oldOccasionData){
                    if(oldOccasionData.name == req.body.name){
                        callback(null, finalResponse);
                    }else{
                        callback(constant.messages.occasionAlreadyExist, null);
                    }
                }else{
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) { //status: "1"
            var occasionObj = {
                updatedBy       : req.body.updatedBy,
                name            : req.body.name,
                description     : req.body.description,
            };
            ProductOccasion.findOneAndUpdate({_id: occasionId}, {$set: occasionObj}, {new: true}, function(err, occasionInfo){
                if(err){
                    callback(err, null);
                }else{
                    finalResponse.occasionInfo = occasionInfo;
                    callback(null, finalResponse);
                }
            });
        },
    ],function(err, data) {
        if (err)
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        else {
            res.json(Response(constant.statusCode.ok, constant.messages.occasionUpdatedSuccessfuly, data,null));
        }
    });
}

/**
 * Function is use to update occasion status 
 * @access private
 * @return json
 * Created by Abhijit A
 * @smartData Enterprises (I) Ltd
 * Created Date 26-Apr-2018
 */
function changeOccasionStatus(req, res) {
    if (req.body.status == 0 || req.body.status == 1) {
        if (req.body.status == 1) {
            var updateOccasionStatus = { status: 1 };
        } else {
            var updateOccasionStatus = { status: 0 };
        }
        ProductOccasion.update({ _id: req.body.occasionId }, { $set: updateOccasionStatus }, function (err) {
            if (err) {
                res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
            } else {
                res.json(Response(constant.statusCode.ok, constant.messages.occasionStatusUpdateSuccess, {}, null));
            }
        });
    } else {
        res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed));
    }
}

/**
 * Function is use to delete occasion by occasion id
 * @access private
 * @return json
 * Created by Ashwini
 * @smartData Enterprises (I) Ltd
 * Created Date 11-Apr-2017
 */
function deleteOccasion(req, res) {
    var id = req.swagger.params.id.value;
    var updateOccasionRecord = { deleted: true }
    ProductOccasion.update({ _id: id }, { $set: updateOccasionRecord }, function (err) {
        if (err) {
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        } else {
            res.json(Response(constant.statusCode.ok, constant.messages.occasionDeleteSuccess, {}, null));
        }
    });
}
