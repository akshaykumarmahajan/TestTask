'use strict';
var mongoose = require('mongoose'),
User = mongoose.model('user'),
waterfall = require('async-waterfall'),
utility = require('../lib/utility.js'),
Error = require('../lib/error.js'),
Response = require('../lib/response.js'),
constant = require('../lib/constants');
// const config = require('../../config/config.js').get(process.env.NODE_ENV);
module.exports = {
    getSellerList: getSellerList,
    getSellerDetails:getSellerDetails,
    updateSeller:updateSeller,
    deleteSeller:deleteSeller,
    changeSellerStatus:changeSellerStatus
};

/**
 * Function is use to get seller list by admin 
 * @access private
 * @return json
 * Created by Abhijit A
 * @smartData Enterprises (I) Ltd
 * Created Date 11-Apr-2018
 */
function getSellerList(req, res) {

    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    var sorting = utility.getSortObj(req.body);
    // var sorting = req.body.sorting ? req.body.sorting : { _id: -1 };
    var condition = {};
    var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
    if (req.body.searchText) {
        condition.$or = [
            { 'phone_number': parseInt(searchText) },
            { 'firstname': new RegExp(searchText, 'gi') },
            { 'lastname': new RegExp(searchText, 'gi') },
            { 'email': new RegExp(searchText, 'gi') },
        ];
    }
    if (searchText.split('\\s+')[1]) {
        condition.$or = [
            { 'firstname': new RegExp(searchText.split('\\s+')[0], 'gi') }, 
            { 'lastname': new RegExp(searchText.split('\\s+')[1], 'gi') }
        ]
    }
    condition.deleted = false;
    condition.role = 'Seller';
    User.find(condition)
        .limit(parseInt(count))
        .skip(parseInt(skip))
        .sort(sorting)
        .lean()
        .exec(function (err, result) {
            if (err) {
                res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
            } else {
                var data = {};
                data.data = result;
                User.find(condition).count().exec(function (err, totalCount) {
                    if (err) {
                        res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                    } else {
                        data.totalCount = totalCount
                        res.json(Response(constant.statusCode.ok, constant.messages.dataRetrievedSuccess, data, null));
                    }
                })
            }
        })
}

/**
 * Function is use to get seller details by sellerId 
 * @access private
 * @return json
 * Created by Abhijit A
 * @smartData Enterprises (I) Ltd
 * Created Date 11-Apr-2018
 */
function getSellerDetails(req, res) {
    User.findOne({ _id: req.body.sellerId })
    .lean()
    .exec(function(err, data) {
        if (err) {
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        } else {
            if (!data) {
                res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
            } else {
                console.log(data)
                utility.fileExistCheck('./public/assets/images/users/' + data.profile_pic, function(exist) {
                    if (!exist) {
                        res.json(Response(constant.statusCode.ok, constant.messages.dataRetrievedSuccess, data, null));
                    } else {
                        res.json(Response(constant.statusCode.ok, constant.messages.dataRetrievedSuccess, data, null));
                    }
                });
            }
        }
    });
}

/**
 * Function is use to get seller details by sellerId 
 * @access private
 * @return json
 * Created by Abhijit A
 * @smartData Enterprises (I) Ltd
 * Created Date 11-Apr-2018
 */
function updateSeller(req, res) {
    var finalResponse = {};
    waterfall([
        function(callback) {
            User.find({ email: req.body.email.toLowerCase(), _id: { $ne: req.body._id }, deleted: false }).lean().exec(function(err, sellerData) {
                if (err) {
                    callback(err, false);
                } else {
                    if (sellerData.length > 0) {
                        res.jsonp(Error(constant.statusCode.error, constant.validateMsg.emailAlreadyExist, constant.validateMsg.emailAlreadyExist));
                    } else {
                        User.findById(req.body._id).exec(function(err, data) {
                            if (err) {
                                res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                            } else {
                                finalResponse.sellerData = data;
                                callback(null, finalResponse);
                            }
                        });
                    }
                }
            });
        },
        function(finalResponse, callback) {
            var sellerRecord = {
                username: req.body.firstname + ' ' + req.body.lastname,
                firstname: req.body.firstname,
                lastname: req.body.lastname,
                email: req.body.email.toLowerCase(),
                dob : req.body.dob,
                address_line_1: req.body.address_line_1,
                address_line_2: req.body.address_line_2,
                gender:req.body.gender,
                phone_number: req.body.phone_number,
                zipcode: req.body.zipcode,
                city: req.body.city,
                state: req.body.state,
                country: req.body.country,
                // modifiedBy: req.body.modifiedBy,
                // modifiedById: req.body.modifiedById,
            };
            User.update({ _id: req.body._id }, { $set: sellerRecord }, function(err) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            });
        },
    ], function(err, data) {
        if (err) {
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        } else {
            res.json(Response(constant.statusCode.ok, constant.messages.sellerUpdateSuccess, data, null));
        }
    });
}

/**
 * Function is use to update seller status 
 * @access private
 * @return json
 * Created by Abhijit A
 * @smartData Enterprises (I) Ltd
 * Created Date 11-Apr-2018
 */
function changeSellerStatus(req, res) {
    if (req.body.status == 0 || req.body.status == 1) {
        if (req.body.status == 1) {
            var updateSellerStatus = { status: 1 };
        } else {
            var updateSellerStatus = { status: 0 };
        }
        User.update({ _id: req.body.sellerId }, { $set: updateSellerStatus }, function(err) {
            if (err) {
                res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
            } else {
                res.json(Response(constant.statusCode.ok, constant.messages.sellerStatusUpdateSuccess, {}, null));
            }
        });
    } else {
        res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed));
    }

}

/**
 * Function is use to delete Seller by Seller id
 * @access private
 * @return json
 * Created by Ashwini
 * @smartData Enterprises (I) Ltd
 * Created Date 11-Apr-2017
 */
function deleteSeller(req, res) {
    var id = req.swagger.params.id.value;
    var updateSellerRecord = { deleted: true }
    User.update({ _id: id }, { $set: updateSellerRecord }, function(err) {
        if (err) {
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        } else {
            res.json(Response(constant.statusCode.ok, constant.messages.sellerDeleteSuccess, {}, null));
        }
    });
}