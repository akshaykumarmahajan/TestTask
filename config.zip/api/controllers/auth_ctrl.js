'use strict';

var mongoose = require('mongoose'),
    voucher_codes = require('voucher-code-generator'),
    User = mongoose.model('user'),
    InternalMessages = mongoose.model('internal_message'),
    WishList = mongoose.model('product_wish_list'),
    Setting = mongoose.model('setting'),
    path = require('path'),
    jwt = require('jsonwebtoken'),
    validator = require('validator'),
    utility = require('../lib/utility.js'),
    mailer = require('../lib/mailer.js'),
    waterfall = require('async-waterfall'),
    async = require('async'),
    Error = require('../lib/error.js'),
    Response = require('../lib/response.js'),
    constant = require('../lib/constants'),
    c = require('../helpers/cypher');

const config = require('../../config/config.js').get(process.env.NODE_ENV);
// console.log(utility.getDecryptText('308bc784287f7f50611bb7'));
module.exports = {

    userLogin: userLogin,
    userRegister: userRegister,
    userForgotPassword: userForgotPassword,
    resetPassword: resetPassword,
    uploadImage: uploadImage,
    loggedin: loggedin,
    userActivation: userActivation
};

/**
 * Function is use to check users login status
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 21-July-2017
 */
function loggedin(req, res) {
    // console.log("Here in loggedin",req.headers.authorization.split(' '));
    if (req.headers && req.headers.authorization) { // success callback for the Authentication
        var parts = req.headers.authorization.split(' ');

        if (parts.length == 2) {
            jwt.verify(parts[1], config.secret, function (err, user) {
                if (err) {
                    //res.json(Response(402, constant.messages.authenticationFailed));
                    res.json(Response(constant.statusCode.unauth, constant.messages.authenticationFailed));
                } else {
                    if (user) {
                        User.findById(user.uid, { createdAt: 0, updatedAt: 0, password: 0 })
                            .exec(function(err, admin) {
                                if (err)
                                    res.json(Response(402, constant.messages.authenticationFailed));
                                else if (!admin) {
                                    res.json(Response(402, constant.messages.authenticationFailed));
                                } else {
                                    utility.fileExistCheck('./public/assets/images/users/' + admin.image, function(exist) {
                                        if (!exist) {
                                            admin.image = 'noUser.jpg';
                                            res.json({ "code": 200, status: "OK", user: admin });
                                        } else {
                                            //console.log('admin:- ',admin)
                                            res.json({ "code": 200, status: "OK", user: admin });
                                        }
                                    });
                                }
                                // utility.fileExistCheck('./public/assets/images/users/' + admin.image, function(exist) {
                                //     if (!exist) {
                                //         admin.image = 'noUser.jpg';
                                //         res.json({ "code": 200, status: "OK", user: admin });
                                //     } else {
                                //         //console.log('admin:- ',admin)
                                //         res.json({ "code": 200, status: "OK", user: admin });
                                //     }
                                // });
                            });
                    } else {
                        //res.json(Response(402, constant.messages.authenticationFailed));
                        // console.log('innnnnnnnnnnnnnnnn11')
                        res.json(Response(constant.statusCode.unauth, constant.messages.authenticationFailed));
                    }
                }
            });
        } else {
            // console.log('innnnnnnnnnnnnnnnn22')
            //res.json(Response(402, constant.messages.authenticationFailed));
            res.json(Response(constant.statusCode.unauth, constant.messages.authenticationFailed));
        }
    } else {
        // console.log('innnnnnnnnnnnnnnnn33')
        //res.json(Response(402, constant.messages.authenticationFailed));
        res.json(Response(constant.statusCode.unauth, constant.messages.authenticationFailed));
    }
}


/**
 * Function is use to login user
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 21-July-2017
 */
function userLogin(req, res) {
    //console.log('req.body:- ', req.body)
    if (!req.body.email || !req.body.password) {
        res.jsonp(Error(constant.statusCode.error, constant.messages.requiredFieldsMissing, constant.messages.requiredFieldsMissing));
    } else if (req.body.email && !validator.isEmail(req.body.email)) {
        res.jsonp(Error(constant.statusCode.error, constant.messages.invalidEmail, constant.messages.invalidEmail));
    } else {

        var data = {};
        var jwtToken = null;
        var passEnc = utility.getEncryptText(req.body.password);
        var userData = {
            email: req.body.email.toLowerCase(),
            password: passEnc //req.body.password
        };
        var lastLoginDate = new Date();

        User.findOne(userData, {
            password: 0,
            updatedAt: 0,
            createdAt: 0,
            verifyToken: 0
        }).exec(function (err, userInfo) {
            if (err) {
                res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
            } else {
                if (userInfo != null) {
                    if (userInfo.status == 0) {
                        res.json(Error(constant.statusCode.error, constant.messages.accountNotActivated, null));
                    } else if (userInfo.isDelete) {
                        res.json(Error(constant.statusCode.error, constant.messages.accountDeleted, null));
                    } else {
                        var expirationDuration = 60 * 60 * 24 * 8; // expiration duration format sec:min:hour:day. ie: 8 Hours as per i/p
                        //var expirationDuration = 60; // expiration duration 1 minute
                        var params = {
                            uid: userInfo._id
                        }
                        jwtToken = jwt.sign(params, config.secret, {
                            expiresIn: expirationDuration
                        });
                        userInfo.token = jwtToken;
                        // userInfo.lastLoginDate = new Date();
                        userInfo.save(function (err, userInfoData) {
                            if (err) {
                                res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                            } else {
                                InternalMessages.find({to : userInfoData._id})
                                .count().lean().exec(function(err, messageCount){
                                    if(err){
                                        res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));    
                                    }else{
                                        WishList.find({userId : userInfoData._id, deleted: false})
                                        .count().lean().exec(function(err, wishlistCount){
                                            if(err){
                                                res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                                            }else{
                                                userInfoData.messageCount = messageCount;
                                                userInfoData.wishlistCount = wishlistCount;
                                                res.json(Response(constant.statusCode.ok, constant.messages.loginSuccess, userInfoData, null));
                                            }
                                        })
                                    }
                                });
                            }
                        });
                    }
                } else {
                    res.json(Error(constant.statusCode.error, constant.messages.invalidLoginInput, null));
                }
            }
        });
    }
}


/**
 * Function is use to sign up user account 
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 21-July-2017
 */
 function userRegister(req, res) {
    // console.log('req.body:- ', req.body);

    var finalResponse = {};

    if (!req.body.firstname || !req.body.lastname || !req.body.email || !req.body.password) {
        return res.json(Response(402, constant.validateMsg.requiredFieldsMissing));
    } else if (req.body.email && !validator.isEmail(req.body.email)) {
        return res.json(Response(402, constant.validateMsg.invalidEmail));
    } else {
        waterfall([
            function (callback) { //Check for already exist Email of user
                User.findOne({email: req.body.email}, function (err, emailExist) {
                    // console.log("emailexist", emailExist);
                    if (err) {
                        callback(err, false);
                    } else {
                        if (emailExist) {
                            // finalResponse.isEmailExist = true;
                            res.json(Error(constant.statusCode.error, constant.messages.emailAlreadyExist, null));
                        } else {
                            // finalResponse.isEmailExist = false;  
                            callback(null, finalResponse);
                        }
                    }
                });
            },
            function (finalResponse, callback) { //Save User data
                var code = voucher_codes.generate({
                    prefix: "USR",
                    length: 4,
                    count: 1,
                    charset: "0123456789"
                });
                var date = new Date();
                var verification_token = utility.getEncryptText(Math.random().toString(4).slice(2) + date.getTime());
                var obj = {
                    firstname: req.body.firstname,
                    lastname: req.body.lastname,
                    username: req.body.firstname + ' ' + req.body.lastname,
                    email: req.body.email.toLowerCase(),
                    password: utility.getEncryptText(req.body.password),
                    verification_token: verification_token,
                    uniqueId: code[0]
                };
                
                // console.log('obj:- ', obj);

                var userRecord = new User(obj);
                userRecord.save(function (err, userData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.userData = userData;
                        callback(null, finalResponse);
                    }
                });
            },
            function (finalResponse, callback) { //Send Email to User for verify Account
                var mailData = {
                    userId: finalResponse.userData._id,
                    email: finalResponse.userData.email,
                    firstname: finalResponse.userData.firstname,
                    lastname: finalResponse.userData.lastname,
                    username: finalResponse.userData.username,
                    id: finalResponse.userData.verification_token,
                };
                mailer.sendMail(mailData.email, constant.emailKeyword.registration, mailData, function (err, resp) {
                    if (err) {
                        callback(err, false);
                    } else {
                        callback(null, finalResponse);
                    }
                });
            },
        ], function (err, data) {
            if (err) {
                res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
            } else {
                res.json(Response(constant.statusCode.ok, constant.messages.signupSuccess, data, null));
            }
        });
    }
}
/*function userRegister(req, res) {
    //console.log('req.body:- ', req.body);

    var finalResponse = {};

    if (!req.body.firstname || !req.body.lastname || !req.body.email || !req.body.password) {
        return res.json(Response(402, constant.validateMsg.requiredFieldsMissing));
    } else if (req.body.email && !validator.isEmail(req.body.email)) {
        return res.json(Response(402, constant.validateMsg.invalidEmail));
    } else {
        waterfall([
            function (finalResponse, callback) { //Check for already exist Email of user
                User.findOne({email: req.body.email}, function (err, emailExist) {
                    if (err) {
                        callback(err, false);
                    } else {
                        if (emailExist) {
                            finalResponse.isEmailExist = true;
                            res.json(Error(constant.statusCode.error, constant.messages.emailAlreadyExist, null));
                        } else {
                            finalResponse.isEmailExist = false;
                            callback(null, finalResponse);
                        }
                    }
                });
            },
            function (finalResponse, callback) { //Save User data
                var code = voucher_codes.generate({
                    prefix: "USR",
                    length: 4,
                    count: 1,
                    charset: "0123456789"
                });
                var verification_token = utility.getEncryptText(Math.random().toString(4).slice(2) + date.getTime());
                var obj = {
                    firstname: req.body.firstname,
                    lastname: req.body.lastname,
                    username: req.body.firstname + ' ' + req.body.lastname,
                    phoneNumber: req.body.phoneNumber,
                    email: req.body.email.toLowerCase(),
                    password: utility.getEncryptText(req.body.password),
                    verification_token: verification_token,
                    uniqueId: code[0]
                };
                
                console.log('obj:- ', obj);

                var userRecord = new User(obj);
                userRecord.save(function (err, userData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.userData = userData;
                        callback(null, finalResponse);
                    }
                });
            },
            function (finalResponse, callback) { //Send Email to User for verify Account
                var mailData = {
                    userId: finalResponse.userData._id,
                    email: finalResponse.userData.email,
                    firstname: finalResponse.userData.firstname,
                    lastname: finalResponse.userData.lastname,
                    username: finalResponse.userData.username,
                };
                mailer.sendMail(mailData.email, constant.emailKeyword.registration, mailData, function (err, resp) {
                    if (err) {
                        callback(err, false);
                    } else {
                        callback(null, finalResponse);
                    }
                });
            },
        ], function (err, data) {
            if (err) {
                res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
            } else {
                res.json(Response(constant.statusCode.ok, constant.messages.signupSuccess, data, null));
            }
        });
    }
}*/

/**
 * Forgot passsword
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 12-Aprl-2017
 */
function userForgotPassword(req, res) {
    // console.log("*********", req.body);
    if (validator.isNull(req.body.email)) {
        res.json(Error(constant.statusCode.error, constant.validateMsg.requiredFieldsMissing, constant.validateMsg.requiredFieldsMissing));
    } else if (req.body.email && !validator.isEmail(req.body.email)) {
        res.json(Error(constant.statusCode.error, constant.validateMsg.invalidEmail, constant.validateMsg.invalidEmail));
    } else {
        var model = User;
        var where = {
            email: req.body.email
        };
        model.findOne(where).exec(function (err, userInfoData) {
            if (err) {
                res.json(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
            } else {
                if (!userInfoData) {
                    res.json(Error(constant.statusCode.error, constant.messages.emailNotExist, constant.messages.emailNotExist));
                } else {
                    if (userInfoData.status == 0) {
                        res.json(Error(constant.statusCode.error, constant.messages.userNotactivated, constant.messages.userNotactivated));
                    } else if (userInfoData.deleted) {
                        res.json(Error(constant.statusCode.error, constant.messages.userAccountdeleted, constant.messages.userAccountdeleted));
                    } else {
                        var query = {
                            _id: userInfoData._id
                        };
                        var data = {
                            reset_key: ''
                        }
                        data.reset_key = c.uuid.v1();
                        User.findOneAndUpdate(query, data, function (err, result) {
                            if (result) {
                                var baseUrl = config.baseUrl;
                                var userMailData = {
                                    userId: userInfoData._id,
                                    email: userInfoData.email,
                                    firstname: userInfoData.firstname,
                                    lastname: userInfoData.lastname,
                                    password: utility.getDecryptText(userInfoData.password),
                                    link: baseUrl + '#/reset-password/' + data.reset_key
                                };
                                mailer.sendMail(userInfoData.email, constant.emailKeyword.forgotPassword, userMailData, function (err, resp) {
                                    if (err) {
                                        res.json(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                                    } else {
                                        res.json(Response(constant.statusCode.ok, constant.messages.forgotPasswordSuccess, {}, null));
                                    }
                                });
                            }
                        });
                    }
                }
            }
        });
    }
}

/**
 * Reset Password
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 03-May-2017
 */
function resetPassword(req, res) {
    // var data = req.body,
        // old_password = utility.getEncryptText(req.body.old_password);
        var old_password = utility.getEncryptText(req.body.old_password);
    // var resetKey = data.reset_key;
    try {
        var password = utility.getEncryptText(req.body.password);
        // data.password = utility.getEncryptText(req.body.password);
        // var query = {
        //     '_id': data.userId,
        //     'password': data.old_password
        // };
        User.findOneAndUpdate({'_id': req.body.userId, 'password': old_password}, {password: password}, {
            new: true
        }, function (err, user) {
            if (err) {
                res.json(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
            } else if (!user) {
                res.json(Response(constant.statusCode.error, constant.messages.resetPasswordNotMatch, {}, null));
            } else {
                res.json(Response(constant.statusCode.ok, constant.messages.resetPasswordSuccess, {}, null));
            }
        });
    } catch (err) {
        res.json(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
    }
}


/**
 * Function is use to update user profile pic
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 16-Jan-2017
 */
function uploadImage(req, res) {
    var timestamp = Number(new Date()); // current time as number
    var file = req.swagger.params.file.value;
    var userId = req.swagger.params.id.value;
    var splitFileName = file.originalname.split('.');
    var ext = splitFileName[splitFileName.length - 1].toLowerCase();
    var filename = userId + '_' + timestamp + '.' + ext;
    var imagePath = "./public/assets/images/users/" + filename;
    User.findOne({
        _id: userId
    }, function (err, userData) {
        if (err) {
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        } else if (userData) {
            utility.fileUpload(path.resolve(imagePath), file.buffer).then(function () {
                var UserImage = {
                    image: filename
                };
                User.findOneAndUpdate({
                    _id: userId
                }, {
                    $set: UserImage
                }, {
                    new: true
                }, function (err, updateUserData) {
                    if (err) {
                        res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                    } else {
                        res.json(Response(constant.statusCode.ok, constant.messages.imageUpdateSuccess, updateUserData, null));
                    }
                });
            }).catch(function (err) {
                res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
            });
        } else {
            res.jsonp(Error(constant.statusCode.error, constant.messages.userNotFound, constant.messages.userNotFound));
        }
    });
}

/**
 * Function is use to activate user account
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 21-Mar-2018
 */
function userActivation(req, res) {
    var userToken = req.swagger.params.id.value;
    User.findOne({
        verification_token: userToken
    }, function(err, user) {
        if (err || !user) {
            res.jsonp(Error(constant.statusCode.error, constant.messages.userNotFound, constant.messages.userNotFound));
        } else {
            if(user.status == 1){
                res.jsonp(Error(constant.statusCode.ok, constant.messages.userAlreadyActivated, constant.messages.userNotFound));
            }else{
                user.status = 1;
                // user.verification_token = null;
                user.save(function(err, data) {
                    if (err){
                        res.jsonp(Error(constant.statusCode.error, constant.messages.userNotFound, constant.messages.userNotFound));
                    }
                    else {
                        res.json(Response(constant.statusCode.ok, constant.messages.userActivationSuccess, data, null));
                    }
                });
            }
        }

    })
}