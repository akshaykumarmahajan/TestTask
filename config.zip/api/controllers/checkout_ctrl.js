'use strict';

var mongoose = require('mongoose'),
    common = require('../../config/common.js'),
    Error = require('../lib/error.js'),
    Response = require('../lib/response.js'),
    constant = require('../lib/constants.js'),
    waterfall = require('async-waterfall'),
    async = require('async'),
    ShippingAddress = mongoose.model('shipping_address'),
    Setting = mongoose.model('setting'),
    Product = mongoose.model('product'),
    User = mongoose.model('user');

module.exports = {
    getCheckoutDetails: getCheckoutDetails,
    getShippingCostDetails: getShippingCostDetails,
    shippingAddress: shippingAddress
};



/**
 * Function is use to get product & setting details for checkout page 
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 29-Mar-2018
 */
function getCheckoutDetails(req, res){
    // console.log("Checkout Req Body :: ", req.body);
    var finalResponse = {};
    var productId = req.body.productId,
        userId = req.body.userId;

    waterfall([
        function(callback) {
            User.findOne({ _id: userId, deleted: false}).lean().exec(function(err, userInfo) {
                if (err) {
                    callback(constant.messages.userAccountdeleted, null);
                } else {
                    if(userInfo.status == 0){
                        callback(constant.messages.userNotactivated, null);
                    }else{
                        finalResponse.userInfo = userInfo;
                        callback(null, finalResponse);
                    }
                }
            });
        },
        function(finalResponse, callback) {
            Product.findOne({ _id: productId, deleted: false})
            .populate('featuredImageId')
            .populate('currency')
            .populate('sizeId')
            .populate('sellerId')
            .lean().exec(function(err, productInfo) {
                if (err) {
                    callback(constant.messages.productNotFound, null);
                } else {
                    finalResponse.productInfo = productInfo;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) { //status: "1"
            Setting.findOne({deleted: false}).lean().exec(function(err, settingInfo) {
                if (err) {
                    callback(constant.messages.requestNotProcessed, null);
                } else {
                    finalResponse.settingInfo = settingInfo;
                   callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) { //Find shipping address info with limit of 2
            ShippingAddress.find({ userId: userId, deleted: false}).sort({'createdAt': -1}).limit(2).lean().exec(function(err, shippingAddressInfo) {
                if (err) {
                    callback(constant.messages.requestNotProcessed, null);
                } else {
                    finalResponse.shippingAddressInfo = shippingAddressInfo;
                   callback(null, finalResponse);
                }
            });
        },
    ],function(err, data) {
        if (err)
            res.jsonp(Error(constant.statusCode.error, err, err));
        else {
            res.json(Response(constant.statusCode.ok, constant.messages.dataRetrievedSuccess, data, null));
        }
    });
}

/**
 * Function is use to get product, setting & shipping cost details for checkout page 2 
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 11-Apr-2018
 */
function getShippingCostDetails(req, res){
    console.log("Checkout Req Body :: ", req.body);
    var finalResponse = {};
    var productId = req.body.productId,
        userId = req.body.userId;

    waterfall([
        function(callback) {
            User.findOne({ _id: userId, deleted: false}).lean().exec(function(err, userInfo) {
                if (err) {
                    callback(constant.messages.userAccountdeleted, null);
                } else {
                    if(userInfo.status == 0){
                        callback(constant.messages.userNotactivated, null);
                    }else{
                        finalResponse.userInfo = userInfo;
                        callback(null, finalResponse);
                    }
                }
            });
        },
        function(finalResponse, callback) {
            Product.findOne({ _id: productId, deleted: false})
            .populate('featuredImageId')
            .populate('currency')
            .populate('sizeId')
            .populate('sellerId')
            .lean().exec(function(err, productInfo) {
                if (err) {
                    callback(constant.messages.productNotFound, null);
                } else {
                    finalResponse.productInfo = productInfo;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) { //status: "1"
            Setting.findOne({deleted: false}).lean().exec(function(err, settingInfo) {
                if (err) {
                    callback(constant.messages.requestNotProcessed, null);
                } else {
                    finalResponse.settingInfo = settingInfo;
                   callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) { //Shipping API for shipping cost details
            finalResponse.shippingInfo = {};
            callback(null, finalResponse);
        },
        function(finalResponse, callback) { //Shipping API for shipping cost details
            var total_cost = 0, processing_fees = 0, commision = 0, shipping_amount = 0;
            // processing_fees = finalResponse.settingInfo.processing_fees;
            // commision = ((finalResponse.settingInfo.commision * finalResponse.productInfo.price) / 100);
            // shipping_amount = finalResponse.shippingInfo.price;
            // total_cost = processing_fees + commision + shipping_amount;

            var totalCostObj = {
                // total_amount        : total_cost,
                total_amount        : finalResponse.productInfo.price,
                processing_fees     : processing_fees,
                commision           : commision,
                shipping_amount     : shipping_amount
            };
            finalResponse.totalCostObj = totalCostObj;
            callback(null, finalResponse);
        },
        function(finalResponse, callback) { //Shipping API for shipping cost details
            Product.findOneAndUpdate({_id: productId}, {$set: {product_status : 'Out of Stock', quantity: 0}}, {new: true}, function(err, productInfo){
                if(err){
                    callback(constant.messages.requestNotProcessed, null);
                }else{
                    finalResponse.productInfo = productInfo;
                    callback(null, finalResponse);
                }
            });
        }
    ],function(err, data) {
        if (err)
            res.jsonp(Error(constant.statusCode.error, err, err));
        else {
            res.json(Response(constant.statusCode.ok, constant.messages.dataRetrievedSuccess, data, null));
        }
    });
}

/**
 * Function is use to Add shipping Address
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 29-Mar-2018
 */
function shippingAddress(req, res){
    // console.log("Shipping Address Req Body :: ", req.body);
    var finalResponse = {};
    var productId = req.body.productId,
        userId = req.body.userId;

    waterfall([
        function(callback) {
            User.findOne({ _id: userId, deleted: false}).lean().exec(function(err, userInfo) {
                if (err) {
                    callback(constant.messages.userAccountdeleted, null);
                } else {
                    if(userInfo.status == 0){
                        callback(constant.messages.userNotactivated, null);
                    }else{
                        finalResponse.userInfo = userInfo;
                        callback(null, finalResponse);
                    }
                }
            });
        },
        function(finalResponse, callback) {
            Product.findOne({ _id: productId, deleted: false})
            .lean().exec(function(err, productInfo) {
                if (err) {
                    callback(constant.messages.productNotFound, null);
                } else {
                    finalResponse.productInfo = productInfo;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) { //status: "1"
            var shippingAdd = {
                firstname : req.body.firstname,
                lastname : req.body.lastname,
                country : req.body.country,
                address_line_1 : req.body.address_line_1,
                city : req.body.city,
                state : req.body.state,
                zipcode : req.body.zipcode,
                pnhone_number : req.body.pnhone_number,
                productId : req.body.productId,
                userId : req.body.userId
            };
            if(req.body.address_line_2){
                shippingAdd.address_line_1 = req.body.address_line_1;
            }
            var shippingAddressRecors = new ShippingAddress(shippingAdd);
            shippingAddressRecors.save(function(err, shippingInfo){
                if(err){
                    callback(constant.messages.requestNotProcessed, null);
                }else{
                    finalResponse.shippingInfo = shippingInfo;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) {
            var userObj = {
                shipping_address_1 : finalResponse.shippingInfo._id
            };
            User.findOneAndUpdate({_id: userId}, {$set: userObj}, {new: true}, function(err, userData){
                if(err){
                    callback(constant.messages.requestNotProcessed, null);
                }else{
                    finalResponse.userInfo = userData;
                    callback(null, finalResponse);
                }
            });
        },
    ],function(err, data) {
        if (err)
            res.jsonp(Error(constant.statusCode.error, err, err));
        else {
            res.json(Response(constant.statusCode.ok, constant.messages.shippingAddressAddedSuccess, data, null));
        }
    });
}
