'use strict';

var mongoose = require('mongoose'),
    Error = require('../lib/error.js'),
    Response = require('../lib/response.js'),
    constant = require('../lib/constants.js'),
    Currency = mongoose.model('currency'),
    waterfall = require('async-waterfall'),
    async = require('async'),
    fs = require('fs-extra'),
    path = require('path'),
    Product = mongoose.model('product'),
    ProductCondition = mongoose.model('product_condition'),
    ProductCategory = mongoose.model('product_category'),
    ProductImage = mongoose.model('product_image'),
    ProductColor = mongoose.model('product_color'),
    ProductSize = mongoose.model('product_size'),
    ProductWishList = mongoose.model('product_wish_list'),
    InternalMessage = mongoose.model('internal_message'),
    Notification = mongoose.model('notification'),
    ProductOccasion = mongoose.model('product_occasion');

module.exports = {
    getProductParams: getProductParams,
    saveProductImage: saveProductImage,
    updateProductImage: updateProductImage,
    getProductFilters: getProductFilters,
    getHeaderCount: getHeaderCount
    // saveProfileImage: saveProfileImage
};



/**
 * Function is use to get Product Params
 * @access private
 * @return json
 * Created by Abhijit Agrawal
 * @smartData Enterprises (I) Ltd
 * Created Date 12-03-2018
 */
function getProductParams(req, res){
    var finalResponse = {};
    waterfall([
        function(callback) {
            Currency.find({deleted: false, status: 1}, function(err, currencyList){
                if(err){
                    callback(err, null);
                }else{
                    finalResponse.currencyList = currencyList;
                    callback(null, finalResponse);
                }
            }).sort({country: 1});
        },
        function(finalResponse, callback){
            ProductColor.find({deleted: false, status: 1}, function(err, coloursList){
                if(err){
                    callback(err, null);
                }else{
                    finalResponse.coloursList = coloursList;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback){
            ProductSize.find({deleted: false, status: 1}, function(err, sizeList){
                if(err){
                    callback(err, null);
                }else{
                    finalResponse.sizeList = sizeList;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback){
            ProductCategory.find({deleted: false, status: 1}, function(err, categoryList){
                if(err){
                    callback(err, null);
                }else{
                    finalResponse.categoryList = categoryList;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback){
            ProductCondition.find({deleted: false, status: 1}, function(err, conditionList){
                if(err){
                    callback(err, null);
                }else{
                    finalResponse.conditionList = conditionList;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback){
            ProductOccasion.find({deleted: false, status: 1}, function(err, occasionList){
                if(err){
                    callback(err, null);
                }else{
                    finalResponse.occasionList = occasionList;
                    callback(null, finalResponse);
                }
            });
        },
    ],function(err, data) {
        if (err)
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        else {
            res.json(Response(constant.statusCode.ok, constant.messages.imageUpdateSuccess, finalResponse,null));
        }
    });
}

/**
 * Function is use to save product images
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 13-03-2018
 */
function saveProductImage(req, res) {
    var timestamp = Number(new Date()); // current time as number
    var file = req.swagger.params.file.value;
    var addedBy = req.swagger.params.addedBy.value;
    var productId = req.swagger.params.id.value;
    var key = req.swagger.params.key.value;
    
    var splitFileName = file.originalname.split('.');
    var ext = splitFileName[splitFileName.length - 1].toLowerCase();
    var filename = productId + '_' + timestamp + '.' + ext;
    var imagePath = "./public/assets/images/product/" + filename;
    console.log("Image Key :: ", key);
    fs.writeFile(path.resolve(imagePath), file.buffer, function(err) {
        if (err) {
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        } else {
            var productImage = {
                productId : productId,
                addedBy : addedBy,
                image_url: filename
            };
            if(key == 0){
                productImage.is_featured = true;
            }else{
                productImage.is_featured = false;
            }
            console.log("Product Imgae : ", productImage);
            var imageRecord = new ProductImage(productImage);
            imageRecord.save(function (err, imageData) {
                if (err)
                    res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                else {
                    if(key == 0){
                        Product.findOneAndUpdate({_id: productId}, {$set: {featuredImageId: imageData._id}}, {new: true}, function(err, productInfo){
                            if(err){
                                res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                            }else{
                                res.json(Response(constant.statusCode.ok, constant.messages.imageUpdateSuccess, constant.messages.imageUpdateSuccess,null));
                            }
                        });
                    }else{
                        res.json(Response(constant.statusCode.ok, constant.messages.imageUpdateSuccess, constant.messages.imageUpdateSuccess,null));
                    }
                }
            });
        }
    });
}

// function saveProfileImage(req, res) {
//     var timestamp = Number(new Date()); // current time as number
//     var file = req.swagger.params.file.value;
//     var addedBy = req.swagger.params.addedBy.value;
//     var productId = req.swagger.params.id.value;
//     var key = req.swagger.params.key.value;
    
//     var splitFileName = file.originalname.split('.');
//     var ext = splitFileName[splitFileName.length - 1].toLowerCase();
//     var filename = productId + '_' + timestamp + '.' + ext;
//     var imagePath = "./public/assets/images/product/" + filename;
//     console.log("Image Key :: ", key);
//     fs.writeFile(path.resolve(imagePath), file.buffer, function(err) {
//         if (err) {
//             res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
//         } else {
//             var productImage = {
//                 productId : productId,
//                 addedBy : addedBy,
//                 image_url: filename
//             };
//             if(key == 0){
//                 productImage.is_featured = true;
//             }else{
//                 productImage.is_featured = false;
//             }
//             console.log("Product Imgae : ", productImage);
//             var imageRecord = new ProductImage(productImage);
//             imageRecord.save(function (err, imageData) {
//                 if (err)
//                     res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
//                 else {
//                     if(key == 0){
//                         Product.findOneAndUpdate({_id: productId}, {$set: {featuredImageId: imageData._id}}, {new: true}, function(err, productInfo){
//                             if(err){
//                                 res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
//                             }else{
//                                 res.json(Response(constant.statusCode.ok, constant.messages.imageUpdateSuccess, constant.messages.imageUpdateSuccess,null));
//                             }
//                         });
//                     }else{
//                         res.json(Response(constant.statusCode.ok, constant.messages.imageUpdateSuccess, constant.messages.imageUpdateSuccess,null));
//                     }
//                 }
//             });
//         }
//     });
// }

function saveProductImage_old(req, res) {
    var timestamp = Number(new Date()); // current time as number
    var file = req.swagger.params.file.value;
    var addedBy = req.swagger.params.addedBy.value;
    var productId = req.swagger.params.id.value;
    // var is_featured = req.swagger.params.is_featured.value;   

    var finalResponse = {};
    var file_1 = '';
    var file_2 = '';
    var file_3 = '';
    if(req.swagger.params.file_1.value){file_1 = req.swagger.params.file_1.value;}
    if(req.swagger.params.file_2.value){file_2 = req.swagger.params.file_2.value;}
    if(req.swagger.params.file_3.value){file_3 = req.swagger.params.file_3.value;}
    waterfall([
        function(callback) {
            var splitFileName = file.originalname.split('.');
            var ext = splitFileName[splitFileName.length - 1].toLowerCase();
            var filename = productId + '_' + timestamp + '.' + ext;
            var imagePath = "./public/assets/images/product/" + filename;
            fs.writeFile(path.resolve(imagePath), file.buffer, function(err) {
                if (err) {
                    res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                } else {
                    var productImage = {
                        productId : productId,
                        addedBy : addedBy,
                        image_url: filename,
                        is_featured: true
                    };
                    var imageRecord = new ProductImage(productImage);
                    imageRecord.save(function (err, imageData) {
                        if (err) {
                            callback(err, null);
                        } else {
                            callback(null, constant.messages.imageUpdateSuccess);
                        }
                    });
                }
            });  
        },function(finalResponse, callback) {
            if(file_1 != ''){
                var splitFileName = file_1.originalname.split('.');
                var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                var filename = productId + '_' + timestamp + '.' + ext;
                var imagePath = "./public/assets/images/product/" + filename;
                fs.writeFile(path.resolve(imagePath), file_1.buffer, function(err) {
                    if (err) {
                        res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                    } else {
                        var productImage = {
                            productId : productId,
                            addedBy : addedBy,
                            image_url: filename,
                            is_featured: false
                        };
                        var imageRecord = new ProductImage(productImage);
                        imageRecord.save(function (err, imageData) {
                            if (err) {
                                callback(err, null);
                            } else {
                                callback(null, true);
                            }
                        });
                    }
                });
            }else{
                callback(null, true);
            }
        },function(finalResponse,callback) {
            if(file_2 != ''){
                var splitFileName = file_2.originalname.split('.');
                var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                var filename = productId + '_' + timestamp + '.' + ext;
                var imagePath = "./public/assets/images/product/" + filename;
                fs.writeFile(path.resolve(imagePath), file_2.buffer, function(err) {
                    if (err) {
                        res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                    } else {
                        var productImage = {
                            productId : productId,
                            addedBy : addedBy,
                            image_url: filename,
                            is_featured: false
                        };
                        var imageRecord = new ProductImage(productImage);
                        imageRecord.save(function (err, imageData) {
                            if (err) {
                                callback(err, null);
                            } else {
                                callback(null, true);
                            }
                        });
                    }
                });
            }else{
                callback(null, true);
            }
        },function(finalResponse,callback) {
            if(file_3 != ''){
                var splitFileName = file_3.originalname.split('.');
                var ext = splitFileName[splitFileName.length - 1].toLowerCase();
                var filename = productId + '_' + timestamp + '.' + ext;
                var imagePath = "./public/assets/images/product/" + filename;
                fs.writeFile(path.resolve(imagePath), file_3.buffer, function(err) {
                    if (err) {
                        res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                    } else {
                        var productImage = {
                            productId : productId,
                            addedBy : addedBy,
                            image_url: filename,
                            is_featured: false
                        };
                        var imageRecord = new ProductImage(productImage);
                        imageRecord.save(function (err, imageData) {
                            if (err) {
                                callback(err, null);
                            } else {
                                callback(null, true);
                            }
                        });
                    }
                });
            }else{
                callback(null, true);
            }
        },
    ],function(err, data) {
        if (err)
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        else {
            res.json(Response(constant.statusCode.ok, constant.messages.imageUpdateSuccess, constant.messages.imageUpdateSuccess,null));
        }
    });
}

/**
 * Function is use to Update Product List
 * @access private
 * @return json
 * Created by Abhijit Agrawal
 * @smartData Enterprises (I) Ltd
 * Created Date 15-03-2018
 */
function updateProductImage(req, res) {
    var timestamp = Number(new Date()); // current time as number
    var file = req.swagger.params.file.value;
    var addedBy = req.swagger.params.addedBy.value;
    var imageId = req.swagger.params.id.value;

    var splitFileName = file_3.originalname.split('.');
    var ext = splitFileName[splitFileName.length - 1].toLowerCase();
    var filename = productId + '_' + timestamp + '.' + ext;
    var imagePath = "./public/assets/images/product/" + filename;
    ProductImage.findOne({ _id: imageId }, function(err, imageData) {
        if (err) {
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        } else if (imageData) {
            fs.writeFile(path.resolve(imagePath), file.buffer, function(err) {
                if (err) {
                    res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                } else {
                    var productImage = {
                        image_url: filename
                    };
                    ProductImage.update({ _id: imageId }, { $set: productImage }, function(err) {
                        if (err) {
                            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                        } else {
                            if (imageData.image_url != 'noUser.jpg') {
                                var filePath = __dirname + '/../../public/assets/images/product/' + imageData.image_url;
                                fs.exists(filePath, function(exists) {
                                    if (exists) {
                                        fs.unlink(filePath, function(err) {
                                            if (err) {
                                                res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                                            } else {
                                                res.json(Response(constant.statusCode.ok, constant.messages.imageUpdateSuccess, constant.messages.imageUpdateSuccess, null));
                                            }
                                        });
                                    } else {
                                        res.json(Response(constant.statusCode.ok, constant.messages.imageUpdateSuccess, constant.messages.imageUpdateSuccess, null));
                                    }
                                });
                            }
                        }
                    });
                }
            });
        } else {
            res.jsonp(Error(constant.statusCode.error, constant.messages.userNotFound, constant.messages.userNotFound));
        }
    }); //findOne end
}

function getProductFilters(req, res){
    var finalResponse = {};
    waterfall([
        function(callback){
            ProductColor.find({deleted: false, status: 1}, function(err, coloursList){
                if(err){
                    callback(err, null);
                }else{
                    finalResponse.coloursList = coloursList;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback){
            ProductSize.find({deleted: false, status: 1}, function(err, sizeList){
                if(err){
                    callback(err, null);
                }else{
                    finalResponse.sizeList = sizeList;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback){
            ProductCategory.find({deleted: false, status: 1}, function(err, categoryList){
                if(err){
                    callback(err, null);
                }else{
                    finalResponse.categoryList = categoryList;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback){
            ProductCondition.find({deleted: false, status: 1}, function(err, conditionList){
                if(err){
                    callback(err, null);
                }else{
                    finalResponse.conditionList = conditionList;
                    callback(null, finalResponse);
                }
            });
        },
    ],function(err, data) {
        if (err)
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        else {
            res.json(Response(constant.statusCode.ok, constant.messages.imageUpdateSuccess, finalResponse,null));
        }
    });
}

function getHeaderCount(req, res){
    console.log("8888888888");
    var userId = req.swagger.params.id.value;
    var finalResponse = {};
    waterfall([
        function(callback){ //Wish List Count By User ID
            ProductWishList.find({deleted: false, userId: userId})
            .count()
            .lean()
            .exec(function(err, wishlistCount){
                if(err){
                    callback(err, null);
                }else{
                    finalResponse.wishlistCount = wishlistCount;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback){
            Notification.find({isRead: false, notifyType: 'Message', destnationUser: userId})
            .count()
            .lean()
            .exec(function(err, messageCount){
                if(err){
                    callback(err, null);
                }else{
                    finalResponse.messageCount = messageCount;
                    callback(null, finalResponse);
                }
            });
        },
    ],function(err, data) {
        if (err)
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        else {
            res.json(Response(constant.statusCode.ok, constant.messages.successRetreivingData, finalResponse, null));
        }
    });
}