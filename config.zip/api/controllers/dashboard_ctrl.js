'use strict';

var mongoose = require('mongoose'),
    common = require('../../config/common.js'),
    Error = require('../lib/error.js'),
    Response = require('../lib/response.js'),
    constant = require('../lib/constants.js'),
    waterfall = require('async-waterfall'),
    async = require('async'),
    User = mongoose.model('user');

module.exports = {
    getDashboardCount: getDashboardCount
};



/**
 * Function is use to get Dashboard 
 * @access private
 * @return json
 * Created by ashwini
 * @smartData Enterprises (I) Ltd
 * Created Date 10-Aug-2017
 */
function getDashboardCount(req, res){
    
    var finalResponse = {};

    waterfall([
        function(callback) {
            User.find({ userType : "staff", deleted: false}).count().lean().exec(function(err, totalStaff) {
                if (err) {
                    callback(err, null);
                } else {
                    finalResponse.totalStaff = totalStaff;                       
                   callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) {
            User.find({ userType : "user", deleted: false}).count().lean().exec(function(err, totalCustomer) {
                if (err) {
                    callback(err, null);
                } else {
                    finalResponse.totalCustomer = totalCustomer;                       
                   callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) { //status: "1"
            User.find({ userType : "provider", deleted: false}).count().lean().exec(function(err, totalProvider) {
                if (err) {
                    callback(err, null);
                } else {
                    finalResponse.totalProvider = totalProvider;                       
                   callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) { //status: "1"
            User.find({deleted: false, userType:'user'},'firstname lastname image createdAt')
            .sort({ createdAt: -1 })
            .lean()
            .limit(8)
            .exec(function(err, totalUserRecord) {
                if (err) {
                    callback(err, null);
                } else {
                    finalResponse.totalUserRecord = totalUserRecord;                       
                   callback(null, finalResponse);
                }
            });
        },
    ],function(err, data) {
        if (err)
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        else {
            res.json(Response(constant.statusCode.ok, constant.messages.dataRetrievedSuccess, data,null));
        }
    });
}

