'use strict';

var mongoose = require('mongoose'),
    Permission = mongoose.model('permission'),
    utility = require('../lib/utility.js'),
    common = require('../../config/common.js'),
    Error = require('../lib/error.js'),
    Response = require('../lib/response.js'),
    constant = require('../lib/constants.js');


module.exports = {
    getPermissionById: getPermissionById
};

/**
 * Function is use to get Permission 
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 06-Sep-2017
 */
function getPermissionById(req, res) {
    var id = req.swagger.params.id.value;
    Permission.findOne({ adminId: id })
        .lean()
        .exec(function(err, data) {
            if (err) {
                res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
            } else {
                if (!data) {
                    res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));

                } else {
                    res.json(Response(constant.statusCode.ok, constant.messages.dataRetrievedSuccess, data, null));
                }
            }
        });
}