'use strict';

var mongoose = require('mongoose'),
    common = require('../../config/common.js'),
    Error = require('../lib/error.js'),
    Response = require('../lib/response.js'),
    constant = require('../lib/constants.js'),
    utility = require('../lib/utility.js'),
    waterfall = require('async-waterfall'),
    async = require('async'),
    moment = require('moment'),
    InternalMessage = mongoose.model('internal_message'),
    Notification = mongoose.model('notification');

module.exports = {
    askQuestion: askQuestion,
    getAllBuyingMessage: getAllBuyingMessage,
    getAllSellingMessage: getAllSellingMessage,
    markAllMessageAsRead: markAllMessageAsRead
};



/**
 * Function is use to Ask Question to Seller
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 02-04-2018
 */
    function askQuestion(req, res){
    var askQueObj = {
        to              : req.body.toId,
        from            : req.body.fromId,
        subject         : 'Ask Question from Buyer',
        description     : req.body.message,
        productId       : req.body.productId,
        product_image   : req.body.product_image,
    };
    var notiObj = {
        sourceUser      : req.body.fromId,
        destnationUser  : req.body.toId,
        productId       : req.body.productId,
        notifyType      : 'Message',
        content         : req.body.message
    };
    if(req.body.isFromBuyer){
        askQueObj.isSentBy = 'Buyer';
        notiObj.createdBy = 'user';
    }else{
        askQueObj.isSentBy = 'Seller';
        notiObj.createdBy = 'seller';
    }
    var askQueRecord = new InternalMessage(askQueObj);
    askQueRecord.save(function(err, askQueData){
        if (err){
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        }else {
            new Notification(notiObj).save(function(err, notiData) {
                if (err) {
                    console.log("Notification Save Err :: ",err);
                    res.json(Response(constant.statusCode.ok, constant.messages.askQuestionSentSuccessfully, askQueData, null));
                } else {
                    res.json(Response(constant.statusCode.ok, constant.messages.askQuestionSentSuccessfully, askQueData, null));
                }
            });
        }
    });
}

/**
 * Function is use to list of all buying messages
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 03-04-2018
 */
function getAllBuyingMessage(req, res){
    var userId = req.body.userId;
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    var sorting = utility.getSortObj(req.body);
    var condition = {deleted: false, from: userId};
    var a = moment();//now
    // var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
    // if (req.body.searchText) {
    //     condition.$or = [
    //         { 'title'  : new RegExp(searchText, 'gi') },
    //         { 'brand': new RegExp(searchText, 'gi') },
    //         { 'fabric': new RegExp(searchText, 'gi') },
    //         { 'product_status': new RegExp(searchText, 'gi') },
    //     ];
    // }
    InternalMessage.find(condition)
    .populate('to')
    .populate('from')
    .populate('productId')
    .populate('product_image')
    .limit(parseInt(count))
    .skip(parseInt(skip))
    .sort(sorting)
    .lean()
    .exec(function(err, result) {
        if (err) {
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        } else {
            InternalMessage.find(condition).count().exec(function(err, totalCount) {
                if (err) {
                    res.json({code: 201, message: constant.messages.requestNotProcessed, data: err});
                } else {
                    async.each(result, function(item, cb){
                        console.log("11111");
                        var b = moment(item.createdAt);
                        var agoTxt = '';
                        if(a.diff(b, 'years') > 0){
                            agoTxt = a.diff(b, 'years') + ' Year ago';
                            item.addedAgo =  agoTxt;
                            
                            cb();
                        }else if(a.diff(b, 'months') > 0){
                            agoTxt = a.diff(b, 'months') + ' Months ago';
                            item.addedAgo =  agoTxt;
                            
                            cb();
                        }else if(a.diff(b, 'days') > 0){
                            agoTxt = a.diff(b, 'days') + ' Days ago';
                            item.addedAgo =  agoTxt;
                            
                            cb();
                        }else if(a.diff(b, 'hours') > 0){
                            agoTxt = a.diff(b, 'hours') + ' Hours ago';
                            item.addedAgo =  agoTxt;
                            
                            cb();
                        }else if(a.diff(b, 'minutes') > 0){
                            agoTxt = a.diff(b, 'minutes') + ' Minutes ago';
                            item.addedAgo =  agoTxt;
                            
                            cb();
                        }else{
                            agoTxt = 'Now';
                            item.addedAgo =  agoTxt;
                            
                            cb();
                        }
                    }, function(err){
                        if(err){
                            res.json({code: 201, message: constant.messages.requestNotProcessed, data: err});
                        }else{
                            res.json({code: 200, message: constant.messages.dataRetrievedSuccess, data: result, totalCount: totalCount });
                        }
                    });
                }
            })
        }
    });
}

/**
 * Function is use to list of all selling messages
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 03-04-2018
 */
function getAllSellingMessage(req, res){
    var userId = req.body.userId;
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    var sorting = utility.getSortObj(req.body);
    var condition = {deleted: false, to: userId};
    var a = moment();//now
    // var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
    // if (req.body.searchText) {
    //     condition.$or = [
    //         { 'title'  : new RegExp(searchText, 'gi') },
    //         { 'brand': new RegExp(searchText, 'gi') },
    //         { 'fabric': new RegExp(searchText, 'gi') },
    //         { 'product_status': new RegExp(searchText, 'gi') },
    //     ];
    // }
    InternalMessage.find(condition)
    .populate('to')
    .populate('from')
    .populate('productId')
    .populate('product_image')
    .limit(parseInt(count))
    .skip(parseInt(skip))
    .sort(sorting)
    .lean()
    .exec(function(err, result) {
        if (err) {
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        } else {
            InternalMessage.find(condition).count().exec(function(err, totalCount) {
                if (err) {
                    res.json({code: 201, message: constant.messages.requestNotProcessed, data: err});
                } else {
                    async.each(result, function(item, cb){
                        var b = moment(item.createdAt);
                        var agoTxt = '';
                        if(a.diff(b, 'years') > 0){
                            agoTxt = a.diff(b, 'years') + ' Year ago';
                            item.addedAgo =  agoTxt;
                            
                            cb();
                        }else if(a.diff(b, 'months') > 0){
                            agoTxt = a.diff(b, 'months') + ' Months ago';
                            item.addedAgo =  agoTxt;
                            
                            cb();
                        }else if(a.diff(b, 'days') > 0){
                            agoTxt = a.diff(b, 'days') + ' Days ago';
                            item.addedAgo =  agoTxt;
                            
                            cb();
                        }else if(a.diff(b, 'hours') > 0){
                            agoTxt = a.diff(b, 'hours') + ' Hours ago';
                            item.addedAgo =  agoTxt;
                            
                            cb();
                        }else if(a.diff(b, 'minutes') > 0){
                            agoTxt = a.diff(b, 'minutes') + ' Minutes ago';
                            item.addedAgo =  agoTxt;
                            
                            cb();
                        }else{
                            agoTxt = 'Now';
                            item.addedAgo =  agoTxt;
                            
                            cb();
                        }
                    }, function(err){
                        if(err){
                            res.json({code: 201, message: constant.messages.requestNotProcessed, data: err});
                        }else{
                            res.json({code: 200, message: constant.messages.dataRetrievedSuccess, data: result, totalCount: totalCount });
                        }
                    });
                }
            })
        }
    });
}

/**
 * Function is use to get All Messages
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 03-04-2018
 */
function getAllMessages(req, res){
    var userId = req.body.userId;
    var finalResponse = {};
    var a = moment();//now

    waterfall([
        function(callback) {
            InternalMessage.find({to: userId, deleted: false}, function(err, sellingMessageList){
                if (err){
                    callback(constant.messages.requestNotProcessed, null);
                }else {
                    var newArr = [];
                    async.each(sellingMessageList, function(item, cb){
                        console.loh("11111");
                        var b = moment(item.createdAt);
                        var agoTxt = '';
                        if(a.diff(b, 'years') > 0){
                            agoTxt = a.diff(b, 'years') + ' Year ago';
                            item.addedAgo =  agoTxt;
                            newArr.push(item);
                            cb();
                        }else if(a.diff(b, 'months') > 0){
                            agoTxt = a.diff(b, 'months') + ' Months ago';
                            item.addedAgo =  agoTxt;
                            newArr.push(item);
                            cb();
                        }else if(a.diff(b, 'days') > 0){
                            agoTxt = a.diff(b, 'days') + ' Days ago';
                            item.addedAgo =  agoTxt;
                            newArr.push(item);
                            cb();
                        }else if(a.diff(b, 'minutes') > 0){
                            agoTxt = a.diff(b, 'minutes') + ' Minutes ago';
                            item.addedAgo =  agoTxt;
                            newArr.push(item);
                            cb();
                        }else{
                            agoTxt = 'Now';
                            item.addedAgo =  agoTxt;
                            newArr.push(item);
                            cb();
                        }
                    }, function(err){
                        if(err){
                            callback(constant.messages.requestNotProcessed, null);     
                        }else{
                            finalResponse.sellingMessage = newArr;
                            callback(null, finalResponse);
                        }
                    });
                }
            });
        },
        function(finalResponse, callback) {
            InternalMessage.find({from: userId, deleted: false}, function(err, buyingMessageList){
                if (err){
                    callback(constant.messages.requestNotProcessed, null);
                }else {
                    var newArr1 = [];
                    async.each(buyingMessageList, function(item, cb1){
                        console.loh("22222");
                        var b = moment(item.createdAt);
                        var agoTxt = '';
                        if(a.diff(b, 'years') > 0){
                            agoTxt = a.diff(b, 'years') + ' Year ago';
                            item.addedAgo =  agoTxt;
                            newArr1.push(item);
                            cb1();
                        }else if(a.diff(b, 'months') > 0){
                            agoTxt = a.diff(b, 'months') + ' Months ago';
                            item.addedAgo =  agoTxt;
                            newArr1.push(item);
                            cb1();
                        }else if(a.diff(b, 'days') > 0){
                            agoTxt = a.diff(b, 'days') + ' Days ago';
                            item.addedAgo =  agoTxt;
                            newArr1.push(item);
                            cb1();
                        }else if(a.diff(b, 'minutes') > 0){
                            agoTxt = a.diff(b, 'minutes') + ' Minutes ago';
                            item.addedAgo =  agoTxt;
                            newArr1.push(item);
                            cb1();
                        }else{
                            agoTxt = 'Now';
                            item.addedAgo =  agoTxt;
                            newArr1.push(item);
                            cb1();
                        }
                    }, function(err){
                        if(err){
                            callback(constant.messages.requestNotProcessed, null);     
                        }else{
                            finalResponse.buyingMessage = newArr1;
                            callback(null, finalResponse);
                        }
                    });
                    // finalResponse.buyingMessage = buyingMessageList;
                    // callback(null, finalResponse);
                }
            });
        },
    ],function(err, data) {
        if (err)
            res.jsonp(Error(constant.statusCode.error, err, err));
        else {
            res.json(Response(constant.statusCode.ok, constant.messages.messageFetchSuccessfully, data, null));
        }
    });
    
}

/**
 * Function is use to Mark all selling message as read.
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 09-04-2018
 */
function markAllMessageAsRead(req, res){
    var msgObj = { isRead : true },
        userId = req.body.userId;
    Notification.update({destnationUser: userId, deleted: false}, { $set: msgObj }, {"multi": true}).then(function(data){
        if (data){
            res.json(Response(constant.statusCode.ok, constant.messages.markAllMessageAsRead, data, null));
        } else {
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        }
    });
}