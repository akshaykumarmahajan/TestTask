'use strict';

var mongoose = require('mongoose'),
    common = require('../../config/common.js'),
    Error = require('../lib/error.js'),
    Response = require('../lib/response.js'),
    constant = require('../lib/constants.js'),
    mailer = require('../lib/mailer.js'),
    waterfall = require('async-waterfall'),
    async = require('async'),
    paypal = require('paypal-rest-sdk'),
    moment = require('moment'),
    voucher_codes = require('voucher-code-generator'),
    User = mongoose.model('user'),
    Product = mongoose.model('product'),
    Payment = mongoose.model('payment'),
    ShippingAddress = mongoose.model('shipping_address'),
    ShippingDetail = mongoose.model('shipping_detail'),
    Order = mongoose.model('order'),
    Notification = mongoose.model('notification');

module.exports = {
    buyProduct: buyProduct,
    successPayment: successPayment
};

paypal.configure({
  'mode': 'sandbox', //sandbox or live
  'client_id': 'AagUjF3h4zw-kBHlLuowcCv-NC6E_rznjx8_-ctVkJEiQJNpGYVdDXeY6PHXiWD8m65toOtAQmP_FWgO',
  'client_secret': 'EAZWkcmaNh8iwNQ35ss9-AXY8OoaMs7FbLigooNXCY1Qbs_TKMyZ1RgSaXhJ7nlHfJ2OECcxOWMCDVmd'
});

/**
 * Function is use to buy Product and redirect to paypal payment gateway 
 * @access private
 * @return json
 * Created by abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 10-Aug-2017
 */
function buyProduct(req, res){
    console.log("req.body :: ", req.body);
    var create_payment_json = {
        "intent": "sale",
        "payer": {
            "payment_method": "paypal"
        },
        "redirect_urls": {
            "return_url": "http://localhost:5109/#/checkout/paymentSuccess",
            "cancel_url": "http://localhost:5109/#/"
        },
        "transactions": [{
            "item_list": {
                "items": [{
                    "name": "BLUE Sox Hat",
                    "sku": "001",
                    "price": "0.01",
                    "currency": "USD",
                    "quantity": 1
                }]
            },
            "amount": {
                "currency": "USD",
                "total": "0.01"
            },
            "description": "Hat for the best team ever"
        }]
    };

    console.log("create_payment_json::::::::;;;;", create_payment_json);

    paypal.payment.create(create_payment_json, function (error, payment) {
  // console.log("PAYMENT", create_payment_json);
      console.log("PAYMENT", payment);
      if (error) {
        console.log("ERRORRRRRRRR", error);
        console.log("ERRORRRRRRRR-------", error.response.details);
          throw error;
      } else {
          for(let i = 0;i < payment.links.length;i++){
            if(payment.links[i].rel === 'approval_url'){
              console.log("LINKKKKKK::::::;;", payment.links[i].href);
              res.json(Response(constant.statusCode.ok, constant.messages.dataRetrievedSuccess, payment.links[i].href,null));
            }
          }
      }
    });
}

/**
 * Function is use to 
 * @access private
 * @return json
 * Created by abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 10-Aug-2017
 */

function successPayment(req, res){
    console.log('req.body : ', req.body);
    var finalResponse = {};
    var productId = req.body.productId,
        userId = req.body.userId;
    var payerId = req.body.payerId;
    var paymentId = req.body.paymentId;

    waterfall([
        // function(callback) { //Making Payment Paypal
        //     finalResponse.paymentInfo = {"id":"PAY-9HD71346208721823LLHR3XI","intent":"sale","state":"approved","cart":"8K178488832164358","payer":{"payment_method":"paypal","payer_info":{"email":"c2cmarketplace.sdn@gmail.com","first_name":"Silkhi","last_name":"admin","payer_id":"RQHU5GUUMZJGQ","shipping_address":{"recipient_name":"Silkhi admin","line1":"21 Mill St. E.","city":"Acton","state":"ON","postal_code":"L7J 1G8","country_code":"CA"},"country_code":"CA","billing_address":{"line1":"21 Mill St. E.","line2":"","city":"Acton","state":"ON","postal_code":"L7J 1G8","country_code":"CA"}}},"transactions":[{"amount":{"total":"0.01","currency":"USD","details":{}},"description":"Hat for the best team ever","item_list":{"items":[{"name":"BLUE Sox Hat","sku":"001","price":"0.01","currency":"USD","quantity":1}],"shipping_address":{"recipient_name":"Silkhi admin","line1":"21 Mill St. E.","city":"Acton","state":"ON","postal_code":"L7J 1G8","country_code":"CA"}},"related_resources":[{"sale":{"id":"3LD33564SP725742M","state":"completed","amount":{"total":"0.01","currency":"USD","details":{}},"payment_mode":"INSTANT_TRANSFER","protection_eligibility":"ELIGIBLE","protection_eligibility_type":"ITEM_NOT_RECEIVED_ELIGIBLE,UNAUTHORIZED_PAYMENT_ELIGIBLE","transaction_fee":{"value":"0.01","currency":"USD"},"parent_payment":"PAY-9HD71346208721823LLHR3XI","create_time":"2018-04-12T08:52:53Z","update_time":"2018-04-12T08:52:53Z","links":[{"href":"https://api.sandbox.paypal.com/v1/payments/sale/3LD33564SP725742M","rel":"self","method":"GET"},{"href":"https://api.sandbox.paypal.com/v1/payments/sale/3LD33564SP725742M/refund","rel":"refund","method":"POST"},{"href":"https://api.sandbox.paypal.com/v1/payments/payment/PAY-9HD71346208721823LLHR3XI","rel":"parent_payment","method":"GET"}]}}]}],"create_time":"2018-04-12T08:52:54Z","links":[{"href":"https://api.sandbox.paypal.com/v1/payments/payment/PAY-9HD71346208721823LLHR3XI","rel":"self","method":"GET"}],"httpStatusCode":200};
        //     callback(null, finalResponse);
        // },
        function(callback) { //Making Payment Paypal
            var execute_payment_json = {
                "payer_id": payerId,
                "transactions": [{
                    "amount": {
                        "currency": "USD",
                        "total": "0.01"
                    }
                }]
            };

            paypal.payment.execute(paymentId, execute_payment_json, function (error, payment) {
                if (error) {
                    console.log(error.response);
                    console.log(error);
                    callback(constant.messages.requestNotProcessed, null);
                    // throw error;
                } else {
                    console.log(JSON.stringify(payment));
                    finalResponse.paymentInfo = payment;
                    callback(null, finalResponse);
                    // res.json(Response(constant.statusCode.ok, constant.messages.paymentSuccess, payment, null));
                }
            });
        },
        function(finalResponse, callback) { //Product Info
            Product.findOne({ _id: productId, deleted: false})
            .populate('featuredImageId')
            .lean().exec(function(err, productInfo) {
                console.log("productInfo :: ", productInfo);
                if (err) {
                    console.log("Err 1 :: ", err);
                    callback(constant.messages.productNotFound, null);
                } else {
                    finalResponse.productInfo = productInfo;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) { //Buyer Info
            User.findOne({_id: userId, deleted: false})
            .lean().exec(function(err, buyerInfo){
                if(err){
                    console.log("Err 2 :: ", err);
                    callback(constant.messages.productNotFound, null);
                }else{
                    finalResponse.buyerInfo = buyerInfo;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) { //Seller Info
            User.findOne({_id: finalResponse.productInfo.sellerId, deleted: false})
            .lean().exec(function(err, sellerInfo){
                if(err){
                    console.log("Err 3 :: ", err);
                    callback(constant.messages.productNotFound, null);
                }else{
                    finalResponse.sellerInfo = sellerInfo;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) { //Payment Info save to DB
            var code = voucher_codes.generate({
                prefix: "PAY-",
                length: 4,
                count: 1,
                charset: "0123456789"
            });
            var payment_obj = {
                userId                      : userId, 
                sellerId                    : finalResponse.productInfo.sellerId,
                productId                   : productId,
                categoryId                  : finalResponse.productInfo.categoryId,
                subCategoryId               : finalResponse.productInfo.subCategoryId,
                productImageId              : finalResponse.productInfo.featuredImageId._id,
                payment_unique_id           : code[0],
                total_amount                : parseFloat(req.body.total_amount),
                processing_fees             : parseFloat(req.body.processing_fees),
                commision                   : parseFloat(req.body.commision),
                product_amount              : parseFloat(finalResponse.productInfo.price),
                shipping_amount             : parseFloat(req.body.shipping_amount),
                paypal_payment_id           : finalResponse.paymentInfo.id,
                paypal_response_message     : finalResponse.paymentInfo.status,
                paypal_response_code        : finalResponse.paymentInfo.httpStatusCode,
                paypal_response_json        : finalResponse.paymentInfo,
                payment_status              : finalResponse.paymentInfo.payer.status,
                payment_method              : finalResponse.paymentInfo.payer.payment_method
            };
            var paymentRecord = new Payment(payment_obj);
            paymentRecord.save(function(err, paymentData){
                if(err){
                    console.log("Err 4 :: ", err);
                    callback(constant.messages.requestNotProcessed, null);
                }else{
                    finalResponse.paymentData = paymentData;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) { //Save Shipping Address to DB
            var shippingAdd = {
                firstname : req.body.firstname,
                lastname : req.body.lastname,
                country : req.body.country,
                address_line_1 : req.body.address_line_1,
                city : req.body.city,
                state : req.body.state,
                zipcode : req.body.zipcode,
                pnhone_number : req.body.pnhone_number,
                productId : req.body.productId,
                userId : req.body.userId
            };
            if(req.body.address_line_2){
                shippingAdd.address_line_1 = req.body.address_line_1;
            }
            var shippingAddressRecors = new ShippingAddress(shippingAdd);
            shippingAddressRecors.save(function(err, shippingAddressInfo){
                if(err){
                    console.log("Err 5 :: ", err);
                    callback(constant.messages.requestNotProcessed, null);
                }else{
                    finalResponse.shippingAddressInfo = shippingAddressInfo;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) { //Place Shipping Order on UPS
            finalResponse.shippingInfo = {
                shippingNo          : 'UPS-SHIP-123456',
                shippingWeight      : 1,
                shippingCount       : 1,
                shippingCharge      : 10,
                shippingRes         : {}
            };
            callback(null, finalResponse);
        },
        function(finalResponse, callback) { //Save Shipping Details to DB
            var shippingObj = {
                sellerId                : finalResponse.productInfo.sellerId,
                userId                  : userId,
                productId               : productId,
                paymentId               : finalResponse.paymentData._id,
                categoryId              : finalResponse.productInfo.categoryId,
                subCategoryId           : finalResponse.productInfo.subCategoryId,
                shippingAddressId       : finalResponse.shippingAddressInfo._id,
                productImageId          : finalResponse.productInfo.featuredImageId._id,

                shippingNo              : finalResponse.shippingInfo.shippingNo,
                shippingWeight          : finalResponse.shippingInfo.shippingWeight,
                shippingCount           : finalResponse.shippingInfo.shippingCount,
                shippingCharge          : finalResponse.shippingInfo.shippingCharge,
                shippingRes             : finalResponse.shippingInfo.shippingRes,
                shippingDate            : moment().format(),
                expectedDeliverDate     : moment().add(3, 'days').format(),
                
                seller_name             : finalResponse.sellerInfo.username,
                seller_number           : finalResponse.sellerInfo.phone_number,
                seller_address_line_1   : finalResponse.sellerInfo.address_line_1,
                seller_address_line_2   : finalResponse.sellerInfo.address_line_2,
                seller_city             : finalResponse.sellerInfo.city,
                seller_state            : finalResponse.sellerInfo.state,
                seller_zipcode          : finalResponse.sellerInfo.zipcode,

                buyer_name              : finalResponse.buyerInfo.username,
                buyer_number            : finalResponse.buyerInfo.phone_number,
                buyer_address_line_1    : finalResponse.buyerInfo.address_line_1,
                buyer_address_line_2    : finalResponse.buyerInfo.address_line_2,
                buyer_city              : finalResponse.buyerInfo.city,
                buyer_state             : finalResponse.buyerInfo.state,
                buyer_zipcode           : finalResponse.buyerInfo.zipcode,
            };

            var shippingDetailRecord = new ShippingDetail(shippingObj);
            shippingDetailRecord.save(function(err, shippingDetailInfo){
                if(err){
                    console.log("Err 6 :: ", err);
                    callback(constant.messages.requestNotProcessed, null);
                }else{
                    finalResponse.shippingDetailInfo = shippingDetailInfo;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) { //Save Order to DB
            var orderObj = {
                sellerId                : finalResponse.productInfo.sellerId,
                userId                  : userId,
                productId               : productId,
                paymentId               : finalResponse.paymentData._id,
                categoryId              : finalResponse.productInfo.categoryId,
                subCategoryId           : finalResponse.productInfo.subCategoryId,
                shippingAddressId       : finalResponse.shippingAddressInfo._id,
                shippingDetailId        : finalResponse.shippingDetailInfo._id,
                productImageId          : finalResponse.productInfo.featuredImageId._id,

                shippingNo              : finalResponse.shippingInfo.shippingNo,
                shippingWeight          : finalResponse.shippingInfo.shippingWeight,
                shippingCount           : finalResponse.shippingInfo.shippingCount,
                shippingCharge          : finalResponse.shippingInfo.shippingCharge,
                shippingRes             : finalResponse.shippingInfo.shippingRes,
                shippingDate            : moment().format(),
                orderDate               : moment().format(),
                expectedDeliverDate     : moment().add(3, 'days').format(),
                
                seller_name             : finalResponse.sellerInfo.username,
                seller_number           : finalResponse.sellerInfo.phone_number,
                seller_address_line_1   : finalResponse.sellerInfo.address_line_1,
                seller_address_line_2   : finalResponse.sellerInfo.address_line_2,
                seller_city             : finalResponse.sellerInfo.city,
                seller_state            : finalResponse.sellerInfo.state,
                seller_zipcode          : finalResponse.sellerInfo.zipcode,

                buyer_name              : finalResponse.buyerInfo.username,
                buyer_number            : finalResponse.buyerInfo.phone_number,
                buyer_address_line_1    : finalResponse.buyerInfo.address_line_1,
                buyer_address_line_2    : finalResponse.buyerInfo.address_line_2,
                buyer_city              : finalResponse.buyerInfo.city,
                buyer_state             : finalResponse.buyerInfo.state,
                buyer_zipcode           : finalResponse.buyerInfo.zipcode,

                total_amount            : parseFloat(req.body.total_amount),
                processing_fees         : parseFloat(req.body.processing_fees),
                commision               : parseFloat(req.body.commision),
                product_amount          : parseFloat(finalResponse.productInfo.price),
                shipping_amount         : parseFloat(req.body.shipping_amount)
            };

            var orderRecord = new Order(orderObj);
            orderRecord.save(function(err, orderInfo){
                if(err){
                    console.log("Err 7 :: ", err);
                    callback(constant.messages.requestNotProcessed, null);
                }else{
                    finalResponse.orderInfo = orderInfo;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) { //Save Order to DB
            var notiObj = {
                sourceUser : finalResponse.buyerInfo._id,
                destnationUser : finalResponse.sellerInfo._id,
                productId : productId,
                notifyType : 'Product',
                createdBy : 'user',
                content : 'Your Product is SOLD'
            };

            var notiSellerRecord = new Notification(notiObj);
            notiSellerRecord.save(function(err, notiSellerInfo){
                if(err){
                    callback(content.messages.requestNotProcessed, null);
                }else{
                    finalResponse.notiSellerInfo = notiSellerInfo;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) { //Save Order to DB
            var notiObj = {
                sourceUser : finalResponse.sellerInfo._id,
                destnationUser : finalResponse.buyerInfo._id,
                productId : productId,
                notifyType : 'Product',
                createdBy : 'seller',
                content : 'Order successfully placed'
            };

            var notiBuyerRecord = new Notification(notiObj);
            notiBuyerRecord.save(function(err, notiBuyerInfo){
                if(err){
                    callback(content.messages.requestNotProcessed, null);
                }else{
                    finalResponse.notiBuyerInfo = notiBuyerInfo;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) { //Email to Buyer
            var mailData = {
                userId          : finalResponse.buyerInfo._id,
                email           : finalResponse.buyerInfo.email,
                firstname       : finalResponse.buyerInfo.firstname,
                lastname        : finalResponse.buyerInfo.lastname,
                username        : finalResponse.buyerInfo.username,
                product_title   : finalResponse.productInfo.title,
                total_amount    : finalResponse.orderInfo.total_amount,
                shipping_id     : finalResponse.shippingInfo.shippingNo,
                // tracking_id     : finalResponse.trackingInfo.trackingId,
                tracking_id     : 'Tracking-123',
                order_date      : moment(finalResponse.orderInfo.orderDate).format('MMM DD, YYYY'),
                delivery_date   : moment(finalResponse.orderInfo.expectedDeliverDate).format('MMM DD, YYYY'),
            };
            mailer.sendMail(mailData.email, constant.emailKeyword.order_product, mailData, function (err, resp) {
                if (err) {
                    callback(null, finalResponse);
                } else {
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) { //Email to Seller
            var shipping_address = finalResponse.shippingAddressInfo.firstname +" "+finalResponse.shippingAddressInfo.lastname+" "+finalResponse.shippingAddressInfo.address_line_1+" "+finalResponse.shippingAddressInfo.city+" "+finalResponse.shippingAddressInfo.state+" "+finalResponse.shippingAddressInfo.zipcode+" "+finalResponse.shippingAddressInfo.country+". Comtact Details : "+finalResponse.shippingAddressInfo.pnhone_number;
            var mailData = {
                userId              : finalResponse.sellerInfo._id,
                email               : finalResponse.sellerInfo.email,
                firstname           : finalResponse.sellerInfo.firstname,
                lastname            : finalResponse.sellerInfo.lastname,
                username            : finalResponse.sellerInfo.username,
                product_title       : finalResponse.productInfo.title,
                total_amount        : finalResponse.orderInfo.total_amount,
                shipping_id         : finalResponse.shippingInfo.shippingNo,
                buyer_firstname     : finalResponse.buyerInfo.firstname,
                shipping_address    : shipping_address,
                // tracking_id      : finalResponse.trackingInfo.trackingId,
                tracking_id         : 'Tracking-123',
                order_date          : moment(finalResponse.orderInfo.orderDate).format('MMM DD, YYYY'),
                delivery_date       : moment(finalResponse.orderInfo.expectedDeliverDate).format('MMM DD, YYYY'),
            };
            mailer.sendMail(mailData.email, constant.emailKeyword.seller_order_product, mailData, function (err, resp) {
                if (err) {
                    callback(null, finalResponse);
                } else {
                    callback(null, finalResponse);
                }
            });
        },
    ],function(err, data) {
        if (err)
            res.jsonp(Error(constant.statusCode.error, err, err));
        else {
            res.json(Response(constant.statusCode.ok, constant.messages.paymentSuccess, data, null));
        }
    });
}

/**
 * Function is use to 
 * @access private
 * @return json
 * Created by abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 10-Aug-2017
 */

function successPayment_bk(req, res){
    var payerId = req.body.payerId;
    var paymentId = req.body.paymentId;

    var execute_payment_json = {
        "payer_id": payerId,
        "transactions": [{
            "amount": {
                "currency": "USD",
                "total": "0.01"
            }
        }]
    };

    paypal.payment.execute(paymentId, execute_payment_json, function (error, payment) {
        if (error) {
            console.log(error.response);
            console.log(error);
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, error));
            // throw error;
        } else {
            console.log(JSON.stringify(payment));
            res.json(Response(constant.statusCode.ok, constant.messages.paymentSuccess, payment, null));
            // res.send('Success');
            // res.redirect('/Success.html');
        }
    });
}
