'use strict';

var mongoose = require('mongoose'),
    voucher_codes = require('voucher-code-generator'),
    common = require('../../config/common.js'),
    Error = require('../lib/error.js'),
    Response = require('../lib/response.js'),
    constant = require('../lib/constants.js'),
    utility = require('../lib/utility.js'),
    waterfall = require('async-waterfall'),
    moment = require('moment'),
    async = require('async'),
    _ = require('underscore'),
    User = mongoose.model('user'),
    Product = mongoose.model('product'),
    ProductWishList = mongoose.model('product_wish_list'),
    ProductCondition = mongoose.model('product_condition'),    
    ProductOccasion = mongoose.model('product_occasion'),
    ProductCategory = mongoose.model('product_category'),
    ProductImage = mongoose.model('product_image'),
    ProductColor = mongoose.model('product_color'),
    ProductSize = mongoose.model('product_size'),
    Review = mongoose.model('review_comment'),
    ProductInventory = mongoose.model('product_inventory');

module.exports = {
    addProduct: addProduct,
    getProductListBySellerId: getProductListBySellerId,
    getProductDetails: getProductDetails,
    deleteProduct: deleteProduct,
    updateProduct: updateProduct,
    getAllProducts: getAllProducts,
    viewProductDetailByProductId: viewProductDetailByProductId,
    searchProduct: searchProduct
};



/**
 * Function is use to add Product
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 14-03-2018
 */
function addProduct(req, res){
    //console.log("Product Req Body :: ", req.body);
    var finalResponse = {};
    var sellerId = req.body.sellerId;

    waterfall([
        function(callback) {
            User.find({ _id: sellerId, deleted: false}).count().lean().exec(function(err, sellerInfo) {
                if (err) {
                    //console.log("User Err :: ", err);
                    callback(err, null);
                } else {
                    if(sellerInfo.status == 0){
                        callback(constant.messages.accountNotActivated, null);    
                    }else{
                        finalResponse.sellerInfo = sellerInfo;
                        callback(null, finalResponse);
                    }
                }
            });
        },
        function(finalResponse, callback) {
            getTitleName(req.body, function(err, titleText){
                if(err){
                    callback(err, null);
                }else{
                    finalResponse.titleText = titleText;
                    callback(null, finalResponse);
                }
            })
        },
        function(finalResponse, callback) {
            
            var product_obj = {
                sellerId : sellerId,
                title : finalResponse.titleText.title_txt,
                categoryId : req.body.categoryId,
                sizeId : req.body.sizeId,
                condition : req.body.condition,
                description : req.body.description,
                occasion : req.body.occasion,
                fabric : req.body.fabric,
                brand : req.body.brand,
                currency : req.body.currency,
                price : req.body.price,
                productUniqueId: finalResponse.titleText.productUniqueId,
                // quantity : req.body.quantity
                quantity : 1
            };
            var productRecord = new Product(product_obj);
            productRecord.save(function (err, productDate) {
                if (err) {
                    //console.log("Product Err :: ", err);
                    callback(err, null);
                } else {
                    finalResponse.productInfo = productDate;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) {
            var inventoryArr = [];
            async.each(req.body.colorId, function(item, colorCb){
                var inventoryObj = {
                    productId : finalResponse.productInfo._id,
                    categoryId : req.body.categoryId,
                    subCategoryId : req.body.subCategoryId,
                    sizeId : req.body.sizeId,
                    colorId : item,
                    // actual_count : req.body.quantity,
                    // original_count : req.body.quantity
                    actual_count : 0,
                    original_count : 0
                };
                var inventoryRecord = new ProductInventory(inventoryObj);
                inventoryRecord.save(function (err, inventoryDate) {
                    if (err) {
                        colorCb(err, null);
                    }else{
                        inventoryArr.push(inventoryDate);
                        colorCb(null, true);
                    }
                });
            }, function(err){
                if (err) {
                    //console.log("Inventory Err :: ", err);
                    callback(err, null);
                } else {
                    var colorObj = {
                        color_1 : req.body.colorId[0]
                    };
                    if(req.body.colorId.length == 2){
                        colorObj.color_2 = req.body.colorId[1];
                    }
                    Product.findOneAndUpdate({_id: finalResponse.productInfo._id}, {$set: colorObj}, {new: true}, function(err, productData){
                        if(err){
                            callback(err, null);
                        }else{
                            finalResponse.productInfo = productData;
                            finalResponse.inventoryInfo = inventoryArr;
                            callback(null, finalResponse);
                        }
                    });
                }
            });
        },
    ],function(err, data) {
        if (err)
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        else {
            res.json(Response(constant.statusCode.ok, constant.messages.productAddedSuccessfully, finalResponse.productInfo,null));
        }
    });
}

/**
 * Function is use to get Product List By SellerId
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 14-03-2018
 */
function getProductListBySellerId(req, res){
    var sellerId = req.body.sellerId;
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    var sorting = utility.getSortObj(req.body);
    var condition = {deleted: false, sellerId: sellerId};
    var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
    if (req.body.searchText) {
        condition.$or = [
            { 'title'  : new RegExp(searchText, 'gi') },
            { 'brand': new RegExp(searchText, 'gi') },
            { 'fabric': new RegExp(searchText, 'gi') },
            { 'product_status': new RegExp(searchText, 'gi') },
        ];
    }
    Product.find(condition)
    .populate('featuredImageId')
    .populate('categoryId')
    .populate('currency')
    .limit(parseInt(count))
    .skip(parseInt(skip))
    .sort(sorting)
    .lean()
    .exec(function(err, result) {
        if (err) {
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        } else {
            Product.find(condition).count().exec(function(err, totalCount) {
                if (err) {
                    res.json({code: 201, message: constant.messages.requestNotProcessed, data: err});
                } else {
                    res.json({code: 200, message: constant.messages.dataRetrievedSuccess, data: result, totalCount: totalCount });
                }
            })
        }
    });
}

/**
 * Function is use to get Product details by id
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 22-03-2018
 */
function viewProductDetailByProductId(req, res){
    //console.log("View Product Details Req Body :: ", req.body);
    var productId = req.body.productId;
    var finalResponse = {};

    waterfall([
        function(callback) {    //Product Details
            Product.findOne({_id: productId, deleted: false})
            .populate('sellerId')
            .populate('categoryId')
            .populate('sizeId')
            .populate('sub_categoryId')
            .populate('featuredImageId')
            .populate('currency')
            .populate('condition')
            .populate('occasion')
            .lean()
            .exec(function(err, productInfo){
                //console.log('productInfo :: ', productInfo);
                if (err) {
                    //console.log("User Err :: ", err);
                    callback(err, null);
                } else if(productInfo != null) {
                    var a = moment();//now
                    var b = moment(productInfo.createdAt);

                    var agoTxt = '';
                    if(a.diff(b, 'years') > 0){
                        agoTxt = a.diff(b, 'years') + ' Year ago';
                        productInfo.addedAgo =  agoTxt;
                    }else if(a.diff(b, 'months') > 0){
                        agoTxt = a.diff(b, 'months') + ' Months ago';
                        productInfo.addedAgo =  agoTxt;
                    }else if(a.diff(b, 'days') > 0){
                        agoTxt = a.diff(b, 'days') + ' Days ago';
                        productInfo.addedAgo =  agoTxt;
                    }else{
                        agoTxt = 'Added today';
                        productInfo.addedAgo =  agoTxt;
                    }
                    finalResponse.productInfo = productInfo;
                    callback(null, finalResponse);
                }else{
                    callback(err, null);
                }
            });
        },
        function(finalResponse, callback) { //Product Image List
            ProductImage.find({productId: productId, deleted: false})
            .lean()
            .exec(function(err, imageList){
                if (err) {
                    //console.log("Product Err :: ", err);
                    callback(err, null);
                } else {
                    finalResponse.imageList = imageList;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) { //Product Inventory Details
            ProductInventory.find({productId: productId, deleted: false})
            .lean()
            .exec(function(err, inventoryList){
                if (err) {
                    callback(err, null);
                } else {
                    finalResponse.inventoryList = inventoryList;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) { //Seller Product Count
            Product.find({sellerId: finalResponse.productInfo.sellerId._id, deleted: false})
            .count()
            .exec(function(err, sellerProductCount){
                if (err) {
                    callback(err, null);
                } else {
                    finalResponse.sellerProductCount = sellerProductCount;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) { //Intrested People for same Product count
            ProductWishList.find({productId: productId, deleted: false})
            .count()
            .exec(function(err, intrestedPeopleCount){
                if (err) {
                    callback(err, null);
                } else {
                    finalResponse.intrestedPeopleCount = intrestedPeopleCount;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) { //Product color Details & remaining count
            var colorDetails = [];
            async.each(finalResponse.inventoryList, function(item, inventoryCb){
                ProductColor.findOne({_id: item.colorId}, function(err, colorInfo){
                    if(err){
                        inventoryCb(err, null);
                    }else{
                        colorDetails.push(colorInfo);
                        inventoryCb(null, true);
                    }
                });
            }, function(err){
                if(err){
                    callback(err, null);
                }else{
                    finalResponse.colorInfo = colorDetails;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) { //Product color Details & remaining count
            Product.find({
                categoryId: finalResponse.productInfo.categoryId._id,
                $or: [
                    {color_1: finalResponse.productInfo.color_1},
                    {color_2: finalResponse.productInfo.color_1},
                    {color_1: finalResponse.productInfo.color_2},
                    {color_2: finalResponse.productInfo.color_2},

                ],
                deleted: false
            })
            .populate('featuredImageId')
            .populate('currency')
            .lean()
            .exec(function(err, sameProductList){
                if(err){
                    callback(err, null);
                }else{
                    finalResponse.sameProductList = sameProductList;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) { //Seller review list
            Review.find({sellerId: finalResponse.productInfo.sellerId._id, deleted: false})
            .populate('userId')
            .populate('productImageId')
            .sort({_id: -1})
            .lean()
            .exec(function(err, reviewList){
                if (err) {
                    //console.log("Review Err :: ", err);
                    callback(err, null);
                } else {
                    async.each(reviewList, function(item, reviewCb){
                        var a = moment();//now
                        var b = moment(item.createdAt);

                        var agoTxt = '';
                        if(a.diff(b, 'years') > 0){
                            agoTxt = a.diff(b, 'years') + ' Year ago';
                            item.addedAgo =  agoTxt;
                        }else if(a.diff(b, 'months') > 0){
                            agoTxt = a.diff(b, 'months') + ' Months ago';
                            item.addedAgo =  agoTxt;
                        }else if(a.diff(b, 'days') > 0){
                            agoTxt = a.diff(b, 'days') + ' Days ago';
                            item.addedAgo =  agoTxt;
                        }else if(a.diff(b, 'hours') > 0){
                            agoTxt = a.diff(b, 'hours') + ' Hours ago';
                            item.addedAgo =  agoTxt;
                        }else if(a.diff(b, 'minutes') > 0){
                            agoTxt = a.diff(b, 'minutes') + ' Minutes ago';
                            item.addedAgo =  agoTxt;
                        }else{
                            agoTxt = 'Added now';
                            item.addedAgo =  agoTxt;
                        }
                        reviewCb();
                    }, function(err){
                        finalResponse.reviewList = reviewList;
                        //console.log("finalResponse.reviewList:::::;;", finalResponse.reviewList.length);
                        callback(null, finalResponse);
                    });
                }
            });
        }
    ],function(err, data) {
        if (err)
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        else {
            res.json(Response(constant.statusCode.ok, constant.messages.dataRetrievedSuccess, finalResponse, null));
        }
    });
}

 /**
 * Function is use to get Product details by id
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 14-03-2018
 */
function getProductDetails(req, res){
    //console.log("req.query :: ", req.query.id)
    var productId = req.query.id;
    var finalResponse = {};

    waterfall([
        function(callback) {
            Product.findOne({_id: productId, deleted: false})
            .lean()
            .exec(function(err, productInfo){
                if (err) {
                    //console.log("User Err :: ", err);
                    callback(err, null);
                } else {
                    finalResponse.productInfo = productInfo;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) {
            ProductImage.findOne({productId: productId, is_featured: true, deleted: false})
            .lean()
            .exec(function(err, featuredImg){
                if (err) {
                    //console.log("Product Err :: ", err);
                    callback(err, null);
                } else {
                    finalResponse.featuredImg = featuredImg;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) {
            ProductImage.find({productId: productId, is_featured: false, deleted: false})
            .lean()
            .exec(function(err, imageList){
                if (err) {
                    //console.log("Product Err :: ", err);
                    callback(err, null);
                } else {
                    finalResponse.imageList = imageList;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) {
            ProductInventory.find({productId: productId, deleted: false})
            .lean()
            .exec(function(err, inventoryList){
                if (err) {
                    callback(err, null);
                } else {
                    finalResponse.inventoryList = inventoryList;
                    callback(null, finalResponse);
                }
            });
        },
    ],function(err, data) {
        if (err)
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        else {
            res.json(Response(constant.statusCode.ok, constant.messages.dataRetrievedSuccess, finalResponse, null));
        }
    });
    // Product.findOne({_id: productId, deleted: false})
    // .lean()
    // .exec(function(err, productInfo){
    //     if (err) {
    //         res.json({code: 201, message: constant.messages.requestNotProcessed, data: err});
    //     } else {
    //         ProductImage.findOne({productId: productId, is_featured: true, deleted: false})
    //         .lean()
    //         .exec(function(err, featuredImg){
    //             if(err){

    //             }else{
    //                 productInfo.featuredImg = featuredImg;
    //                 productInfo.images = {};
    //                 res.json({code: 200, message: constant.messages.dataRetrievedSuccess, data: productInfo});                    
    //             }
    //         });
    //     }
    // });
}

/**
 * Function is use to Delete Product
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 16-03-2018
 */
function deleteProduct(req, res){
    var id = req.swagger.params.id.value;
    var productRecord = { deleted: true }
    Product.update({ _id: id }, { $set: productRecord }, function(err) {
        if (err) {
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        } else {
            res.json(Response(constant.statusCode.ok, constant.messages.productDeleteSuccess, {}, null));
        }
    });
}

/**
 * Function is use to update Product
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 16-03-2018
 */
function updateProduct(req, res){
    console.log("Update Product Req Body :: ", req.body);
    var finalResponse = {};
    var sellerId = req.body.sellerId;
    var productId = req.body._id;

    waterfall([
        function(callback) {
            User.find({ _id: sellerId, deleted: false}).count().lean().exec(function(err, sellerInfo) {
                if (err) {
                    //console.log("User Err :: ", err);
                    callback(err, null);
                } else {
                    if(sellerInfo.status == 0){
                        callback(constant.messages.accountNotActivated, null);    
                    }else{
                        finalResponse.sellerInfo = sellerInfo;
                        callback(null, finalResponse);
                    }
                }
            });
        },
        function(finalResponse, callback) {
            getTitleName(req.body, function(err, titleText){
                if(err){
                    callback(err, null);
                }else{
                    finalResponse.titleText = titleText;
                    callback(null, finalResponse);
                }
            })
        },
        function(finalResponse, callback) {
            var product_obj = {
                sellerId : sellerId,
                title : finalResponse.titleText.title_txt,
                categoryId : req.body.categoryId,
                sizeId : req.body.sizeId,
                condition : req.body.condition,
                description : req.body.description,
                occasion : req.body.occasion,
                fabric : req.body.fabric,
                brand : req.body.brand,
                currency : req.body.currency,
                price : req.body.price,
                quantity : req.body.quantity
            };
            Product.findOneAndUpdate({_id: productId, deleted: false}, {$set: product_obj}, {new: true})
            .lean()
            .exec(function(err, productInfo){
                if (err) {
                    callback(err, null);
                } else {
                    finalResponse.productInfo = productInfo;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) {
            var inventoryArr = [];
            async.forEachOf(req.body.inventoryArr, function (item, index, colorCb) {
                //console.log("Index : "+index+" Color : "+req.body.colorId[index]+" Item Color : "+item.colorId);
                var inventoryObj = {
                    categoryId : req.body.categoryId,
                    subCategoryId : req.body.subCategoryId,
                    sizeId : req.body.sizeId,
                    colorId : req.body.colorId[index]
                };
                ProductInventory.findOneAndUpdate({_id: item._id}, {$set: inventoryObj}, {new: true})
                .lean()
                .exec(function(err, inventoryInfo){
                    if (err) {
                        colorCb(err, null);
                    }else{
                        inventoryArr.push(inventoryInfo);
                        colorCb(null, true);
                    }
                });
            }, function(err){
                if (err) {
                    callback(err, null);
                } else {
                    finalResponse.inventoryInfo = inventoryArr;
                    callback(null, finalResponse);
                }
            });
        },
    ],function(err, data) {
        if (err)
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        else {
            res.json(Response(constant.statusCode.ok, constant.messages.productUpdatedSuccessfully, finalResponse.productInfo,null));
        }
    });
}

/**
 * Function is use to get all products list
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 20-03-2018
 */
function getAllProducts(req, res){
    //console.log("All Product : Req Body :: ", req.body);
    //console.log("All Product : Req Body :: ", req.body.price);
    var finalResponse = {};
    var query = {};
    query.deleted = false;
    if(req.body.category.length > 0){
        query.categoryId = {$in : req.body.category};
    }
    if(req.body.condition.length > 0){
        query.condition = {$in : req.body.condition};
    }
    if(req.body.size.length > 0){
        query.sizeId = {$in : req.body.size};
    }
    if(req.body.price){
        // query.$or = [
        //     {price : {$gte: req.body.price.minValue}}, 
        //     {price : {$lte: req.body.price.maxValue}}
        // ];        
        query.price = { $gte: req.body.price.minValue, $lte: req.body.price.maxValue };
    }
    if(req.body.color.length > 0){
        query.$or = [
            {color_1 : {$in : req.body.color} },
            {color_2 : {$in : req.body.color} },
        ]
    }
    //console.log("Product List query : ", query);
    waterfall([
        function(callback) {
            Product.find(query)
            .populate('featuredImageId')
            .populate('currency')
            .lean()
            .sort({createdAt : -1})
            .exec(function(err, productList){
                if(err){
                    callback(err, null);
                }else{
                    finalResponse.productList = productList;
                    callback(null, finalResponse);
                }
            });    
        },
    ],function(err, data) {
        if (err)
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        else {
            res.json(Response(constant.statusCode.ok, constant.messages.productListSuccess, finalResponse, null));
        }
    });
}

/**
 * Function is use to get all products list
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 20-03-2018
 */
function searchProduct(req, res){
    //console.log("Search Product Req Body :: ", req.body);
    var finalResponse = {};
    var query = {};
    query.deleted = false;
    if(req.body.userId){
        //console.log("User Id :: ", req.body.userId);
    }
    var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
    if (req.body.searchText) {
        query.$or = [
            { 'title'  : new RegExp(searchText, 'gi') },
            // { 'color_1.color_name': new RegExp(searchText, 'gi') },
            // { 'color_2.color_name': new RegExp(searchText, 'gi') },
            // { 'sizeId.name': new RegExp(searchText, 'gi') },
            // { 'categoryId.name': new RegExp(searchText, 'gi') },
        ];
    }
    if (!isNaN(searchText)) {
        searchText = parseFloat(searchText);
        query.$or.push({ 'price': searchText });
    }
    var aggregateQuery = [
        {   //Product Image details
            $lookup: {
                from: "product_images",
                localField: "featuredImageId",
                foreignField: "_id",
                as: "featuredImageId"
            }
        },
        { $unwind: "$featuredImageId" },
        {   //Category details
            $lookup: {
                from: "product_categories",
                localField: "categoryId",
                foreignField: "_id",
                as: "categoryId"
            }
        },
        { $unwind: "$categoryId" },
        {   //Sub Category details
            $lookup: {
                from: "product_categories",
                localField: "sub_categoryId",
                foreignField: "_id",
                as: "sub_categoryId"
            }
        },
        { $unwind: { path: "$sub_categoryId", preserveNullAndEmptyArrays: true }},
        {   //Size details
            $lookup: {
                from: "product_sizes",
                localField: "sizeId",
                foreignField: "_id",
                as: "sizeId"
            }
        },
        { $unwind: "$sizeId" },
        {   //color details
            $lookup: {
                from: "product_colors",
                localField: "color_1",
                foreignField: "_id",
                as: "color_1"
            }
        },
        { $unwind: "$color_1" },
        {   //color details
            $lookup: {
                from: "product_colors",
                localField: "color_2",
                foreignField: "_id",
                as: "color_2"
            }
        },
        { $unwind: { path: "$color_2", preserveNullAndEmptyArrays: true } },
        {   //currency details
            $lookup: {
                from: "currencies",
                localField: "currency",
                foreignField: "_id",
                as: "currency"
            }
        },
        { $unwind: "$currency" },
        {   //condition details
            $lookup: {
                from: "product_conditions",
                localField: "condition",
                foreignField: "_id",
                as: "condition"
            }
        },
        { $unwind: "$condition" },
        { $match: query }

    ];
    var project = {
        $project: {
            price: 1,
            title: 1,
            featuredImageId: '$featuredImageId',
            categoryId: '$categoryId',
            sub_categoryId: "$sub_categoryId",
            sizeId: '$sizeId',
            color_1: '$color_1',
            color_2: '$color_2',
            currency: '$currency',
            condition: '$condition',
        }
    };
    var sort = {_id : -1};
    var countQuery = [].concat(aggregateQuery);
    aggregateQuery.push(project);
    aggregateQuery.push({ $sort: sort });
    //console.log('Query :: ', query)
    Product.aggregate(aggregateQuery).then(function(result) {
        //console.log("Result :: ", result);
        countQuery.push({ $group: { _id: null, count: { $sum: 1 } } });
        Product.aggregate(countQuery).then(function(dataCount) {
            var cnt = (dataCount[0]) ? dataCount[0].count : 0;
            // data.totalCount = cnt;
            res.json({code: 200, message: constant.messages.dataRetrievedSuccess, data: result, totalCount: cnt });
            // res.json(Response(constant.statusCode.ok, constant.messages.dataRetrievedSuccess, data));
        });
    }).catch(function(err) {
        //console.log("Err :: ", err)
        res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
    });
    // waterfall([
    //     function(callback) {
    //         Product.find(query)
    //         .populate('featuredImageId')
    //         .populate('currency')
    //         .lean()
    //         .sort({createdAt : -1})
    //         .exec(function(err, productList){
    //             if(err){
    //                 callback(err, null);
    //             }else{
    //                 finalResponse.productList = productList;
    //                 callback(null, finalResponse);
    //             }
    //         });    
    //     },
    //     // function(finalResponse, callback){
    //     //     if(req.body.userId){
    //     //         ProductWishList.find({userId: req.body.userId, deleted: false}, function(err, wishList){
    //     //             if(err){
    //     //                 callback(err, finalResponse);
    //     //             }else{
                        
    //     //             }
    //     //         });
    //     //     }else{
    //     //         callback(null, finalResponse)
    //     //     }
    //     // }
    // ],function(err, data) {
    //     if (err)
    //         res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
    //     else {
    //         res.json(Response(constant.statusCode.ok, constant.messages.productListSuccess, finalResponse.productList, null));
    //     }
    // });
}

function getTitleName (req, callback){
    console.log("Req :: ", req);
    var finalResponse = {};
    waterfall([
        function(wfCallback) {
            ProductCondition.findOne({_id: req.condition, deleted: false}, function(err, conditionInfo){
                if(err){
                    wfCallback(err, null);
                }else{
                    finalResponse.conditionInfo = conditionInfo;
                    wfCallback(null, finalResponse);
                }
            });
        },
        function(finalResponse, wfCallback) {
            ProductCategory.findOne({_id: req.categoryId, deleted: false}, function(err, categoryInfo){
                if(err){
                    wfCallback(err, null);
                }else{
                    finalResponse.categoryInfo = categoryInfo;
                    wfCallback(null, finalResponse);
                }
            });
        },
        function(finalResponse, wfCallback) {
            ProductColor.findOne({_id: req.colorId[0], deleted: false}, function(err, colorInfo){
                if(err){
                    wfCallback(err, null);
                }else{
                    finalResponse.colorInfo = colorInfo;
                    wfCallback(null, finalResponse);
                }
            });
        },
        function(finalResponse, wfCallback) {
            ProductSize.findOne({_id: req.sizeId, deleted: false}, function(err, sizeInfo){
                if(err){
                    wfCallback(err, null);
                }else{
                    finalResponse.sizeInfo = sizeInfo;
                    wfCallback(null, finalResponse);
                }
            });
        },
        function(finalResponse, wfCallback) {
            ProductOccasion.findOne({_id: req.occasion, deleted: false}, function(err, occasionInfo){
                if(err){
                    wfCallback(err, null);
                }else{
                    finalResponse.occasionInfo = occasionInfo;
                    wfCallback(null, finalResponse);
                }
            });
        },
        function(finalResponse, wfCallback) {
            var code = voucher_codes.generate({
                prefix: "PRO-",
                length: 3,
                count: 1,
                charset: "0123456789"
            });
            // “Red ” “Cotton” “Bridal” “Saree” in “New” condition
            var title_txt = '', returnObj = {};
            returnObj.productUniqueId = code[0];
            title_txt = finalResponse.colorInfo.color_name+" "+req.fabric+" "+finalResponse.categoryInfo.name+" in "+finalResponse.conditionInfo.name+" condition";
            returnObj.title_txt = title_txt;
            finalResponse.returnObj = returnObj;
            wfCallback(null, finalResponse);
        },
    ],function(err, data) {
        if (err)
            callback(err, null)
        else {
            callback(null, finalResponse.returnObj);
        }
    });
    // ProductCondition = mongoose.model('product_condition'),
    // ProductCategory = mongoose.model('product_category'),
    // ProductColor = mongoose.model('product_color'),
    // ProductSize = mongoose.model('product_size'),
    // ProductOccasion = mongoose.model('product_occasion')
}