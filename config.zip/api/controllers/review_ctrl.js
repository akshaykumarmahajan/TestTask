'use strict';

var mongoose = require('mongoose'),
    common = require('../../config/common.js'),
    Error = require('../lib/error.js'),
    Response = require('../lib/response.js'),
    constant = require('../lib/constants.js'),
    waterfall = require('async-waterfall'),
    async = require('async'),
    User = mongoose.model('user'),
    Review = mongoose.model('review_comment');

module.exports = {
    addReviewAndComment: addReviewAndComment,
    getSellerRatingById: getSellerRatingById
    // successPayment: successPayment
};

/**
 * Function is use to add review and comment 
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 11-04-2018
 */
function addReviewAndComment(req, res){
    var finalResponse = {};
    var sellerId = req.body.sellerId;

    waterfall([
        // function(callback) {
        //     User.findOne({ _id: sellerId, deleted: false}, function(err, sellerInfo) {
        //         if (err) {
        //             callback(err, null);
        //         } else {
        //         	finalResponse.sellerInfo = sellerInfo;
        //             callback(null, finalResponse);
        //         }
        //     });
        // },
        function(callback) { //Add review 
        	var addReviewObj = {
				userId: req.body.userId,
				sellerId: req.body.sellerId,
				productId: req.body.productId,
                productImageId: req.body.productImageId,
				review: req.body.rating,
				comment: req.body.comment
			}
		    var reviewModel = new Review(addReviewObj);
		    reviewModel.save(function(err, addReviewInfo){
		        if (err){
                    callback(err, null);
		        }else {
		        	finalResponse.addReviewInfo = addReviewInfo;
                    callback(null, finalResponse);
		        }
		    });
        },
        function(finalResponse, callback) { //Review average rating and count
        	Review.aggregate([
				{ $match: 
					{ sellerId: mongoose.Types.ObjectId(sellerId), deleted: false } 
				},
	            {
			       "$group":
			         {
			           "_id": "$sellerId",
			           "avgRating": { "$avg": "$review" },
			           "count": {"$sum": 1}
			         }
			     }
	        ], function(err, rating) {
	        	if(err){
	        		callback(err, null);
	        	} else{
	        		finalResponse.averageRating = rating;
	        		callback(null, finalResponse);
	        	}
	        });
        },
        function(finalResponse, callback) { //Save average rating and total rating into user collection
            var obj = {
            	avg_rating: finalResponse.averageRating[0].avgRating,
            	total_rating: finalResponse.averageRating[0].count
            };
            User.findOneAndUpdate({ _id: sellerId, deleted: false}, {$set: obj}, {new: true})
            .lean()
            .exec(function(err, userInfo) {
                if (err) {
                    callback(err, null);
                }else {
                	finalResponse.userInfo = userInfo;
                	callback(null, finalResponse);
                }
            });
        },
    ],function(err, data) {
        if (err)
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        else {
            res.json(Response(constant.statusCode.ok, constant.messages.addReviewAndCommentSaveSuccessfully, finalResponse.addReviewInfo,null));
        }
    });
}

/**
 * Function is use to Get Seller Rating By SellerId
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 23-04-2018
 */
function getSellerRatingById(req, res){
    var sellerId = req.body.sellerId;
    Review.find({deleted: false, sellerId: sellerId})
    .lean().exec(function(err, reviewList){
        if (err){
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        }else {
            res.json(Response(constant.statusCode.ok, constant.messages.dataRetrievedSuccess, reviewList, null));
        }
    });
}