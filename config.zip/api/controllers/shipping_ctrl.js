'use strict';

var mongoose = require('mongoose'),
    common = require('../../config/common.js'),
    Error = require('../lib/error.js'),
    Response = require('../lib/response.js'),
    constant = require('../lib/constants.js'),
    waterfall = require('async-waterfall'),
    async = require('async'),
    User = mongoose.model('user'),
    shippo = require('shippo')('shippo_test_df6cc6d3757931666458b6588eccb445bc334ede');


// var addressFrom  = {
//     "name":"Ms Hippo",
//     "company":"Shippo",
//     "street1":"215 Clayton St.",
//     "city":"San Francisco",
//     "state":"CA",
//     "zip":"94117",
//     "country":"US", //iso2 country code
//     "phone":"+1 555 341 9393",
//     "email":"ms-hippo@goshippo.com",
// }

// // example address_to object dict
// var addressTo = {
//     "name":"Mr Hippo",
//     "company":"London Zoo",
//     "street1":"Regent's Park",
//     "street2":"Outer Cir",
//     "city":"LONDON",
//     "state":"",
//     "zip":"NW1 4RY",
//     "country":"GB", //iso2 country code
//     "phone":"+1 555 341 9393",
//     "email":"mrhippo@goshippo.com",
//     "metadata" : "Hippo T-Shirt Order #1043"
// }

// // parcel object dict
// var parcel = {
//     "length":"5",
//     "width":"5",
//     "height":"5",
//     "distance_unit":"in",
//     "weight":"2",
//     "mass_unit":"lb", 
// }

// // example CustomsItems object. This is required for int'l shipment only.
// var customsItem = {
//     "description":"T-Shirt",
//     "quantity":2,
//     "net_weight":"0.3",
//     "mass_unit":"lb",
//     "value_amount":"20",
//     "value_currency":"USD",
//     "origin_country":"US",
// }

// // Creating the CustomsDeclaration
// // (CustomsDeclaration are NOT required for domestic shipments)
// shippo.customsdeclaration.create({
//     "contents_type": "MERCHANDISE",
//     "non_delivery_option": "RETURN",
//     "certify": true,
//     "certify_signer": "Mr. Hippo",
//     "items": [customsItem],
// })
// .then(function(customsDeclaration) {
//     console.log("customs Declaration : %s", JSON.stringify(customsDeclaration, null, 4));
//     // Creating the shipment object. In this example, the objects are directly passed to the
//     // shipment.create method, Alternatively, the Address and Parcel objects could be created
//     // using address.create(..) and parcel.create(..) functions respectively.
//     // adding the async:false makes this call synchronous
//     return shippo.shipment.create({
//         "address_from": addressFrom,
//         "address_to": addressTo,
//         "parcels": [parcel],
//         "customs_declaration": customsDeclaration.object_id,
//         "async": false
//     })

// }, function(err) {
//     // Deal with an error
//     console.log("There was an error creating customs declaration: %s", err);
// })
// .then(function(shipment) {
//     console.log("shipment : %s", JSON.stringify(shipment, null, 4));
//     shippo.shipment.rates(shipment.object_id)
//     .then(function(rates) {
//         console.log("rates : %s", JSON.stringify(rates, null, 4));
//         // Get the first rate in the rates results for demo purposes.
//       var  rate = rates.results[4];
//         // console.log("***********************",rate);
//         // Purchase the desired rate
//         return shippo.transaction.create({"rate": rate.object_id, "async": false})
//     }).catch(function(err) {
//         // Deal with an error
//         console.log("There was an error retrieving rates : %s", err);
//     })
//     .then(function(transaction) {
//             console.log("transaction : %s", JSON.stringify(transaction, null, 4));
//             // print label_url and tracking_number
//             if(transaction.status == "SUCCESS") {
//                 console.log("Label URL: %s", transaction.label_url);
//                 console.log("Tracking Number: %s", transaction.tracking_number);
//             }else{
//                 //Deal with an error with the transaction
//                 console.log("Message: %s", JSON.stringify(transaction.messages, null, 2));
//             }

//     }).catch(function(err) {
//         // Deal with an error
//         console.log("There was an error creating transaction : %s", err);
//     });
// }).catch(function(err) {
//     // Deal with an error
//     console.log("There was an error creating shipment: %s", err);
// });






// // UPS Start Files

// // var ShipConfirm = require('../lib/ups/lib/shipConfirm');
// // var ShipAccept = require('../lib/ups/lib/shipAccept');
// // var AddressValidation = require('../lib/ups/lib/addressValidation');
// // var VoidShipment = require('../lib/ups/lib/voidShipment');
// // var TimeInTransit = require('../lib/ups/lib/timeInTransit');
// // var Rating = require('../lib/ups/lib/rating');
// // var Tracking = require('../lib/ups/lib/tracking');

// // var confirmShipment = new ShipConfirm('ED41FA609CBE0E28', 'silkhionline', 'Marketplace12');
// // confirmShipment.useSandbox(true);
// // confirmShipment.setJsonResponse(true);
// // // UPS End Files

// // module.exports = {
// //     getDashboardCount: getDashboardCount
// // };


// /**
//  * Function is use to get Dashboard 
//  * @access private
//  * @return json
//  * Created by Abhijit
//  * @smartData Enterprises (I) Ltd
//  * Created Date 10-Aug-2017
//  */
// function getDashboardCount(req, res) {}

// /*var obj = {
//     validate: "nonvalidate",
//     shipment: {
//         description: "Shipment to Philippines",
//         shipper: {
//             name: "Silkhi Inc.",
//             attentionName: "Silkhi Inc.",
//             phone: "6479847111",
//             shipperNumber: "658V5X",
//             phone: "6479847111",
//             address: {
//                 address1: "1511 Spinnaker Mews",
//                 address2: "Pickering",
//                 address3: "Pickering",
//                 city: "Ontario",
//                 state: "ON",
//                 country: "CA",
//                 zip: "L1X0C8"
//             }
//         },
//         shipTo: {
//             companyName: "Company Name",
//             attentionName: "Pedro Calunsod",
//             phone: "12321341",
//             address: {
//                 address1: "999 Warrior St.",
//                 address2: "Maria Cons. Subd. Shiper",
//                 address3: "Stage, Valley",
//                 city: "Stage City",
//                 state: "PH",
//                 country: "PH",
//                 zip: "2010"
//             }
//         },
//         payment: {
//             accountNumber: "658V5X"
//         },
//         service: {
//             code: "expedited"
//         },
//         UnitOfMeasurement: {
//             code: "IN"
//         },
//         package: [{
//             code: "02"            
//         }]
//     }
// };
// confirmShipment.makeRequest(obj, function(err, response){
//     console.log("UPS Error : ", err);
//     console.log("UPS Response : ", response);
// });*/
