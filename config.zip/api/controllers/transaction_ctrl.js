'use strict';

var mongoose = require('mongoose'),
    common = require('../../config/common.js'),
    Error = require('../lib/error.js'),
    Response = require('../lib/response.js'),
    constant = require('../lib/constants.js'),
    utility = require('../lib/utility.js'),
    waterfall = require('async-waterfall'),
    async = require('async'),
    User = mongoose.model('user'),
    Order = mongoose.model('order');

module.exports = {
    getPurchaseProductList: getPurchaseProductList,
    getSelledProductList: getSelledProductList
};



/**
 * Function is use to Get All Purchase Product List
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 16-Apr-2018
 */
function getPurchaseProductList(req, res) {

    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    var sorting = { createdAt: -1 };    
    var condition = { deleted: false, userId : mongoose.Types.ObjectId(req.body.userId)}; //
    
    // if ((req.body.fromdate && req.body.todate)) {
    //     var start = moment(req.body.fromdate).startOf('day'); // set to 12:00 am today
    //     var end = moment(req.body.todate).endOf('day'); // set to 23:59 pm today
    //     condition.createdAt = { '$gte': new Date(moment(start)), '$lte': new Date(moment(end)) };
    // }
    // if(req.body.serviceId){
    //    condition.serviceId = mongoose.Types.ObjectId(req.body.serviceId); 
    // }
    // if(req.body.subServiceId){
    //    condition.subServiceId = mongoose.Types.ObjectId(req.body.subServiceId); 
    // }
    // if(req.body.serviceType){
    //     condition.serviceType = req.body.serviceType;
    // }
    // if(req.body.status){
    //     condition.status = req.body.status.toString();
    // }
    // var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
    // if (req.body.searchText) {
    //     condition.$or = [
    //         { 'orderNo': parseInt(searchText) }, 
    //         { 'serviceInfo.serviceName': new RegExp(searchText, 'gi') },
    //         { 'subServiceInfo.name': new RegExp(searchText, 'gi') },
    //         { 'servicProviderInfo.firstname': new RegExp(searchText, 'gi') },
    //         { 'servicProviderInfo.lastname': new RegExp(searchText, 'gi') },
    //     ];
    // }
    
    var aggregateQuery = [
        {   //Product Image details
            $lookup: {
                from: "product_images",
                localField: "productImageId",
                foreignField: "_id",
                as: "productImageInfo"
            }
        },
        { $unwind: "$productImageInfo" },
        {   //Seller details
            $lookup: {
                from: "users",
                localField: "sellerId",
                foreignField: "_id",
                as: "sellerInfo"
            }
        },
        { $unwind: "$sellerInfo" },
        {   //Product details
            $lookup: {
                from: "products",
                localField: "productId",
                foreignField: "_id",
                as: "productInfo"
            }
        },
        { $unwind: "$productInfo" },
        {   //Size details
            $lookup: {
                from: "product_sizes",
                localField: "productInfo.sizeId",
                foreignField: "_id",
                as: "sizeInfo"
            }
        },
        { $unwind: "$sizeInfo" },
        {   //color details
            $lookup: {
                from: "product_colors",
                localField: "productInfo.color_1",
                foreignField: "_id",
                as: "colorInfo"
            }
        },
        { $unwind: "$colorInfo" },
        {   //currency details
            $lookup: {
                from: "currencies",
                localField: "productInfo.currency",
                foreignField: "_id",
                as: "productCurrencyInfo"
            }
        },
        { $unwind: "$productCurrencyInfo" },
        { $match: condition },
    ];
    var project = {
        $project: {
            orderDate: 1,
            deliverDate: 1,
            raiseRefundRequestDate: 1,
            expectedDeliverDate: 1,
            order_status: 1,
            productImageId: '$productImageInfo',
            productInfo: '$productInfo',
            sellerInfo: '$sellerInfo',
            sizeInfo: '$sizeInfo',
            colorInfo: '$colorInfo',
            productCurrencyInfo: '$productCurrencyInfo'
        }
    };

    var countQuery = [].concat(aggregateQuery);
    aggregateQuery.push(project);
    aggregateQuery.push({ $sort: sorting });
    aggregateQuery.push({ $skip: parseInt(skip) });
    aggregateQuery.push({ $limit: parseInt(count) });

    Order.aggregate(aggregateQuery).then(function(result) {
        countQuery.push({ $group: { _id: null, count: { $sum: 1 } } });
        Order.aggregate(countQuery).then(function(dataCount) {
            var cnt = (dataCount[0]) ? dataCount[0].count : 0;
            // data.totalCount = cnt;
            res.json({code: 200, message: constant.messages.dataRetrievedSuccess, data: result, totalCount: cnt });
            // res.json(Response(constant.statusCode.ok, constant.messages.dataRetrievedSuccess, data));
        });
    }).catch(function(err) {
        console.log("Err :: ", err)
        res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
    });
}
function getPurchaseProductList_bk(req, res){
    var userId = req.body.userId;
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    var sorting = utility.getSortObj(req.body);
    var condition = {deleted: false, userId: userId};
    // var a = moment();//now
    // var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
    // if (req.body.searchText) {
    //     condition.$or = [
    //         { 'title'  : new RegExp(searchText, 'gi') },
    //         { 'brand': new RegExp(searchText, 'gi') },
    //         { 'fabric': new RegExp(searchText, 'gi') },
    //         { 'product_status': new RegExp(searchText, 'gi') },
    //     ];
    // }
    Order.find(condition)
    .populate('sellerId')
    .populate('productId')
    .populate('productImageId')
    .limit(parseInt(count))
    .skip(parseInt(skip))
    .sort(sorting)
    .lean()
    .exec(function(err, result) {
        if (err) {
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        } else {
            Order.find(condition).count().exec(function(err, totalCount) {
                if (err) {
                    res.json({code: 201, message: constant.messages.requestNotProcessed, data: err});
                } else {                    
                    if(err){
                        res.json({code: 201, message: constant.messages.requestNotProcessed, data: err});
                    }else{
                        res.json({code: 200, message: constant.messages.dataRetrievedSuccess, data: result, totalCount: totalCount });
                    }
                }
            })
        }
    });
}

/**
 * Function is use to Get All Selled Product List
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 16-Apr-2018
 */
function getSelledProductList(req, res) {

    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    var sorting = { createdAt: -1 };    
    var condition = { deleted: false, sellerId : mongoose.Types.ObjectId(req.body.userId)};

    // if ((req.body.fromdate && req.body.todate)) {
    //     var start = moment(req.body.fromdate).startOf('day'); // set to 12:00 am today
    //     var end = moment(req.body.todate).endOf('day'); // set to 23:59 pm today
    //     condition.createdAt = { '$gte': new Date(moment(start)), '$lte': new Date(moment(end)) };
    // }
    // if(req.body.serviceId){
    //    condition.serviceId = mongoose.Types.ObjectId(req.body.serviceId); 
    // }
    // if(req.body.subServiceId){
    //    condition.subServiceId = mongoose.Types.ObjectId(req.body.subServiceId); 
    // }
    // if(req.body.serviceType){
    //     condition.serviceType = req.body.serviceType;
    // }
    // if(req.body.status){
    //     condition.status = req.body.status.toString();
    // }
    // var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
    // if (req.body.searchText) {
    //     condition.$or = [
    //         { 'orderNo': parseInt(searchText) }, 
    //         { 'serviceInfo.serviceName': new RegExp(searchText, 'gi') },
    //         { 'subServiceInfo.name': new RegExp(searchText, 'gi') },
    //         { 'servicProviderInfo.firstname': new RegExp(searchText, 'gi') },
    //         { 'servicProviderInfo.lastname': new RegExp(searchText, 'gi') },
    //     ];
    // }

    condition['productInfo.product_status'] = 'Out of Stock';
    var aggregateQuery = [
        {   //Product Image details
            $lookup: {
                from: "product_images",
                localField: "productImageId",
                foreignField: "_id",
                as: "productImageInfo"
            }
        },
        { $unwind: "$productImageInfo" },
        {   //Buyer details
            $lookup: {
                from: "users",
                localField: "userId",
                foreignField: "_id",
                as: "buyerInfo"
            }
        },
        { $unwind: "$buyerInfo" },
        {   //Seller details
            $lookup: {
                from: "users",
                localField: "sellerId",
                foreignField: "_id",
                as: "sellerInfo"
            }
        },
        { $unwind: "$sellerInfo" },
        {   //Product details
            $lookup: {
                from: "products",
                localField: "productId",
                foreignField: "_id",
                as: "productInfo"
            }
        },
        { $unwind: "$productInfo" },
        {   //Size details
            $lookup: {
                from: "product_sizes",
                localField: "productInfo.sizeId",
                foreignField: "_id",
                as: "sizeInfo"
            }
        },
        { $unwind: "$sizeInfo" },
        {   //color details
            $lookup: {
                from: "product_colors",
                localField: "productInfo.color_1",
                foreignField: "_id",
                as: "colorInfo"
            }
        },
        { $unwind: "$colorInfo" },
        {   //currency details
            $lookup: {
                from: "currencies",
                localField: "productInfo.currency",
                foreignField: "_id",
                as: "productCurrencyInfo"
            }
        },
        { $unwind: "$productCurrencyInfo" },
        { $match: condition },
    ];
    var project = {
        $project: {
            orderDate: 1,
            deliverDate: 1,
            raiseRefundRequestDate: 1,
            expectedDeliverDate: 1,
            order_status: 1,
            productImageId: '$productImageInfo',
            productInfo: '$productInfo',
            sellerInfo: '$sellerInfo',
            sizeInfo: '$sizeInfo',
            colorInfo: '$colorInfo',
            productCurrencyInfo: '$productCurrencyInfo',
            buyerInfo: '$buyerInfo'
        }
    };

    var countQuery = [].concat(aggregateQuery);
    aggregateQuery.push(project);
    aggregateQuery.push({ $sort: sorting });
    aggregateQuery.push({ $skip: parseInt(skip) });
    aggregateQuery.push({ $limit: parseInt(count) });

    Order.aggregate(aggregateQuery).then(function(result) {
        countQuery.push({ $group: { _id: null, count: { $sum: 1 } } });
        Order.aggregate(countQuery).then(function(dataCount) {
            var cnt = (dataCount[0]) ? dataCount[0].count : 0;
            res.json({code: 200, message: constant.messages.dataRetrievedSuccess, data: result, totalCount: cnt });
            // res.json(Response(constant.statusCode.ok, constant.messages.dataRetrievedSuccess, data));
        });
    }).catch(function(err) {
        console.log("Err :: ", err)
        res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
    });
}

function getSelledProductList_bk(req, res){
    var userId = req.body.userId;
    var finalResponse = {};

    waterfall([
        function(callback) {
            User.findOne({ _id : userId, deleted: false}).lean().exec(function(err, userInfo) {
                if (err) {
                    callback(err, null);
                } else {
                    finalResponse.userInfo = userInfo;
                   callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) {
            Order.find({sellerId: userId, deleted: false}).lean().exec(function(err, selledList){
                if(err){

                }else{
                    finalResponse.selledList = selledList;
                    callback(null, finalResponse);
                }
            });
        },
    ],function(err, data) {
        if (err){
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        } else {
            res.json(Response(constant.statusCode.ok, constant.messages.dataRetrievedSuccess, data, null));
        }
    });
}

