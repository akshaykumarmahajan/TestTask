'use strict';

var mongoose = require('mongoose'),
    common = require('../../config/common.js'),
    Error = require('../lib/error.js'),
    Response = require('../lib/response.js'),
    constant = require('../lib/constants.js'),
    waterfall = require('async-waterfall'),
    async = require('async'),
    User = mongoose.model('user'),
    Currency = mongoose.model('currency'),
    Product = mongoose.model('product'),
    ProductWishList = mongoose.model('product_wish_list'),
    Notification = mongoose.model('notification');

module.exports = {
    addProductToWishList: addProductToWishList, 
    getWishListByUserId: getWishListByUserId,
    deleteProductFromWishList: deleteProductFromWishList
};



/**
 * Function is use to add Product To Wish List
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 22-03-2018
 */
function addProductToWishList(req, res){
    // console.log("Add Wish List : ", req.body);
    var productId = req.body.productId,
        userId = req.body.userId;
    var finalResponse = {};
    waterfall([
        function(callback) {
            Product.findOne({_id: productId, deleted: false})
            .lean()
            .exec(function(err, productInfo) {
                if (err) {
                    callback(constant.messages.requestNotProcessed, null);
                } else if(productInfo){
                    finalResponse.productInfo = productInfo;
                    callback(null, finalResponse);
                }else{
                    callback(constant.messages.productNotFound, null);
                }
            });
        },
        function(finalResponse, callback) {
            ProductWishList.find({userId: userId, productId: productId, deleted: false}, function(err, productExistInfo){
                if(err){
                    callback(constant.messages.requestNotProcessed, null);
                }else if(productExistInfo.length > 0){
                    callback(constant.messages.productAlreadyInWishList, null);
                }else{
                    callback(null, finalResponse);
                }
            })
        },
        function(finalResponse, callback) {
            var product_obj = {
                userId : req.body.userId,
                productId : req.body.productId,
                featuredImageId : finalResponse.productInfo.featuredImageId
            };
            var wishListRecord = new ProductWishList(product_obj);
            wishListRecord.save(function (err, wishListData) {
                if (err){
                    callback(constant.messages.requestNotProcessed, null);
                }else {
                    finalResponse.wishListData = wishListData;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) {
            ProductWishList.find({userId: userId, deleted: false}).count().lean().exec(function (err, wishListCount) {
                if (err){
                    callback(constant.messages.requestNotProcessed, null);
                }else {
                    console.log("wishListCount", wishListCount);
                    finalResponse.wishListCount = wishListCount;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback){
            var notiObj = {
                sourceUser      : userId,
                destnationUser  : userId,
                productId       : productId,
                notifyType      : 'Wishlist',
                content         : req.body.message,
                createdBy       : 'user'
            };
            new Notification(notiObj).save(function(err, notiData) {
                if (err) {
                    console.log("Notification Save Err :: ",err);
                    callback(null, finalResponse);
                } else {
                    callback(null, finalResponse);
                }
            });
        }
    ],function(err, data) {
        if (err)
            res.jsonp(Error(constant.statusCode.error, err, err));
        else {
            res.json(Response(constant.statusCode.ok, constant.messages.addToWishList, data, null));
        }
    });    
}

/**
 * Function is use to Get Wish List By UserId
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 22-03-2018
 */
function getWishListByUserId(req, res){
    console.log("Get Wish List : ", req.body);

    var userId = req.body.userId;
    ProductWishList.find({userId: userId, deleted: false})
    .populate('productId')
    .populate('featuredImageId')
    .lean()
    .exec(function(err, wishList){
        if (err){
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        }
        else {
            async.each(wishList, function(item, callback){
                Currency.findOne({_id : item.productId.currency}, function(err, currencyInfo){
                    item.productId.currency = currencyInfo;
                    callback();
                });
            }, function(err){
                res.json(Response(constant.statusCode.ok, constant.messages.wishListSuccess, wishList, null));
            });
        }
    });    
}

/**
 * Function is use to Get Wish List By UserId
 * @access private
 * @return json
 * Created by Abhijit
 * @smartData Enterprises (I) Ltd
 * Created Date 22-03-2018
 */
function deleteProductFromWishList(req, res){
    console.log("Get Wish List : ", req.body);
    var productId = req.body.productId,
        userId = req.body.userId;
    var finalResponse = {};

    waterfall([
        function(callback) {
            User.findOne({_id: userId, deleted: false}).lean().exec(function(err, userInfo) {
                if (err) {
                    callback(constant.messages.requestNotProcessed, null);
                } else {
                    finalResponse.userInfo = userInfo;
                    callback(null, finalResponse);
                }
            });
        },
        function(finalResponse, callback) {
            ProductWishList.findOne({ _id: productId, userId: userId})
            .lean()
            .exec(function(err, productInfo) {
                if (err) {
                    callback(constant.messages.requestNotProcessed, null);
                } else if(productInfo){
                    finalResponse.productInfo = productInfo;                       
                    callback(null, finalResponse);
                }else {
                    callback(constant.messages.productAlreadyRemoved, null);
                }
            });
        },
        function(finalResponse, callback) {
            var obj = {deleted: true};
            ProductWishList.findOneAndUpdate({ _id: productId, userId: userId}, {$set: obj}, {new: true})
            .lean()
            .exec(function(err, productInfo) {
                if (err) {
                    callback(constant.messages.requestNotProcessed, null);
                }else {
                    ProductWishList.find({userId: userId, deleted: false})
                    .count()
                    .lean()
                    .exec(function(err, wishList){
                        if(err){
                            callback(constant.messages.requestNotProcessed, null);
                        }else{
                            finalResponse.wishList = wishList;
                            callback(null, finalResponse);
                        }
                    });
                }
            });
        },
    ],function(err, data) {
        if (err)
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        else {
            res.json(Response(constant.statusCode.ok, constant.messages.removeFromWishlist, data, null));
        }
    });
}