'use strict';

var mongoose = require('mongoose');

var currencySchema = new mongoose.Schema({
    country: 			{type: String, dufault: null },
	currency: 			{type: String, dufault: null },
	abbreviation:  		{type: String, dufault: null },
	symbol: 			{type: String, dufault: null },
	other: 				{},
    status:             {type: Number, default: 1 },       //0-InActive, 1-Active
    deleted:            {type: Boolean, default: false },
}, {
    timestamps: true
});

var Currency = mongoose.model('currency', currencySchema);
module.exports = Currency;
// Currency.update({ _id: { $nin: ['5aaba6928657962c7a3a58dc', '5aaba6918657962c7a3a5817', '5aaba6928657962c7a3a58db', '5aaba6918657962c7a3a5841', '5aaba6928657962c7a3a5855'] } }, { $set: { deleted : true } }, {"multi": true}).then(function(respon){
//     console.log(respon)
// });