'use strict';

var mongoose = require('mongoose');

var internalMessageSchema = new mongoose.Schema({
    to:             {type: mongoose.Schema.Types.ObjectId, ref: 'user', required: true}, 
    from:           {type: mongoose.Schema.Types.ObjectId, ref: 'user', required: true},
    productId:      {type: mongoose.Schema.Types.ObjectId, ref: 'product', required: true},
    product_image:  {type: mongoose.Schema.Types.ObjectId, ref: 'product_image'},
    subject:        {type: String, default: ''},
    description:    {type: String, default: ''},
    isSentBy:       {type: String, enum: ['Buyer', 'Seller']},
    status:         {type: Number, default: 1},       //1-send, 0-Failed    
    toIsRead:       {type: Boolean, default: false},       
    fromIsRead:     {type: Boolean, default: false},       
    deleted:        {type: Boolean, default: false},       
}, {
    timestamps: true
});

var internalMessage = mongoose.model('internal_message', internalMessageSchema);
module.exports = internalMessage;