'use strict';

var mongoose = require('mongoose');

var notificationSchema = new mongoose.Schema({
	sourceUser:               {type: mongoose.Schema.Types.ObjectId, ref: 'user'},
    destnationUser:           {type: mongoose.Schema.Types.ObjectId, ref: 'user'},
    productId:          	  {type: mongoose.Schema.Types.ObjectId, ref: 'productId'},
    notifyType: 			  {type: String, enum: ['Message','Product', 'Notification', 'Wishlist'], default: 'Message'},
    createdBy:      		  {type: String, enum: ['seller','user', 'admin'], default: 'user'},
    content:                  {type: String,  default: '' },
    isRead:             	  {type: Boolean, default: false},
    deleted:          		  {type: Boolean, default: false}
}, {
    timestamps: true
});

module.exports = mongoose.model('notification', notificationSchema);