'use strict';

var mongoose = require('mongoose');

var paymentSchema = new mongoose.Schema({
	userId: 					{type: mongoose.Schema.Types.ObjectId, ref: 'user', require: true},
	sellerId:          			{type: mongoose.Schema.Types.ObjectId, ref: 'user', require: true},
	productId: 					{type: mongoose.Schema.Types.ObjectId, ref: 'product', require: true},
	categoryId: 				{type: mongoose.Schema.Types.ObjectId, ref: 'product_category', default: null},
	subCategoryId: 				{type: mongoose.Schema.Types.ObjectId, ref: 'product_sub_category', default: null},
	productImageId:				{type: mongoose.Schema.Types.ObjectId, ref: 'product_image', default: null},
	shippingAddressId: 			{type: mongoose.Schema.Types.ObjectId, ref: 'shipping_address', default: null},
	shippingId: 				{type: mongoose.Schema.Types.ObjectId, ref: 'shipping_detail', default: null},
	
	payment_unique_id: 			{type: String, default: null},
	
	total_amount: 				{type: Number, default: null},
	processing_fees: 			{type: Number, default: null},
	commision: 					{type: Number, default: null},	
	product_amount: 			{type: Number, default: null},
	shipping_amount: 			{type: Number, default: null},

	paypal_payment_id:    		{type: String, default: null},
	paypal_response_message:    {type: Boolean, default: false},
	paypal_response_code: 		{type: String, default: null},
	paypal_response_json: 		{},

	final_invoice_user: 		{type: String, default: null},
	final_invoice_seller: 		{type: String, default: null},

	is_refund:    				{type: Boolean, default: false},
	refund_id: 					{type: mongoose.Schema.Types.ObjectId, ref: 'refund', default: null},

	// payment_status:				{type: String, enum: ['succeeded', 'pending', 'failed'], default: 'pending'},
	payment_status:				{type: String, default: 'pending'},
	status:  					{type: Number, default: 1},       //0-InActive, 1-Active, 2- Deactive
	
	deleted:  					{type: Boolean, default: false},
}, {
    timestamps: true
});

var Payment = mongoose.model('payment', paymentSchema);
module.exports = Payment;