'use strict';

var mongoose = require('mongoose');

var permissionSchema = new mongoose.Schema({
    adminId:                {type: mongoose.Schema.Types.ObjectId, ref: 'user'},
    dashboard:              {type: Boolean, default: true},   
    emailTemplate:          {type: Boolean, default: true},   
    transaction:            {type: Boolean, default: false},
    product:                {type: Boolean, default: false},
    category:               {type: Boolean, default: false},
    payment:                {type: Boolean, default: false},
    setting:                {type: Boolean, default: false},
    users:                  {type: Boolean, default: false},
    buyer:                  {type: Boolean, default: false},
    seller:                 {type: Boolean, default: false},
}, {
    timestamps: true
});

// module.exports = mongoose.model('permission', permissionSchema);
var Permission = mongoose.model('permission', permissionSchema);
module.exports = Permission;

// var obj = {
// 	adminId: '5aaf57cecefc63d7fe043ba1',
// 	dashboard : true,
// 	emailTemplate: true,
// 	transaction: true,
// 	product: true,
// 	category: true,
// 	payment: true,
// 	setting: true,
// 	users: true,
// }
// var perObj = new Permission(obj);
// perObj.save(function(err, res){
// 	console.log('err', err);
// 	console.log('res', res);
// })