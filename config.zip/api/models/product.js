'use strict';

var mongoose = require('mongoose');

var productSchema = new mongoose.Schema({
    sellerId:                       {type: mongoose.Schema.Types.ObjectId, ref: 'user', required: true},
    categoryId:                     {type: mongoose.Schema.Types.ObjectId, ref: 'product_category', required: true},
    sizeId:                         {type: mongoose.Schema.Types.ObjectId, ref: 'product_size', required: true},
    sub_categoryId:                 {type: mongoose.Schema.Types.ObjectId, ref: 'product_sub_category', default: null},
    modifiedById:                   {type: mongoose.Schema.Types.ObjectId, ref: 'user', default: null},
    featuredImageId:                {type: mongoose.Schema.Types.ObjectId, ref: 'product_image', default: null},
    currency:                       {type: mongoose.Schema.Types.ObjectId, ref: 'currency'},
    condition:                      {type: mongoose.Schema.Types.ObjectId, ref: 'product_condition'},    
    color_1:                        {type: mongoose.Schema.Types.ObjectId, ref: 'product_color'},    
    color_2:                        {type: mongoose.Schema.Types.ObjectId, ref: 'product_color'},    
    occasion:                       {type: mongoose.Schema.Types.ObjectId, ref: 'product_occasion', required: true},
    // name:                           {type: String, required: true },
    productUniqueId:                {type: String, default: null },
    title:                          {type: String, required: true },
    description:                    {type: String, default: ''},    
    fabric:                         {type: String, default: null },
    brand:                          {type: String, default: null },
    price:                          {type: Number, default: null },
    modifiedBy:                     {type: String, default: null },
    modifiedDate:                   {type: Date, default: Date.now },
    discount:                       {type: Number, default: null },
    isFreeShipping:                 {type: Boolean, default: false },
    quantity:                       {type: Number, default: 0 },
    total_review:                   {type: Number, default: 0 },
    total_rating:                   {type: Number, default: 0 },
    avg_rating:                     {type: Number, default: 0 },
    rating_5_star:                  {type: Number, default: 0 },
    rating_4_star:                  {type: Number, default: 0 },
    rating_3_star:                  {type: Number, default: 0 },
    rating_2_star:                  {type: Number, default: 0 },
    rating_1_star:                  {type: Number, default: 0 },
    product_status:                 {type: String, enum:['In-Stock', 'Out of Stock'], default: 'In-Stock' },
    isWishList:                     {type: Boolean, default: false },
    status:                         {type: Number, default: 0 },       //0-InActive, 1-Active
    deleted:                        {type: Boolean, default: false },
}, {
    timestamps: true
});

var Product = mongoose.model('product', productSchema);
module.exports = Product;

// Product.update({}, { $set: {
//     occasion : '5ae01390b13a6e15e3e5d068'}
// }, {"multi": true}).then(function(respon){
//     console.log(respon)
// });