'use strict';

var mongoose = require('mongoose');

var productCategorySchema = new mongoose.Schema({
    categoryId:                     {type: mongoose.Schema.Types.ObjectId, ref: 'product_category', default: null},
    addedBy:                        {type: mongoose.Schema.Types.ObjectId, ref: 'user', required: true},
    updatedBy:                      {type: mongoose.Schema.Types.ObjectId, ref: 'user', default: null},
    name:                           {type: String, required: true },
    description:                    {type: String, default: null },
    isSubCategory: 					{type: Boolean, default: false },
    status:                         {type: Number, default: 1 },       //0-InActive, 1-Active
    deleted:                        {type: Boolean, default: false },
}, {
    timestamps: true
});

var ProductCategory = mongoose.model('product_category', productCategorySchema);
module.exports = ProductCategory;
// ProductCategory.update({}, { $set: {
//     categoryId : null, isSubCategory: false}
// }, {"multi": true}).then(function(respon){
//     console.log(respon)
// });