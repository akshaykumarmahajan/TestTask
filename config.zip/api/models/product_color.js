'use strict';

var mongoose = require('mongoose');

var productColorSchema = new mongoose.Schema({
    // productId:            {type: mongoose.Schema.Types.ObjectId, ref: 'product', required: true},
    color_code:           {type: String, required: true },
    color_name:           {type: String, required: true },
    hex_code:             {type: String, required: true },
    status:               {type: Number, default: 1 },       //0-InActive, 1-Active
    class: 				  {type: String, required: true},
    deleted:              {type: Boolean, default: false },
}, {
    timestamps: true
});

var ProductColor = mongoose.model('product_color', productColorSchema);
module.exports = ProductColor;