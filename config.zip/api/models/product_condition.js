'use strict';

var mongoose = require('mongoose');

var productConditionSchema = new mongoose.Schema({
    name: 		{type: String, dufault: null },
	status: 	{type: Number, default: 1 },       //0-InActive, 1-Active
    deleted: 	{type: Boolean, default: false },
}, {
    timestamps: true
});

var ProductCondition = mongoose.model('product_condition', productConditionSchema);
module.exports = ProductCondition;