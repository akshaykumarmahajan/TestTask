'use strict';

var mongoose = require('mongoose');

var productImageSchema = new mongoose.Schema({
    productId:                      {type: mongoose.Schema.Types.ObjectId, ref: 'product', required: true},
    addedBy:                        {type: mongoose.Schema.Types.ObjectId, ref: 'user', required: true},
    image_url:                      {type: String, default: 'noImage.jpg' },
    video_url:                      {type: String, default: null },
    gif_url:                        {type: String, default: null },
    is_featured:                    {type: Boolean, default: false },
    status:                         {type: Number, default: 0 },       //0-InActive, 1-Active
    deleted:                        {type: Boolean, default: false },
}, {
    timestamps: true
});

var ProductImage = mongoose.model('product_image', productImageSchema);
module.exports = ProductImage;