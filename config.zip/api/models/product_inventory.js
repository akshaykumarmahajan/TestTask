'use strict';

var mongoose = require('mongoose');

var productInventorySchema = new mongoose.Schema({
    productId:                      {type: mongoose.Schema.Types.ObjectId, ref: 'product', required: true},
    categoryId:                     {type: mongoose.Schema.Types.ObjectId, ref: 'product_category', required: true},
    subCategoryId:                  {type: mongoose.Schema.Types.ObjectId, ref: 'product_sub_category', default: null},
    sizeId:                         {type: mongoose.Schema.Types.ObjectId, ref: 'product_size', required: true},
    colorId:                        {type: mongoose.Schema.Types.ObjectId, ref: 'product_color', required: true},
    actual_count:                   {type: Number, default: 0 },
    original_count:                 {type: Number, default: 0 },
    status:                         {type: Number, default: 1 },       //0-InActive, 1-Active
    deleted:                        {type: Boolean, default: false },
}, {
    timestamps: true
});

var ProductInventory = mongoose.model('product_inventory', productInventorySchema);
module.exports = ProductInventory;