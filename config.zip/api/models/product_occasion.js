'use strict';

var mongoose = require('mongoose');

var productOccasionSchema = new mongoose.Schema({
	addedBy: 	{type: mongoose.Schema.Types.ObjectId, ref: 'user', required: true},
	updatedBy: 	{type: mongoose.Schema.Types.ObjectId, ref: 'user', default: null},
    name: 		{type: String, required: true },
    description:{type: String, dufault: null },
	status: 	{type: Number, default: 1 },       //0-InActive, 1-Active
    deleted: 	{type: Boolean, default: false },
}, {
    timestamps: true
});

var ProductOccasion = mongoose.model('product_occasion', productOccasionSchema);
module.exports = ProductOccasion;