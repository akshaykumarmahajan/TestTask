'use strict';

var mongoose = require('mongoose');

var productSizeSchema = new mongoose.Schema({
    // productId:            {type: mongoose.Schema.Types.ObjectId, ref: 'product', required: true},
    name:                 {type: String, required: true },
    type:                 {type: String, enum: ['Text', 'Number'], default: 'Text' },
    status:               {type: Number, default: 1 },       //0-InActive, 1-Active
    deleted:              {type: Boolean, default: false },
}, {
    timestamps: true
});

var ProductSize = mongoose.model('product_size', productSizeSchema);
module.exports = ProductSize;