'use strict';

var mongoose = require('mongoose');

var productSubCategorySchema = new mongoose.Schema({
    // productId:                      {type: mongoose.Schema.Types.ObjectId, ref: 'product', required: true},
    categoryId:                     {type: mongoose.Schema.Types.ObjectId, ref: 'product_category', required: true},
    addedId:                        {type: mongoose.Schema.Types.ObjectId, ref: 'user', required: true},
    name:                           {type: String, required: true },
    description:                    {type: String, default: null },
    status:                         {type: Number, default: 0 },       //0-InActive, 1-Active
    deleted:                        {type: Boolean, default: false },
}, {
    timestamps: true
});

var ProductSubCategory = mongoose.model('product_sub_category', productSubCategorySchema);
module.exports = ProductSubCategory;