'use strict';

var mongoose = require('mongoose');

var wishListSchema = new mongoose.Schema({
	userId: 			{type: mongoose.Schema.Types.ObjectId, ref: 'user', required: true},
	productId:       	{type: mongoose.Schema.Types.ObjectId, ref: 'product', required: true},
	featuredImageId:   	{type: mongoose.Schema.Types.ObjectId, ref: 'product_image', default: null},
	status:  			{type: Number, default: 1},       //0-InActive, 1-Active
	deleted:  			{type: Boolean, default: false},
}, {
    timestamps: true
});

var WishList = mongoose.model('product_wish_list', wishListSchema);
module.exports = WishList;