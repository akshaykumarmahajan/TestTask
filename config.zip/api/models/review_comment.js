'use strict';

var mongoose = require('mongoose');

var reviewCommentSchema = new mongoose.Schema({
	userId: 			{type: mongoose.Schema.Types.ObjectId, ref: 'user', required: true},
	sellerId:       	{type: mongoose.Schema.Types.ObjectId, ref: 'user', default: null},
	productId:       	{type: mongoose.Schema.Types.ObjectId, ref: 'product', default: null},
	productImageId:     {type: mongoose.Schema.Types.ObjectId, ref: 'product_image', default: null},
	review: 			{type: Number, default: 0},
	comment: 			{type: String, default: null},
	status:  			{type: Number, default: 1},       //0-InActive, 1-Active
	deleted:  			{type: Boolean, default: false},
}, {
    timestamps: true
});

var ReviewComment = mongoose.model('review_comment', reviewCommentSchema);
module.exports = ReviewComment;
// var obj = {
// 	userId : '5ab4fea7390dbc3a78305e0c',
// 	sellerId: '5aa61cb8d0f3e9e0f8563381',
// 	productId: '5ac22b329b8d0333f9b490ac',
// 	review: 4,
// 	comment: 'Product is not good'
// };
// new ReviewComment(obj).save(function(err, res){
// 	console.log('Err :: ', err);
// 	console.log('Res :: ', res);
// });

// ReviewComment.update({}, { $set: {productImageId: '5ac22bf29b8d0333f9b490b8'} }, {"multi": true}).then(function(respon){
//     console.log(respon)
// });