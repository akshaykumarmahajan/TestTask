'use strict';

var mongoose = require('mongoose');

var settingSchema = new mongoose.Schema({
	updatedBy: 					{type: mongoose.Schema.Types.ObjectId, ref: 'user', required: true},
	commission: 				{type: Number, default: 0},
	processing_fees:    		{type: Number, default: 0},
	company_number: 			{type: String, default: ''},
	company_email: 				{type: String, default: ''},
	company_name: 				{type: String, default: ''},
	company_address_line_1: 	{type: String, default: ''},
	company_address_line_2: 	{type: String, default: ''},
	company_city: 				{type: String, default: ''},
	company_state: 				{type: String, default: ''},
	company_zipcode: 			{type: String, default: ''},
	company_fax: 				{type: String, default: ''},
	company_country: 			{type: String, default: ''},
	status:  					{type: Number, default: 1},       //0-InActive, 1-Active
	deleted:  					{type: Boolean, default: false},
}, {
    timestamps: true
});

var Setting = mongoose.model('setting', settingSchema);
module.exports = Setting;