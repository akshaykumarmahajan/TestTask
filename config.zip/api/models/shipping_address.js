'use strict';

var mongoose = require('mongoose');

var shippingAddressSchema = new mongoose.Schema({
    userId:                 {type: mongoose.Schema.Types.ObjectId, ref: 'user', required: true},
    productId:              {type: mongoose.Schema.Types.ObjectId, ref: 'product', required: true},
	
    firstname:              {type: String, required: true},
    lastname:               {type: String, required: true},
    country:                {type: String, required: true},
    address_line_1:         {type: String, required: true},
    address_line_2:         {type: String, default: ''},
    city:                   {type: String, required: true},
    state:                  {type: String, required: true},
    zipcode:                {type: String, required: true},
    pnhone_number:          {type: String, required: true},

	status:  			    {type: Number, default: 0},       //0-InActive, 1-Active
	deleted:  			    {type: Boolean, default: false},
}, {
    timestamps: true
});

var ShippingAddressDetails = mongoose.model('shipping_address', shippingAddressSchema);
module.exports = ShippingAddressDetails;