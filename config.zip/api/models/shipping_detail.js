'use strict';

var mongoose = require('mongoose');

var shippingSchema = new mongoose.Schema({
	sellerId: 			    {type: mongoose.Schema.Types.ObjectId, ref: 'user', required: true},
	userId: 			    {type: mongoose.Schema.Types.ObjectId, ref: 'user', required: true},
    productId:       	    {type: mongoose.Schema.Types.ObjectId, ref: 'product', required: true},
    paymentId:       	    {type: mongoose.Schema.Types.ObjectId, ref: 'payment', required: true},
    categoryId:       	    {type: mongoose.Schema.Types.ObjectId, ref: 'product_category', required: true},
    subCategoryId:          {type: mongoose.Schema.Types.ObjectId, ref: 'product_sub_category', default: null},
    shippingAddressId:      {type: mongoose.Schema.Types.ObjectId, ref: 'shipping_address', default: null},
    productImageId:         {type: mongoose.Schema.Types.ObjectId, ref: 'product_image', default: null},

    // Shipping Info
    shippingNo:             {type: String, default: ''},
    shippingWeight:         {type: Number, default: 0},
    shippingCount:          {type: Number, default: 0},
    shippingCharge:         {type: Number, default: 0},
    shippingRes:            {},
    shippingDate:           {type: Date, default: Date.now},
    deliverDate:            {type: Date, default: Date.now},
    expectedDeliverDate:    {type: Date, default: Date.now},
    
    // Seller Info
    seller_name:            {type: String, default: ''},
    seller_number:          {type: String, default: ''},
    seller_address_line_1:  {type: String, default: ''},
    seller_address_line_2:  {type: String, default: ''},
    seller_city:            {type: String, default: ''},
    seller_state:           {type: String, default: ''},
    seller_zipcode:         {type: String, default: ''},
    seller_lat:             {type: Number, default: ''},
    seller_lng:             {type: Number, default: ''},

    // Buyer Info
    buyer_name:            {type: String, default: ''},
    buyer_number:          {type: String, default: ''},
    buyer_address_line_1:  {type: String, default: ''},
    buyer_address_line_2:  {type: String, default: ''},
    buyer_city:            {type: String, default: ''},
    buyer_state:           {type: String, default: ''},
    buyer_zipcode:         {type: String, default: ''},
    buyer_lat:             {type: Number, default: ''},
    buyer_lng:             {type: Number, default: ''},

	status:  			    {type: Number, default: 0},       //0-InActive, 1-Active
	deleted:  			    {type: Boolean, default: false},
}, {
    timestamps: true
});

var ShippingDetails = mongoose.model('shipping_detail', shippingSchema);
module.exports = ShippingDetails;