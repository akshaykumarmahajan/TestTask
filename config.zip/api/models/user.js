'use strict';

var mongoose = require('mongoose');

var userSchema = new mongoose.Schema({
    paypalId:                       {type: mongoose.Schema.Types.ObjectId, ref: 'user', default: null},
    shipping_address_1:             {type: mongoose.Schema.Types.ObjectId, ref: 'shipping_address', default: null},
    firstname:                      {type: String, required: true },
    lastname:                       {type: String, required: true },
    username:                       {type: String, default: ''},    
    userUniqueId:                   {type: String, default: ''},    
    email:                          {type: String, lowercase: true, required: true, unique: true },
    password:                       {type: String, required: true },
    phone_number:                   {type: String, default: null },
    alternate_number:               {type: String, default: null },
    profile_pic:                    {type: String, default: 'noUser.jpg' },
    address_line_1:                 {type: String, default: null },
    address_line_2:                 {type: String, default: null },
    city:                           {type: String, default: null },
    state:                          {type: String, default: null },
    zipcode:                        {type: String, default: null },
    country:                        {type: String, default: null },
    latitude:                       {type: Number, default: 0 },
    longitude:                      {type: Number, default: 0 },
    status:                         {type: Number, default: 0 },
    uniqueId:                       {type: String, default: null },
    token:                          {type: String, default: '' },     // TOken to access all API's
    verification_token:             {type: String, default: '' },
    gender:                         {type: String, enum: ['Male', 'Female']},
    dob:                            {type: Date,   default: null },    
    joinDate:                       {type: Date,   default: Date.now },
    status:                         {type: Number, default: 0 },       //0-InActive, 1-Active, 2- Deactive
    deleted:                        {type: Boolean, default: false },
    is_email_verified:              {type: Boolean, default: false },
    is_phone_verified:              {type: Boolean, default: false },
    invite_count:                   {type: Number, default: 0 },
    avg_rating:                     {type: Number, default: 0 },
    total_rating:                   {type: Number, default: 0 },
    role:                           {type: String, enum: ['Buyer', 'Seller', 'Admin'], default: 'Buyer' },
    bio:                            {type: String, default: null },
    paypal_email:                   {type: String, default: null },
    product_buy_count:              {type: Number, default: 0},
    product_sell_count:             {type: Number, default: 0},
}, {
    timestamps: true
});

var User = mongoose.model('user', userSchema);
module.exports = User;