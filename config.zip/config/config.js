'use strict';

const config = {

    staging: {
        port: 5109,
        db: {
            user: 'C2CMarketplace',
            password: 'C2CMarketplace2018',
            url: 'mongodb://localhost:27017/C2CMarketplace'
        },
        baseUrl: 'http://52.34.207.5:5109/',
        smtp: {
            service: 'Gmail',
            username: 'c2cmarketplace.sdn@gmail.com',
            password: 'Password@aa01',
            host: 'smtp.gmail.com',
            mailUsername: 'C2CMarketplace',
            verificationMail: 'c2cmarketplace.sdn@gmail.com'
        },
        cryptoAlgorithm: 'aes-256-ctr',
        cryptoPassword: 'd6F3Efeq',
        secret: 'C2CMarketplace',
        googleApiKey: 'AIzaSyDzmSSIf0sBm22lbD2KSlGJTtfX_b_lchU',
        ARApiKey: 'orkgzt1hgput175ilvjxk7xw1',
        twitter: {
            //viral content keys
            "consumer_key": "Hi49IUUJtNmvF0FVhzdLdMmGH",
            "consumer_secret": "lnmzXgrIT40qAOUpB9mfqlSEfd9XHIfYSjDiDBUmtsqj3K45Mr",
            "callback_url": "callback_twitter",
            "access_type": "read-write",
            "defaultLiveFeedCount": 100,
            "maxLimitTweetText": 140,
            "defaultFollowingCount": 20
        },
        facebook: {
            //A2Z Test (LUXSDN)
            "client_id": "112393802767798",
            "client_secret": "64ff854f676d351cdc0ee0648065227f",
            // Viral Content System App
            // "client_id": "682077881938779",
            // "client_secret": "1934cdfb0546f2b215b44e2b411e5e14",
            "redirect_uri": "callback_facebook",
            "defaultLiveFeedCount": 3,
            "maxLimitText": 140,
            "defaultFollowingCount": 20,
            "scope": "email, user_about_me, user_birthday, user_location, publish_actions, publish_pages, user_posts, user_likes, user_photos,read_insights,manage_pages"
        },
        instagram: {
            "client_id": "8d0e2038fbfe446089d059e48cee2e73",
            "client_secret": "5e48e2c2aa2f4ae28feabe86c2a66543",
            "redirect_uri": "callback_instagram",
            "defaultLiveFeedCount": 100,
            "maxLimitText": 140,
            "defaultFollowingCount": 20,
            "scope": ['likes', 'comments', 'relationships', 'public_content', 'follower_list', 'basic']
        },
        apn: {
            certPath: './../../config/pem/dev/C2CmarketplaceCertR.pem',
            keyPath: './../../config/pem/dev/C2CmarketplaceKeyR.pem',
            passphrase: '1234',
            gateway: 'gateway.sandbox.push.apple.com',
            port: 2195
        },
        fcm: {
            serverKey: 'AAAAV1lZASs:APA91bGnE-w43VFSWBkVJUCoPFPnRiPD_5puI0pKpP9ZIOFoL9QrMNmEViXrBCBZJRySSEnp9FYd9S3a84AuVW-1gaPozPJFeenpGrGVw8Z30ixepgESBY3P8xiOzHy7Lvr5Aawrlt1B',
            collapseKey: 'C2Cmarketplace'
        },
        sandGridKey: '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' //Local Key of email: c2cmarketplace.sdn@gmail.com
    },
    local: {
        port: 5109,
        db: {
            user: 'C2CMarketplace',
            password: 'C2CMarketplace2018',
            url: 'mongodb://52.34.207.5:27017/C2CMarketplace'
        },
        baseUrl: 'http://localhost:5109/',
        smtp: {
            service: 'Gmail',
            username: 'c2cmarketplace.sdn@gmail.com',
            password: 'Password@aa01',
            host: 'smtp.gmail.com',
            mailUsername: 'C2CMarketplace',
            verificationMail: 'c2cmarketplace.sdn@gmail.com'
        },
        cryptoAlgorithm: 'aes-256-ctr',
        cryptoPassword: 'd6F3Efeq',
        secret: 'luxnow',
        googleApiKey: 'AIzaSyDzmSSIf0sBm22lbD2KSlGJTtfX_b_lchU',
        ARApiKey: 'orkgzt1hgput175ilvjxk7xw1',
        twitter: {
            //client twitter keys
            // "consumer_key": "VzzqpVVHKqmN8dFVBgkIHLGbl",
            // "consumer_secret": "xgkYAFjQRkXkTEeb4UngIf7IUNOOGdHRoDbAwPkeYZIlP3R0Mj",
            //viral content keys
            "consumer_key": "Hi49IUUJtNmvF0FVhzdLdMmGH",
            "consumer_secret": "lnmzXgrIT40qAOUpB9mfqlSEfd9XHIfYSjDiDBUmtsqj3K45Mr",
            "callback_url": "callback_twitter",
            "access_type": "read-write",
            "defaultLiveFeedCount": 100,
            "maxLimitTweetText": 140,
            "defaultFollowingCount": 20
        },
        facebook: {
            //A2Z Test (LUXSDN)
            "client_id": "112393802767798",
            "client_secret": "64ff854f676d351cdc0ee0648065227f",
            // Viral Content System App
            // "client_id": "682077881938779",
            // "client_secret": "1934cdfb0546f2b215b44e2b411e5e14",
            "redirect_uri": "callback_facebook",
            "defaultLiveFeedCount": 3,
            "maxLimitText": 140,
            "defaultFollowingCount": 20,
            "scope": "email, user_about_me, user_birthday, user_location, publish_actions, publish_pages, user_posts, user_likes, user_photos,read_insights,manage_pages"
        },
        instagram: {
            "client_id": "8d0e2038fbfe446089d059e48cee2e73",
            "client_secret": "5e48e2c2aa2f4ae28feabe86c2a66543",
            "redirect_uri": "callback_instagram",
            "defaultLiveFeedCount": 100,
            "maxLimitText": 140,
            "defaultFollowingCount": 20,
            "scope": ['likes', 'comments', 'relationships', 'public_content', 'follower_list', 'basic']
        },
        apn: {
            certPath: './../../config/pem/dev/C2CmarketplaceCertR.pem',
            keyPath: './../../config/pem/dev/C2CmarketplaceKeyR.pem',
            passphrase: '1234',
            gateway: 'gateway.sandbox.push.apple.com',
            port: 2195
        },
        fcm: {
            // serverKey: 'AIzaSyC3R5BjfO5WClwzPwT0XnSvx4ku1-nZbXA',
            serverKey: 'AAAAV1lZASs:APA91bGnE-w43VFSWBkVJUCoPFPnRiPD_5puI0pKpP9ZIOFoL9QrMNmEViXrBCBZJRySSEnp9FYd9S3a84AuVW-1gaPozPJFeenpGrGVw8Z30ixepgESBY3P8xiOzHy7Lvr5Aawrlt1B',
            collapseKey: 'C2Cmarketplace'
        },
        sandGridKey: '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' //Local Key of email: c2cmarketplace.sdn@gmail.com
    },

    /*
    SECRET  : 'crm@$12&*01',
    webUrl: 'http://localhost:5046',
    //DIR_NAME: '/app',
        
    SMTP: {
        service: 'gmail',
        host: 'smtp.gmail.com',
        secure: true,
        port: 465,
        authUser: 'techteamsdn@gmail.com',
        authpass: 'tech@sdn'
    },
    EMAIL_FROM : '"Tech Group" <techteamsdn@gmail.com>',
    EMAIL_BCC : '"Tech Group" <techteamsdn@gmail.com>',
    //EMAIL_TEMP : 'stephanie.daniels@lexhelper.com, support2@lexhelper.com',
    EMAIL_TEMP : 'techteamsdn@gmail.com'*/

};

module.exports.get = function get(env) {
    return config[env] || config.default;
}