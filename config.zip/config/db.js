'use strict';

const config = require('./config.js').get(process.env.NODE_ENV);

/* DB */
var mongoose = require('mongoose');
require('../api/models/user');
require('../api/models/permission');
require('../api/models/emailTemplate');
require('../api/models/emailHistory');
require('../api/models/mailingList');
require('../api/models/currency');
require('../api/models/setting');
require('../api/models/shipping_address');
require('../api/models/internal_message');
require('../api/models/review_comment');
require('../api/models/notification');
require('../api/models/payment');
require('../api/models/shipping_detail');
require('../api/models/order');
require('../api/models/faq');

// Product Models
require('../api/models/product');
require('../api/models/product_image');
require('../api/models/product_inventory');
require('../api/models/product_color');
require('../api/models/product_size');
require('../api/models/product_category');
require('../api/models/product_sub_category');
require('../api/models/product_condition');
require('../api/models/product_wish_list');
require('../api/models/product_occasion');

/* end DB */


// database connection setup
mongoose.Promise = global.Promise;
mongoose.connect(config.db.url, { user: config.db.user, pass: config.db.password });			//SDN Local server
var db = mongoose.connection;
db.on('error', console.error.bind(console, "connection failed"));
db.once('open', function() {
    console.log("Database conencted successfully!");
});
// mongoose.set('debug', true);



