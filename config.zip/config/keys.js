
exports.saltKey = '$2a$10$8NNrP7ODP9FGWtcW37DSWO';
