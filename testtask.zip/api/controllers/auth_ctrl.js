'use strict';

var mongoose = require('mongoose'),
    voucher_codes = require('voucher-code-generator'),
    User = mongoose.model('user'),
    path = require('path'),
    jwt = require('jsonwebtoken'),
    validator = require('validator'),
    utility = require('../lib/utility.js'),
    mailer = require('../lib/mailer.js'),
    waterfall = require('async-waterfall'),
    async = require('async'),
    Error = require('../lib/error.js'),
    Response = require('../lib/response.js'),
    constant = require('../lib/constants'),
    c = require('../helpers/cypher');

const config = require('../../config/config.js').get(process.env.NODE_ENV);
// console.log(utility.getDecryptText('308bc784287f7f50611bb7'));
module.exports = {

    userLogin: userLogin,
    userRegister: userRegister,
    googleLogin:googleLogin
};

/**
 * Function is use to login user
 * @access private
 * @return json
 * Created by Akshay
 */
function userLogin(req, res) {
    //console.log('req.body:- ', req.body)
    if (!req.body.email || !req.body.password) {
        res.jsonp(Error(constant.statusCode.error, constant.messages.requiredFieldsMissing, constant.messages.requiredFieldsMissing));
    } else if (req.body.email && !validator.isEmail(req.body.email)) {
        res.jsonp(Error(constant.statusCode.error, constant.messages.invalidEmail, constant.messages.invalidEmail));
    } else {

        var data = {};
        var jwtToken = null;
        var passEnc = utility.getEncryptText(req.body.password);
        var userData = {
            email: req.body.email.toLowerCase(),
            password: passEnc //req.body.password
        };
        var lastLoginDate = new Date();

        User.findOne(userData, {
            password: 0,
            updatedAt: 0,
            createdAt: 0,
            verifyToken: 0
        }).exec(function (err, userInfo) {
            if (err) {
                res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
            } else {
                if (userInfo != null) {
                    if (userInfo.status == 0) {
                        res.json(Error(constant.statusCode.error, constant.messages.accountNotActivated, null));
                    } else if (userInfo.isDelete) {
                        res.json(Error(constant.statusCode.error, constant.messages.accountDeleted, null));
                    } else {
                        var expirationDuration = 60 * 60 * 24 * 8; // expiration duration format sec:min:hour:day. ie: 8 Hours as per i/p
                        //var expirationDuration = 60; // expiration duration 1 minute
                        var params = {
                            uid: userInfo._id
                        }
                        jwtToken = jwt.sign(params, config.secret, {
                            expiresIn: expirationDuration
                        });
                        userInfo.token = jwtToken;
                        // userInfo.lastLoginDate = new Date();
                        userInfo.save(function (err, userInfoData) {
                            if (err) {
                                res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                            } else {
                                res.json(Response(constant.statusCode.ok, constant.messages.loginSuccess, userInfoData, null));
                            }
                        });
                    }
                } else {
                    res.json(Error(constant.statusCode.error, constant.messages.invalidLoginInput, null));
                }
            }
        });
    }
}


/**
 * Function is use to sign up user account 
 * @access private
 * @return json
 * Created by Akshay
 */
 function userRegister(req, res) {
    // console.log('req.body:- ', req.body);

    var finalResponse = {};

    if (!req.body.firstname || !req.body.lastname || !req.body.email || !req.body.password) {
        return res.json(Response(402, constant.validateMsg.requiredFieldsMissing));
    } else if (req.body.email && !validator.isEmail(req.body.email)) {
        return res.json(Response(402, constant.validateMsg.invalidEmail));
    } else {
        waterfall([
            function (callback) { //Check for already exist Email of user
                User.findOne({email: req.body.email}, function (err, emailExist) {
                    // console.log("emailexist", emailExist);
                    if (err) {
                        callback(err, false);
                    } else {
                        if (emailExist) {
                            // finalResponse.isEmailExist = true;
                            res.json(Error(constant.statusCode.error, constant.messages.emailAlreadyExist, null));
                        } else {
                            // finalResponse.isEmailExist = false;  
                            callback(null, finalResponse);
                        }
                    }
                });
            },
            function (finalResponse, callback) { //Save User data
                var code = voucher_codes.generate({
                    prefix: "USR",
                    length: 4,
                    count: 1,
                    charset: "0123456789"
                });
                var date = new Date();
                var verification_token = utility.getEncryptText(Math.random().toString(4).slice(2) + date.getTime());
                var obj = {
                    firstname: req.body.firstname,
                    lastname: req.body.lastname,
                    username: req.body.firstname + ' ' + req.body.lastname,
                    email: req.body.email.toLowerCase(),
                    password: utility.getEncryptText(req.body.password),
                    verification_token: verification_token,
                    uniqueId: code[0]
                };
                
                // console.log('obj:- ', obj);

                var userRecord = new User(obj);
                userRecord.save(function (err, userData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.userData = userData;
                        callback(null, finalResponse);
                    }
                });
            },
        ], function (err, data) {
            if (err) {
                res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
            } else {
                res.json(Response(constant.statusCode.ok, constant.messages.signupSuccess, data, null));
            }
        });
    }
}


function googleLogin(req, res){
    console.log('Req.body : ', req.body);
    var accessTokenUrl = 'https://accounts.google.com/o/oauth2/token';
    var peopleApiUrl = 'https://www.googleapis.com/plus/v1/people/me/openIdConnect';
    var params = {
        code: req.body.code,
        client_id: req.body.clientId,
        client_secret: 'AG4h3XsU_-qxD4qi8IW3o3e9',
        redirect_uri: req.body.redirectUri,
        grant_type: 'authorization_code'
    };
    var finalResponse = {};
    waterfall([
        function (callback) { //Check for already exist Email of user
            request.post(accessTokenUrl, { json: true, form: params }, function(err, response, token) {
                var accessToken = token.access_token;
                var headers = { Authorization: 'Bearer ' + accessToken };
                console.log("err", err)
                console.log("token", token)
                request.get({ url: peopleApiUrl, headers: headers, json: true }, function(err, response, profile) {
                    console.log("err", err)
                    console.log("profile", profile)
                    if (profile.error) {
                        callback(profile.error, null);
                    }else if(err){
                        callback(err, null);
                    }else{
                        finalResponse.googleInfo = profile;
                        callback(null, finalResponse);
                    }
                });
            });
        },
        function (finalResponse, callback) { //Email Already exist
            User.findOne({email : finalResponse.googleInfo.email, deleted: false})
            .lean().exec(function(err, userInfo){
                console.log("err --: ", err);
                console.log("userInfo --: ", userInfo);
                if(err){
                    callback(err, null);
                }else if(userInfo){
                    finalResponse.userInfo = userInfo;
                    callback(null, finalResponse);
                }else{
                    console.log("Email N F")
                    var code = voucher_codes.generate({
                        prefix: "USR",
                        length: 4,
                        count: 1,
                        charset: "0123456789"
                    });
                    var date = new Date();
                    var verification_token = utility.getEncryptText(Math.random().toString(4).slice(2) + date.getTime());
                    var obj = {
                        firstname: finalResponse.googleInfo.given_name,
                        lastname: finalResponse.googleInfo.family_name,
                        username: finalResponse.googleInfo.given_name + ' ' + finalResponse.googleInfo.family_name,
                        email: finalResponse.googleInfo.email.toLowerCase(),
                        password: utility.getEncryptText(code[0]),
                        verification_token: verification_token,
                        uniqueId: code[0],
                        status: 1
                    };                    
                    // console.log('obj:- ', obj);
                    var userRecord = new User(obj);
                    userRecord.save(function (err, userData) {
                        if (err) {
                            console.log("emailexist", err);
                            callback(err, false);
                        } else {
                            finalResponse.userInfo = userData;
                            callback(null, finalResponse);
                        }
                    });
                }
            });
        },
        function (finalResponse, callback) { //Login & token
            var jwtToken = null;
            var expirationDuration = 60 * 60 * 24 * 1; // expiration duration format sec:min:hour:day. ie: 24 Hours as per i/p
            var userInfo = finalResponse.userInfo;
            var params = {
                uid: userInfo._id
            }
            jwtToken = jwt.sign(params, config.secret, {
                expiresIn: expirationDuration
            });
            var userObj = {token : jwtToken};
            User.findOneAndUpdate({_id: userInfo._id}, {$set: userObj}, {new: true}, function (err, userInfoData) {
                if (err) {
                    callback(err, null);
                } else {
                    finalResponse.userInfo = userInfoData;
                    callback(null, finalResponse);
                }
            });
        },
    ], function (err, data) {
        if (err) {
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        } else {
            console.log("Final Response : ", data);
            res.json(Response(constant.statusCode.ok, constant.messages.loginSuccess,data.userInfo, null));
        }
    });
}