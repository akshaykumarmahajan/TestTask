'use strict';

var mongoose = require('mongoose'),
    EmailTemplate = mongoose.model('emailTemplate'),
    utility = require('../lib/utility.js'),
    common = require('../../config/common.js'),
    Error = require('../lib/error.js'),
    Response = require('../lib/response.js'),
    constant = require('../lib/constants.js');


module.exports = {
    getEmailTemplateList: getEmailTemplateList,
    getEmailTemplateById: getEmailTemplateById,
    updateEmailTemplate: updateEmailTemplate
};

/**
 * Function is use to get Service list
 * @access private
 * @return json
 * Created by Akshay
 */
function getEmailTemplateList(req, res) {
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    var sorting = req.body.sorting ? req.body.sorting : { _id: -1 };
    var condition = {};
    var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
    if (req.body.searchText) {
        condition.$or = [
            { 'title': new RegExp(searchText, 'gi') },
            { 'unique_keyword': new RegExp(searchText, 'gi') },
            { 'subject': new RegExp(searchText, 'gi') },
            { 'description': new RegExp(searchText, 'gi') }
        ];
    }
    condition.isDeleted = false;
    EmailTemplate.find(condition)
        .limit(parseInt(count))
        .skip(parseInt(skip))
        .sort(sorting)
        .lean()
        .exec(function(err, result) {
            if (err) {
                res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
            } else {
                var data = {};
                data.data = result;
                EmailTemplate.find(condition)
                    .count()
                    .exec(function(err, totalCount) {
                        if (err) {
                            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                        } else {
                            data.totalCount = totalCount
                            res.json(Response(constant.statusCode.ok, constant.messages.dataRetrievedSuccess, data, null));
                        }
                    })
            }
        })
}


/**
 * Function is use to get emailTemplate 
 * @access private
 * @return json
 * Created by Akshay
 */
function getEmailTemplateById(req, res) {
    var id = req.swagger.params.id.value;
    EmailTemplate.findOne({ _id: id }, 'title description subject unique_keyword')
        .lean()
        .exec(function(err, data) {
            if (err) {
                res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
            } else {
                if (!data) {
                    res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));

                } else {
                    res.json(Response(constant.statusCode.ok, constant.messages.dataRetrievedSuccess, data, null));
                }
            }
        });
}

/**
 * Function is use to update EmailTemplate info
 * @access private
 * @return json
 * Created by Akshay
 */
function updateEmailTemplate(req, res) {
    EmailTemplate.find({ unique_keyword: req.body.unique_keyword, _id: { $ne: req.body._id }, isDeleted: false }, function(err, existEmailTemplateData) {
        if (err) {
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        } else {
            if (existEmailTemplateData.length > 0) {
                res.jsonp(Error(constant.statusCode.error, constant.messages.emailTemplateAlreadyExist, constant.messages.emailTemplateAlreadyExist));
            } else {

                EmailTemplate.findById(req.body._id).exec(function(err, emailTemplateData) {
                    if (err) {
                        res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                    } else {
                        if (emailTemplateData) {
                            emailTemplateData.title = req.body.title;
                            emailTemplateData.description = req.body.description;
                            emailTemplateData.subject = req.body.subject;
                            emailTemplateData.save(function(err, data) {
                                if (err) {
                                    res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
                                } else {
                                    res.json(Response(constant.statusCode.ok, constant.messages.emailTemplateUpdateSuccess, data, null));
                                }
                            });
                        } else {
                            res.jsonp(Error(constant.statusCode.error, constant.messages.emailTemplateNotFound, constant.messages.emailTemplateNotFound));
                        }
                    }
                });

            }
        }
    });
}