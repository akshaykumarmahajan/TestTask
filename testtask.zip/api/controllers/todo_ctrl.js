'use strict';

var mongoose = require('mongoose'),
    Todo = mongoose.model('todo'),
    formidable = require('formidable'),
    waterfall = require('async-waterfall'),
    util = require('util'),
    fs = require('fs-extra'),
    path = require('path'),
    jwt = require('jsonwebtoken'),
    validator = require('validator'),
    mailer = require('../lib/mailer.js'),
    config = require('../../config/mail_config.js'),
    utility = require('../lib/utility.js'),
    Error = require('../lib/error.js'),
    Response = require('../lib/response.js'),
    constant = require('../lib/constants');

var nodemailer = require("nodemailer");
var smtpTransport = require('nodemailer-smtp-transport');

var transporter = nodemailer.createTransport(
    smtpTransport('smtp://' + config.SMTP.authUser + ':' + config.SMTP.authpass + '@smtp.gmail.com')
);


module.exports = {
    addTodo: addTodo,
    updateTodo: updateTodo,
    getTodoList:getTodoList,
    deleteTodo:deleteTodo   
};    

/**
 * Function is use to add new todo
 * @access private
 * @return json
 * Created by Akshay
 */
 function addTodo(req, res) {
       var finalResponse = {};
    // console.log("Req Body 11111111111111111: ", req.body);
    waterfall([
        function(callback) {
            var todoData = {
                todo_name: req.body.todo_name,
                todo_description:req.body.todo_description,
                email: req.body.email,
            };
            var todoRecord = new Todo(todoData);
            todoRecord.save(function(err, data) {
                if (err) {
                    console.log('err save:- ',err)
                    callback(err, false);
                } else {
                    finalResponse = data;
                    callback(null, finalResponse);
                }
            });
        },
        function (finalResponse, callback) { //Send Email to User for creating new todo
            var mailData = {
                email: req.body.email,
                todo_name: req.body.todo_name,
                todo_description:  req.body.todo_description,
            };
            // console.log("maildata",mailData);
            mailer.sendMail(mailData.email, constant.emailKeyword.todo_task_created, mailData, function (err, resp) {
                if (err) {
                    callback(err, false);
                } else {
                    // console.log("heer");
                    callback(null, finalResponse);
                }
            });
        },
        
    ], function(err, data) {
        if (err) {
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        } else {
            res.json(Response(constant.statusCode.ok, constant.messages.todoAddSuccess, data, null));
        }
    });
}


/**
 * Function is use to update todo
 * @access private
 * @return json
 * Created by Akshay
 */
function updateTodo(req, res) {
    var finalResponse = {};
    waterfall([
        function(callback) {
            var todoId = req.body.todoId;
            var todoData = {
                todo_name: req.body.todo_name,
                todo_description:req.body.todo_descriptiond,
                status:'2'
            };
            Todo.findOneAndUpdate({_id: todoId, deleted: false}, {$set: todoData}, {new: true}, function(err, data){
                if (err) {
                    console.log('err save:- ',err)
                    callback(err, false);
                } else {
                    finalResponse = data;
                    callback(null, finalResponse);
                }

            });
        },
        function (finalResponse, callback) { //Send Email to User for creating new todo
            console.log("email",finalResponse.email);
            var mailData = {
                email: finalResponse.email,
                todo_name: req.body.todo_name,
                todo_description:  req.body.todo_description,
            };
            // console.log("maildata",mailData);
            mailer.sendMail(mailData.email, constant.emailKeyword.todo_task_completed, mailData, function (err, resp) {
                if (err) {
                    callback(err, false);
                } else {
                    // console.log("heer");
                    callback(null, finalResponse);
                }
            });
        },
        
    ], function(err, data) {
        if (err) {
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        } else {
            res.json(Response(constant.statusCode.ok, constant.messages.todoUpdated, data, null));
        }
    });

}


/**
 * Function is use to get Todo list
 * @access private
 * @return json
 * Created by Akshay
 */
function getTodoList(req, res) {
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    // var sorting = req.body.sorting ? req.body.sorting : { _id: -1 };
    var sorting = utility.getSortObj(req.body);
    var condition = {deleted: false};
    Todo.find(condition)
    .limit(parseInt(count))
    .skip(parseInt(skip))
    .sort(sorting)
    .lean()
    .exec(function(err, result) {
        if (err) {
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        } else {
            var data = {};
            data.data = result;
            Todo.find(condition).count().exec(function(err, totalCount) {
                if (err) {
                    res.json({code: 201, message: constant.messages.requestNotProcessed, data: err});
                } else {
                    data.totalCount = totalCount;
                    res.json({code: 200, message: constant.messages.dataRetrievedSuccess, data: data});
                }
            })
        }
    });
}


/**
 * Function is use to delete Todo
 * @access private
 * @return json
 * Created by Akshay
 */
function deleteTodo(req, res) {
    var id = req.swagger.params.id.value;
    var updateTodo = { deleted: true }
    Todo.update({ _id: id }, { $set: updateTodo }, function(err) {
        if (err) {
            res.jsonp(Error(constant.statusCode.error, constant.messages.requestNotProcessed, err));
        } else {
            res.json(Response(constant.statusCode.ok, constant.messages.todoDeleteSuccess, {}, null));
        }
    });
}
