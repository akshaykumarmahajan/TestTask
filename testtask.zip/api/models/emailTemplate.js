'use strict';

var mongoose = require('mongoose');

var emailTemplateSchema = new mongoose.Schema({
    title			: 	{ type: String },
    unique_keyword	: 	{ type: String },
    subject			: 	{ type: String, required: true },
    description		: 	{ type: String, required: true },
    status		    : 	{ type: Number, default: 1 },
    deleted			: 	{ type: Boolean, default: false }
}, {
    timestamps: true
});

var EmailTemplate = mongoose.model('emailTemplate', emailTemplateSchema);
module.exports = EmailTemplate;


module.exports = EmailTemplate;
module.exports = mongoose.model('emailTemplate', emailTemplateSchema);

var obj = {
    "title" : "Todo Task Created",
    "unique_keyword" : "todo_task_created",
    "subject" : "Todo Task Created",
    "description" : '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"><html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office"><head> <meta http-equiv="Content-Type" content="text/html; charset=utf-8"> <meta http-equiv="X-UA-Compatible" content="IE=edge"> <meta name="viewport" content="width=device-width, initial-scale=1"> <title></title> <style>*{margin: 0; padding: 0;}body, table, td, p, a, li, blockquote{-webkit-text-size-adjust: none !important;}@media only screen and (max-width: 480px){body{width: 100% !important; min-width: 100% !important; margin: 0;}#parent_tbl{width: 100% !important; padding: 0 0;}#child_tbl{width: 100% !important; padding: 0 0px;}.top_head{display: block !important; width: 100%; text-align: center; padding: 18px 0px 24px 0px !important;}.top_head h3{font-size: 16px !important;}.info{display: block; width: 100%; text-align: left;}.footer-padding{padding:10px 3px !important;}}</style></head><body> <table border="0" cellpadding="0" cellspacing="0" width="100%" style="background: #d8d8d8; margin: 0; padding: 0"> <tr> <td> <table align="center" border="0" cellpadding="0" cellspacing="0" width="600px" id="parent_tbl" style="background: #fff; margin: 40px auto"> <tr> <td> <table width="600px" align="center" cellpadding="0" cellspacing="0" id="child_tbl"> <tr> <td colspan="2" class="top_head" style=" padding:30px 8px 24px 8px; text-align: center; border-bottom: 1px solid #de1352;"> <span style="color: #de1352; font-size: 25px;"><b>Infosys</b></span> </td></tr><tr colspan="2"> <td style=" padding:20px 30px 0px 30px;"><p style="margin:0px; font-size:23px; color:#666666; font-family: arial; font-weight:300;">Todo Task</p></td></tr><tr> <td style=" padding:30px 30px 0px 30px;" colspan="2"> <p style=" margin:0 0 15px 0; font-size:14px; color:#666666; font-family: arial; font-weight:300;"> Hello [[email]],</p><h3 style=" font-size:14px; color:#666666; font-family: arial; font-weight:300; margin: 0 0 20px 0">You have created a new todo . Please find the details below.</h3> <h3 style=" font-size:14px; color:#666666; font-family: arial; font-weight:300; margin: 0 0 20px 0">Todo Name : [[todo_name]]</h3> <h3 style=" font-size:14px; color:#666666; font-family: arial; font-weight:300; margin: 0 0 20px 0">Todo Description : [[todo_description]]</h3>  </td></tr><tr> <td style=" padding:0px 100px 0px 30px;" colspan="2">  </td></tr><tr> <td style=" padding:0px 30px 25px 30px;" colspan="2"> <p style=" margin:20px 0 0 0; font-size:14px; color:#666666; font-family: arial; font-weight:300;">Regards,<br>Infosys</p></td></tr><tr> <td class="footer-padding" style=" background: #de1352; padding:15px 15px; vertical-align: top" colspan=""> <table width="100%"> <tr> <td style="font-size:14px; color:#fff; font-family: arial; font-weight:400;line-height:25px; vertical-align: top;"><p style="text-align: center; font-size: 12px;">Copyright © 2020 Infosys  - All Rights Reserved</p></td></tr></table> </td></tr></table> </td></tr></table> </td></tr></table></body></html>',
    "isDeleted" : false,
    "isActive" : false
};
var templateRecord = new EmailTemplate(obj);
templateRecord.save(function (err, data) {
	//console.log("Emai Err : ", err);
	//console.log("Emai res : ", data);
});

var EmailTemplate = mongoose.model('emailTemplate', emailTemplateSchema);
module.exports = EmailTemplate;
module.exports = mongoose.model('emailTemplate', emailTemplateSchema);

var obj = {
    "title" : "Todo Task Completed",
    "unique_keyword" : "todo_task_completed",
    "subject" : "Todo Task Completed",
    "description" : '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"><html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office"><head> <meta http-equiv="Content-Type" content="text/html; charset=utf-8"> <meta http-equiv="X-UA-Compatible" content="IE=edge"> <meta name="viewport" content="width=device-width, initial-scale=1"> <title></title> <style>*{margin: 0; padding: 0;}body, table, td, p, a, li, blockquote{-webkit-text-size-adjust: none !important;}@media only screen and (max-width: 480px){body{width: 100% !important; min-width: 100% !important; margin: 0;}#parent_tbl{width: 100% !important; padding: 0 0;}#child_tbl{width: 100% !important; padding: 0 0px;}.top_head{display: block !important; width: 100%; text-align: center; padding: 18px 0px 24px 0px !important;}.top_head h3{font-size: 16px !important;}.info{display: block; width: 100%; text-align: left;}.footer-padding{padding:10px 3px !important;}}</style></head><body> <table border="0" cellpadding="0" cellspacing="0" width="100%" style="background: #d8d8d8; margin: 0; padding: 0"> <tr> <td> <table align="center" border="0" cellpadding="0" cellspacing="0" width="600px" id="parent_tbl" style="background: #fff; margin: 40px auto"> <tr> <td> <table width="600px" align="center" cellpadding="0" cellspacing="0" id="child_tbl"> <tr> <td colspan="2" class="top_head" style=" padding:30px 8px 24px 8px; text-align: center; border-bottom: 1px solid #de1352;"> <span style="color: #de1352; font-size: 25px;"><b>Infosys</b></span> </td></tr><tr colspan="2"> <td style=" padding:20px 30px 0px 30px;"><p style="margin:0px; font-size:23px; color:#666666; font-family: arial; font-weight:300;">Todo Task Completed</p></td></tr><tr> <td style=" padding:30px 30px 0px 30px;" colspan="2"> <p style=" margin:0 0 15px 0; font-size:14px; color:#666666; font-family: arial; font-weight:300;"> Hello [[email]],</p><h3 style=" font-size:14px; color:#666666; font-family: arial; font-weight:300; margin: 0 0 20px 0">You have Completed todo . Please find the details below.</h3> <h3 style=" font-size:14px; color:#666666; font-family: arial; font-weight:300; margin: 0 0 20px 0">Todo Name : [[todo_name]]</h3> <h3 style=" font-size:14px; color:#666666; font-family: arial; font-weight:300; margin: 0 0 20px 0">Todo Description : [[todo_description]]</h3>  </td></tr><tr> <td style=" padding:0px 100px 0px 30px;" colspan="2">  </td></tr><tr> <td style=" padding:0px 30px 25px 30px;" colspan="2"> <p style=" margin:20px 0 0 0; font-size:14px; color:#666666; font-family: arial; font-weight:300;">Regards,<br>Infosys</p></td></tr><tr> <td class="footer-padding" style=" background: #de1352; padding:15px 15px; vertical-align: top" colspan=""> <table width="100%"> <tr> <td style="font-size:14px; color:#fff; font-family: arial; font-weight:400;line-height:25px; vertical-align: top;"><p style="text-align: center; font-size: 12px;">Copyright © 2020 Infosys  - All Rights Reserved</p></td></tr></table> </td></tr></table> </td></tr></table> </td></tr></table></body></html>',
    "isDeleted" : false,
    "isActive" : false
};
var templateRecord = new EmailTemplate(obj);
templateRecord.save(function (err, data) {
	//console.log("Emai Err : ", err);
	//console.log("Emai res : ", data);
});