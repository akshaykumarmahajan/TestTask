'use strict';

var mongoose = require('mongoose');

var mailingListSchema = new mongoose.Schema({
	email:     {type: String, lowercase: true, unique: true, required: true },
	status:    {type: String, default: 1},    //0-deactive, 1-active
	isDelete:  {type: Boolean, default: false}
}, {
    timestamps: true
});

module.exports = mongoose.model('mailingList', mailingListSchema);