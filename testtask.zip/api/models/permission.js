'use strict';

var mongoose = require('mongoose');

var permissionSchema = new mongoose.Schema({
    adminId:                {type: mongoose.Schema.Types.ObjectId, ref: 'user'},
    dashboard:              {type: Boolean, default: true},   
    emailTemplate:          {type: Boolean, default: true},   
}, {
    timestamps: true
});

var Permission = mongoose.model('permission', permissionSchema);
module.exports = Permission;
