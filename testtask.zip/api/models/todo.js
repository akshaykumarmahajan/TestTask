'use strict';

var mongoose = require('mongoose');

var todoSchema = new mongoose.Schema({
	todo_name: 			{type: String},
	todo_description: 	{type: String},
	email: 				{type: String},
	status: 			{type: String, default: 0},       //0-Incomplete, 1-Complete 
	deleted: 			{type: Boolean, default: false},
	token: 				{type: String},
}, {
    timestamps: true
});

var TODO = mongoose.model('todo', todoSchema);
module.exports = TODO;