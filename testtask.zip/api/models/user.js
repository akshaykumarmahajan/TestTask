'use strict';

var mongoose = require('mongoose');

var userSchema = new mongoose.Schema({
    firstname:                      {type: String, required: true },
    lastname:                       {type: String, required: true },
    username:                       {type: String, default: ''},    
    email:                          {type: String, lowercase: true, required: true, unique: true },
    password:                       {type: String, required: true },
    phone_number:                   {type: String, default: null },
    token:                          {type: String, default: '' },     // TOken to access all API's
    verification_token:             {type: String, default: '' },
    joinDate:                       {type: Date,   default: Date.now },
    status:                         {type: Number, default: 1 },       //0-InActive, 1-Active, 2- Deactive
    deleted:                        {type: Boolean, default: false },
    is_email_verified:              {type: Boolean, default: true },
    is_phone_verified:              {type: Boolean, default: true },
    role:                           {type: String, enum: ['User', 'Admin'], default: 'User' },
}, {
    timestamps: true
});

var User = mongoose.model('user', userSchema);
module.exports = User;