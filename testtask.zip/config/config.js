'use strict';

const config = {

    local: {
        port: 5109,
        db: {
            user: '',
            password: '',
            url: 'mongodb://localhost:27017/TechTest'
        },
        baseUrl: 'http://localhost:5109/',
        smtp: {
            service: 'Gmail',
            username: 'c2cmarketplace.sdn@gmail.com',
            password: 'Password@aa01',
            host: 'smtp.gmail.com',
            mailUsername: 'C2CMarketplace',
            verificationMail: 'c2cmarketplace.sdn@gmail.com'
        },
        cryptoAlgorithm: 'aes-256-ctr',
        cryptoPassword: 'd6F3Efeq',
        secret: 'luxnow',
        googleApiKey: 'AIzaSyDzmSSIf0sBm22lbD2KSlGJTtfX_b_lchU',
        ARApiKey: 'orkgzt1hgput175ilvjxk7xw1',
        sandGridKey: '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' //Local Key of email: c2cmarketplace.sdn@gmail.com
    },

};

module.exports.get = function get(env) {
    return config[env] || config.default;
}