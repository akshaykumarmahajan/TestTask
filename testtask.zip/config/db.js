'use strict';

const config = require('./config.js').get(process.env.NODE_ENV);

/* DB */
var mongoose = require('mongoose');
require('../api/models/user');
require('../api/models/todo');
require('../api/models/permission');
require('../api/models/emailTemplate');
require('../api/models/emailHistory');
require('../api/models/mailingList');

// database connection setup
mongoose.Promise = global.Promise;
mongoose.connect(config.db.url, { user: config.db.user, pass: config.db.password });	
// mongoose.connect('mongodb://localhost:27017/C2CMarketplace', { user: '', pass: '' });			//SDN Local server
var db = mongoose.connection;
db.on('error', console.error.bind(console, "connection failed"));
db.once('open', function() {
    console.log("Database conencted successfully!");
});
// mongoose.set('debug', true);



