'use strict';

module.exports =  {
        SECRET  : 'crm@$12&*01',       
    
        webUrl: 'http://localhost:5083',
        //DIR_NAME: '/app',
        
        SMTP: {
            service: 'gmail',
            host: 'smtp.gmail.com',
            secure: true,
            port: 465,
            authUser: 'techteamsdn@gmail.com',
            authpass: 'tech@sdn'
        },
        EMAIL_FROM : '"Tech Group" <techteamsdn@gmail.com>',
        EMAIL_BCC : '"Tech Group" <techteamsdn@gmail.com>',
        //EMAIL_TEMP : 'stephanie.daniels@lexhelper.com, support2@lexhelper.com',
        EMAIL_TEMP : 'techteamsdn@gmail.com'
};